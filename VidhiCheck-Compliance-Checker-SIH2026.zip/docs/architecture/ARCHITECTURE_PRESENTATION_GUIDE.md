# VIDHICHECK — SYSTEM ARCHITECTURE & SIH PRESENTATION GUIDE

**Problem Statement:** SIH26034 — Software System to check compliance of Packaged Commodities under Legal Metrology (Packaged Commodities) Rules, 2011  
**Target Ministry:** Ministry of Consumer Affairs, Food & Public Distribution  
**Prototype Name:** VidhiCheck (AI-Based Packaged Commodity Compliance Checker)  

---

## 1. High-Level Architecture Diagram (Mermaid)

```mermaid
flowchart LR
    %% Subgraphs matching 5 visual layers
    subgraph USER_LAYER ["1. USER LAYER"]
        direction TB
        OFFICER["<b>[1] ENFORCEMENT OFFICER</b><br/>• Scan / Upload Product Image<br/>• View AI Compliance Flags<br/>• Authorize Final Legal Status<br/><br/><i>Tech: React + Tailwind CSS</i>"]
    end

    subgraph AI_LAYER ["2. AI PROCESSING LAYER"]
        direction TB
        IMG_PROC["<b>[2] IMAGE PROCESSING</b><br/>• Upload & Validation<br/>• Auto Crop, Resize, Deskew<br/>• Contrast & Denoising<br/>• Label Area Detection<br/><br/><i>Tech: Python + OpenCV</i>"]
        OCR["<b>[3] OCR ENGINE</b><br/>• Multi-angle Text Detection<br/>• Text Bounding Boxes<br/>• Multilingual Extraction<br/>• Confidence Scores (0-100%)<br/><br/><i>Tech: PaddleOCR / Tesseract</i>"]
        DECLARATION["<b>[4] DECLARATION EXTRACTION</b><br/>• MRP & Unit Sale Price<br/>• Net Quantity & Units<br/>• Mfg / Pkd / Expiry Date<br/>• Manufacturer / Packer<br/>• Consumer Care Details<br/><br/><i>Tech: Python + Regex + NLP</i>"]
        IMG_PROC --> OCR --> DECLARATION
    end

    subgraph CORE_LAYER ["3. VIDHICHECK CORE"]
        direction TB
        RULE_ENGINE["<b>[5] VIDHICHECK — LEGAL METROLOGY RULE CHECKER</b><br/>• Mandatory Declarations (Rule 6)<br/>• MRP Formatting & Taxes<br/>• Net Quantity Units (Rule 13)<br/>• Mfg / Pkd Date Format<br/>• Font Size & Readability Thresholds<br/><br/><i>Tech: Python Rule Engine + JSON Rules</i>"]
        COMPLIANCE["<b>[6] COMPLIANCE ANALYSIS</b><br/><b>Outcomes:</b><br/>[✓] COMPLIANT<br/>[✗] NON-COMPLIANT<br/>[⚠] NEEDS VERIFICATION<br/><br/><b>Output:</b> Rule Violated + Reason + Evidence"]
        RULE_ENGINE --> COMPLIANCE
    end

    subgraph VERIFICATION_LAYER ["4. VERIFICATION LAYER"]
        direction TB
        VERIFY["<b>[7] OFFICER VERIFICATION</b><br/><i>Human-in-the-Loop Safeguard</i><br/>• Review AI Analysis & Evidence<br/>• Cross-examine Discrepancies<br/>• Add Official Remarks<br/>• Accept / Overrule AI Finding<br/><br/><b>[FINAL COMPLIANCE STATUS]</b><br/><i>(Officer Signed & Timestamped)</i>"]
    end

    subgraph OUTPUT_LAYER ["5. OUTPUT LAYER"]
        direction TB
        REPORT["<b>[8] REPORT GENERATION</b><br/>• Packaging Photo & OCR Logs<br/>• Extracted Declarations<br/>• Violated Rules & Penal Sections<br/>• Officer Remarks & Stamp<br/><br/><b>Output: PDF Compliance Report</b>"]
        DB[("<b>[9] INSPECTION DATABASE</b><br/>• Scanned Products & Hashes<br/>• OCR Detections & Confidences<br/>• Inspection Records<br/>• Audit Trail & History<br/><br/><i>Tech: SQLite</i>")]
        DASHBOARD["<b>[10] VIDHICHECK DASHBOARD</b><br/>• Total Inspections<br/>• Compliant vs Non-Compliant<br/>• Pending Verification Queue<br/>• Violation Trends & Summaries<br/><br/><i>Tech: React + Charts</i>"]
        REPORT --> DB --> DASHBOARD
    end

    %% Flow Connectivity
    OFFICER -->|"Product Image"| IMG_PROC
    DECLARATION -->|"Extracted Declarations"| RULE_ENGINE
    COMPLIANCE -->|"AI Result & Evidence"| VERIFY
    VERIFY -->|"Final Validated Status"| REPORT
    DASHBOARD -.->|"Review History & Analytics"| OFFICER

    %% Styling
    classDef bAndW fill:#ffffff,stroke:#000000,stroke-width:1.5px,color:#000000;
    classDef coreBlock fill:#ffffff,stroke:#000000,stroke-width:2.5px,color:#000000;
    class OFFICER,IMG_PROC,OCR,DECLARATION,COMPLIANCE,VERIFY,REPORT,DB,DASHBOARD bAndW;
    class RULE_ENGINE coreBlock;
```

---

## 2. The 5 Logical Layers Explained (For Slides)

| Layer | Component | Core Responsibility | Technologies Used |
| :--- | :--- | :--- | :--- |
| **1. User Layer** | Enforcement Officer | Field inspector captures multi-side product packaging photos using mobile/web app. Views flagged declarations and authorizes legal outcomes. | React, Tailwind CSS |
| **2. AI Processing Layer** | Image Processing, OCR Engine, Declaration Extraction | Pre-processes image (crop, deskew, contrast), localizes text regions using bounding boxes, and extracts key structured declarations (MRP, Net Qty, Mfg Date, Packer, Consumer Care). | Python, OpenCV, PaddleOCR / Tesseract, Regex + Basic NLP |
| **3. VidhiCheck Core** | Legal Metrology Rule Checker & Compliance Analysis | Validates extracted attributes against codified Legal Metrology (Packaged Commodities) Rules, 2011. Returns 3 clear outcomes: `✓ COMPLIANT`, `✗ NON-COMPLIANT`, or `⚠ NEEDS VERIFICATION`. | Python Rule Engine, Declarative JSON Rules |
| **4. Verification Layer** | Officer Verification (Human-in-the-loop) | Critical legal safeguard: Officer reviews AI-generated findings, examines evidence snapshots, adds remarks, and gives the final legally-binding verdict. | Web Verification UI |
| **5. Output Layer** | PDF Report, Database, Dashboard | Compiles tamper-evident inspection PDF report, archives logs in SQLite, and displays market-wide compliance analytics on the dashboard. | ReportLab (Python), SQLite, React + Charts |

---

## 3. Technology Stack Summary (Bottom Bar)

```
┌──────────────────────────────────────────────────────────────────────────────────────────┐
│                                   TECHNOLOGY STACK                                       │
├────────────────────┬────────────────────┬────────────────────────────────────────────────┤
│ Layer              │ Technology         │ Why this choice? (SIH Justification)           │
├────────────────────┼────────────────────┼────────────────────────────────────────────────┤
│ Frontend           │ React + Tailwind   │ Responsive, fast field-ready UI for mobile/PC  │
│ Backend API        │ Python + FastAPI   │ High-throughput async endpoints, native ML fit │
│ AI / Vision        │ OpenCV + PaddleOCR │ Robust Indian font OCR, bounding box accuracy  │
│ Rule Engine        │ Python + JSON      │ Easy rule updating when gazette rules change   │
│ Database           │ SQLite             │ Zero-config, lightweight, zero cloud overhead  │
│ Reports            │ ReportLab (Python) │ Automated, court-admissible PDF generation     │
└────────────────────┴────────────────────┴────────────────────────────────────────────────┘
```

---

## 4. Key SIH Judge Questions & Foolproof Answers

### Question 1: "Why can't the AI automatically issue a challan or notice without an officer?"
> **Answer:** *"Under the Legal Metrology Act, 2009 and Indian administrative jurisprudence, penal and regulatory actions require attribution to a legally designated public officer. AI cannot be legally culpable for false positives. VidhiCheck is designed as an **intelligence amplifier**, reducing inspection time from 15 minutes to 30 seconds, while keeping the Legal Metrology Officer firmly in the loop as the final legal authority."*

### Question 2: "Why use a JSON Rule Engine instead of end-to-end Deep Learning for compliance?"
> **Answer:** *"Legal compliance requires **100% determinism and explainability**. Deep learning is probabilistic and hallucinations could create unlawful citations. By separating OCR (perception) from our Python Rule Engine (logic), our system provides an exact audit trail: e.g., 'Rule 6(1)(e) violated: Unit Sale Price missing on pack > 100g'. Furthermore, whenever the ministry amends regulations, we simply update a JSON rule definition without retraining any ML model."*

### Question 3: "Why is the architecture not using Kubernetes / Kafka / Microservices?"
> **Answer:** *"For an on-field enforcement prototype, reliability, offline capability, and zero dev-ops friction are paramount. A modular FastAPI + SQLite architecture can run directly on an officer’s laptop or edge tablet in remote rural markets without cloud connectivity. It delivers maximum performance with minimum operational attack surface."*

---

## 5. Files Generated in This Repository

1. **Standalone SVG Vector Graphic:**  
   `docs/architecture/vidhicheck_architecture_diagram.svg`  
   *(Insert directly into PowerPoint slides without loss of quality at 4K/1080p)*

2. **Interactive HTML Presentation & Export Tool:**  
   `docs/architecture/vidhicheck_architecture_diagram.html`  
   *(Open in any browser to view and click 'Export PNG for PPT' or 'Download SVG')*
