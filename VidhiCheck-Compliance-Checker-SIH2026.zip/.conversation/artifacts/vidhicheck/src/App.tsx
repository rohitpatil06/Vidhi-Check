import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { AppShell } from '@/components/app-shell';
import { LoginPage } from '@/pages/auth';
import { AboutPage } from '@/pages/about';
import { DashboardPage } from '@/pages/dashboard';
import { HistoryPage } from '@/pages/history';
import { ReportsPage } from '@/pages/reports';
import { ResultPage } from '@/pages/result';
import { ScanPage } from '@/pages/scan';
import NotFound from '@/pages/not-found';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Router() {
  const isAuthenticated = typeof window !== 'undefined' && localStorage.getItem('vidhicheck-auth') === 'true';
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={LoginPage} />
        <Route path="/dashboard">{() => isAuthenticated ? <AppShell><DashboardPage /></AppShell> : <LoginPage />}</Route>
        <Route path="/scan">{() => isAuthenticated ? <AppShell><ScanPage /></AppShell> : <LoginPage />}</Route>
        <Route path="/result/:id">{() => isAuthenticated ? <AppShell><ResultPage /></AppShell> : <LoginPage />}</Route>
        <Route path="/history">{() => isAuthenticated ? <AppShell><HistoryPage /></AppShell> : <LoginPage />}</Route>
        <Route path="/reports">{() => isAuthenticated ? <AppShell><ReportsPage /></AppShell> : <LoginPage />}</Route>
        <Route path="/about">{() => isAuthenticated ? <AppShell><AboutPage /></AppShell> : <LoginPage />}</Route>
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
