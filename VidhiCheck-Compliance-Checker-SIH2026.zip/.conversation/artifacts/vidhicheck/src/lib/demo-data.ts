import type { Dashboard, Inspection, Report } from '@workspace/api-client-react';

export const demoInspection: Inspection = {
  id: 'VC-24091',
  product: 'Sona Masoori Rice · 5 kg',
  date: '2025-02-14T10:42:00.000Z',
  officer: 'A. Mehta',
  status: 'Needs Verification',
  score: 78,
  declarations: [
    { field: 'productName', label: 'Commodity name', value: 'Sona Masoori Rice', confidence: 0.98, status: 'pass' },
    { field: 'netQuantity', label: 'Net quantity', value: '5 kg', confidence: 0.96, status: 'pass' },
    { field: 'mrp', label: 'Maximum retail price', value: '₹ 485.00', confidence: 0.93, status: 'pass' },
    { field: 'packer', label: 'Manufacturer / packer', value: 'Kaveri Grains Pvt. Ltd.', confidence: 0.84, status: 'warning' },
    { field: 'address', label: 'Registered address', value: 'Plot 18, Industrial Area, Bengaluru', confidence: 0.71, status: 'warning' },
    { field: 'consumerCare', label: 'Consumer care', value: '1800 123 4477', confidence: 0.99, status: 'pass' },
  ],
  checks: [
    { requirement: 'Name and address of packer', result: 'Present; address line is partially obscured', status: 'warning' },
    { requirement: 'Net quantity in standard units', result: '5 kg · declaration is legible', status: 'pass' },
    { requirement: 'Maximum retail price inclusive of taxes', result: '₹ 485.00 · format accepted', status: 'pass' },
    { requirement: 'Consumer care details', result: 'Toll-free number detected', status: 'pass' },
    { requirement: 'Month and year of packing', result: 'Not found in visible label area', status: 'fail' },
  ],
  violations: [
    { title: 'Packing month not visible', status: 'Open', reason: 'The mandatory month and year of packing could not be established from the supplied label photograph.', rule: 'LM Rules, Rule 6(1)(d)' },
    { title: 'Address needs officer confirmation', status: 'Review', reason: 'OCR confidence is below the verification threshold for the registered address line.', rule: 'LM Rules, Rule 6(1)(a)' },
  ],
  ocrText: 'SONA MASOORI RICE | NET QTY 5 kg | MRP ₹485.00 (INCLUSIVE OF ALL TAXES) | PACKED BY KAVERI GRAINS PVT LTD | CUSTOMER CARE 1800 123 4477',
  imageData: null,
  remarks: '',
  finalStatus: null,
};

export const demoInspections: Inspection[] = [
  demoInspection,
  { ...demoInspection, id: 'VC-24088', product: 'Parle-G Biscuits · 800 g', date: '2025-02-13T15:18:00.000Z', status: 'Compliant', score: 96, finalStatus: 'Compliant', violations: [], remarks: 'All declarations verified against visible label.' },
  { ...demoInspection, id: 'VC-24083', product: 'Fortune Sunflower Oil · 1 L', date: '2025-02-12T11:05:00.000Z', status: 'Non-Compliant', score: 48, finalStatus: 'Non-Compliant', violations: [{ title: 'MRP appears overwritten', status: 'Open', reason: 'The printed price shows evidence of alteration.', rule: 'LM Rules, Rule 6(1)(e)' }] },
  { ...demoInspection, id: 'VC-24077', product: 'Aashirvaad Atta · 10 kg', date: '2025-02-11T09:34:00.000Z', status: 'Needs Verification', score: 69 },
  { ...demoInspection, id: 'VC-24071', product: 'Tata Salt · 1 kg', date: '2025-02-10T14:09:00.000Z', status: 'Compliant', score: 91, finalStatus: 'Compliant', violations: [] },
];

export const demoDashboard: Dashboard = {
  total: 128,
  compliant: 91,
  nonCompliant: 18,
  needsVerification: 19,
  recent: demoInspections.slice(0, 4),
};

const storageKey = 'vidhicheck-inspections';
export function readLocalInspections(): Inspection[] {
  try {
    const stored = localStorage.getItem(storageKey);
    return stored ? JSON.parse(stored) as Inspection[] : demoInspections;
  } catch { return demoInspections; }
}
export function saveLocalInspection(inspection: Inspection): void {
  const existing = readLocalInspections().filter((item) => item.id !== inspection.id);
  localStorage.setItem(storageKey, JSON.stringify([inspection, ...existing]));
}
export function getLocalInspection(id: string): Inspection {
  return readLocalInspections().find((item) => item.id === id) ?? demoInspection;
}
export function makeLocalReport(id: string, inspection: Inspection): Report {
  return {
    id,
    fileName: `vidhicheck-${id.toLowerCase()}.pdf`,
    content: `VIDHICHECK COMPLIANCE VERIFICATION\n\nInspection: ${id}\nProduct: ${inspection.product}\nOfficer: ${inspection.officer}\nStatus: ${inspection.finalStatus ?? inspection.status}\nScore: ${inspection.score}/100\n\nDeclarations\n${inspection.declarations.map((item) => `- ${item.label}: ${item.value}`).join('\n')}\n\nRemarks\n${inspection.remarks || 'No additional remarks recorded.'}`,
  };
}