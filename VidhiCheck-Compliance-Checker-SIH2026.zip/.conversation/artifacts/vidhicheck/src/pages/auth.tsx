import { useState } from 'react';
import { useLocation } from 'wouter';
import { ArrowRight, LockKeyhole, ShieldCheck } from 'lucide-react';

export function LoginPage() {
  const [, setLocation] = useLocation();
  const [officerId, setOfficerId] = useState('officer001');
  const [password, setPassword] = useState('vidhicheck123');
  const [error, setError] = useState('');
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (officerId === 'officer001' && password === 'vidhicheck123') {
      localStorage.setItem('vidhicheck-auth', 'true');
      setLocation('/dashboard');
    } else setError('Use the demo credentials shown below to continue.');
  };
  return <div className="paper-grid min-h-[100dvh] bg-[#e8eee8] text-foreground lg:grid lg:grid-cols-[1.05fr_.95fr]">
    <section className="relative hidden overflow-hidden bg-[hsl(var(--sidebar))] px-12 py-12 text-white lg:flex lg:flex-col lg:justify-between xl:px-20">
      <div className="absolute -right-20 top-24 h-80 w-80 rounded-full border border-[#d7b75b]/20" /><div className="absolute -right-8 top-36 h-56 w-56 rounded-full border border-[#d7b75b]/20" />
      <div className="flex items-center gap-3"><div className="grid h-10 w-10 place-items-center rounded-[13px] bg-[#d7b75b] text-[#1b3c3d]"><ShieldCheck size={21} strokeWidth={2.5} /></div><span className="text-[15px] font-extrabold tracking-[-.03em]">Vidhi<span className="text-[#d7b75b]">Check</span></span></div>
      <div className="relative max-w-lg"><p className="font-mono-ui text-[10px] uppercase tracking-[.22em] text-[#d7b75b]">Built for the last metre</p><h1 className="mt-5 text-5xl font-extrabold leading-[1.05] tracking-[-.06em] xl:text-6xl">A clearer label.<br /><span className="text-[#d7b75b]">A stronger record.</span></h1><p className="mt-6 max-w-md text-sm leading-7 text-white/60">Turn a package photograph into a defensible verification record, with the officer always in control of the decision.</p></div>
      <div className="flex items-end justify-between text-[10px] text-white/35"><span className="font-mono-ui uppercase tracking-[.16em]">Legal Metrology / India</span><span className="font-mono-ui">v1.0 · secure workspace</span></div>
    </section>
    <section className="flex min-h-[100dvh] items-center justify-center px-5 py-10 sm:px-10"><div className="w-full max-w-[420px] animate-rise-in">
      <div className="mb-10 flex items-center gap-3 lg:hidden"><div className="grid h-10 w-10 place-items-center rounded-[13px] bg-primary text-primary-foreground"><ShieldCheck size={21} /></div><span className="text-[15px] font-extrabold tracking-[-.03em]">Vidhi<span className="text-primary">Check</span></span></div>
      <p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">Officer workspace</p><h2 className="mt-3 text-3xl font-extrabold tracking-[-.05em]">Sign in to inspect.</h2><p className="mt-3 text-sm leading-6 text-muted-foreground">Your verification desk is ready when you are.</p>
      <form onSubmit={submit} className="mt-9 space-y-5"><label className="block"><span className="mb-2 block text-[11px] font-bold uppercase tracking-[.08em] text-foreground">Officer ID</span><input autoComplete="username" value={officerId} onChange={(e) => setOfficerId(e.target.value)} className="h-12 w-full rounded-xl border border-border bg-card px-4 text-sm outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/10" data-testid="input-officer-id" /></label><label className="block"><span className="mb-2 block text-[11px] font-bold uppercase tracking-[.08em] text-foreground">Passphrase</span><div className="relative"><input autoComplete="current-password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="h-12 w-full rounded-xl border border-border bg-card px-4 pr-11 text-sm outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/10" data-testid="input-password" /><LockKeyhole className="absolute right-4 top-3.5 text-muted-foreground" size={16} /></div></label>{error && <p className="rounded-lg bg-[#f7e3df] px-3 py-2 text-xs text-[#a33e32]" data-testid="status-login-error">{error}</p>}<button type="submit" className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary text-sm font-bold text-primary-foreground transition-transform hover:-translate-y-0.5" data-testid="button-login">Enter workspace <ArrowRight size={16} /></button></form>
      <div className="mt-7 rounded-xl border border-[#d9e5dd] bg-[#eef5ef] p-4"><p className="font-mono-ui text-[9px] uppercase tracking-[.16em] text-[#52806e]">Demo access</p><p className="mt-2 text-xs text-[#35564e]">officer001 <span className="mx-1 text-[#8ba499]">/</span> vidhicheck123</p></div>
      <p className="mt-8 text-center text-[10px] text-muted-foreground">Restricted to authorised Legal Metrology officers.</p>
    </div></section>
  </div>;
}