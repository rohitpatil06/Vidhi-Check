import { useRef, useState } from 'react';
import { useLocation } from 'wouter';
import { Camera, Check, FileImage, Info, Loader2, ScanLine, UploadCloud, X } from 'lucide-react';
import { useAnalyzeProduct, useCreateInspection } from '@workspace/api-client-react';
import { demoInspection, saveLocalInspection } from '@/lib/demo-data';
import { PageHeader, SectionLabel } from '@/components/app-shell';

export function ScanPage() {
  const [, setLocation] = useLocation();
  const inputRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState('');
  const [fileName, setFileName] = useState('');
  const [product, setProduct] = useState<'rice' | 'biscuits' | 'oil'>('rice');
  const analyze = useAnalyzeProduct();
  const create = useCreateInspection();
  const busy = analyze.isPending || create.isPending;
  const onFile = (file?: File) => { if (!file) return; setFileName(file.name); const reader = new FileReader(); reader.onload = () => setPreview(String(reader.result)); reader.readAsDataURL(file); };
  const runAnalysis = () => {
    analyze.mutate({ data: { imageData: preview || null, demoProduct: product } }, {
      onSuccess: (inspection) => { saveLocalInspection(inspection); setLocation(`/result/${inspection.id}`); },
      onError: () => {
        const fallback = { ...demoInspection, id: `VC-${Date.now().toString().slice(-5)}`, imageData: preview || null, product: product === 'rice' ? demoInspection.product : product === 'biscuits' ? 'Parle-G Biscuits · 800 g' : 'Fortune Sunflower Oil · 1 L' };
        create.mutate({ data: { product: fallback.product, status: fallback.status, score: fallback.score, declarations: fallback.declarations, checks: fallback.checks, violations: fallback.violations, ocrText: fallback.ocrText, imageData: fallback.imageData } }, { onSuccess: (inspection) => { saveLocalInspection(inspection); setLocation(`/result/${inspection.id}`); }, onError: () => { saveLocalInspection(fallback); setLocation(`/result/${fallback.id}`); } });
      },
    });
  };
  return <div><PageHeader eyebrow="New inspection" title="Read the package." description="Upload a clear label photograph. VidhiCheck will extract the declarations and map them to the relevant checks." />
    <div className="mx-auto max-w-5xl px-5 py-8 sm:px-8 lg:px-12 lg:py-10"><div className="grid gap-8 lg:grid-cols-[1fr_340px]">
      <section><div className={`relative flex min-h-[430px] flex-col items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed ${preview ? 'border-primary/40 bg-[#e6efea]' : 'border-[#bdcbc2] bg-[#f0f4ee]'} p-6 text-center transition-colors`}>
        {preview ? <><img src={preview} alt="Uploaded package label" className="max-h-[370px] max-w-full rounded-xl object-contain shadow-lg" data-testid="img-upload-preview" /><button onClick={() => { setPreview(''); setFileName(''); }} className="absolute right-4 top-4 grid h-8 w-8 place-items-center rounded-full bg-card/90 text-muted-foreground shadow" aria-label="Remove image" data-testid="button-remove-image"><X size={15} /></button></> : <><div className="mb-5 grid h-16 w-16 place-items-center rounded-2xl bg-card text-primary shadow-[0_5px_18px_rgba(48,65,57,.08)]"><UploadCloud size={27} strokeWidth={1.6} /></div><h2 className="text-lg font-bold tracking-[-.03em]">Drop a label photograph here</h2><p className="mt-2 max-w-xs text-xs leading-5 text-muted-foreground">Use the front or back of a packaged commodity. Text should be in focus and well lit.</p><div className="mt-6 flex gap-2"><button onClick={() => inputRef.current?.click()} className="inline-flex h-10 items-center gap-2 rounded-lg bg-primary px-4 text-xs font-bold text-primary-foreground" data-testid="button-choose-image"><FileImage size={15} /> Choose image</button><button onClick={() => inputRef.current?.click()} className="inline-flex h-10 items-center gap-2 rounded-lg border border-border bg-card px-4 text-xs font-bold text-foreground" data-testid="button-camera"><Camera size={15} /> Camera</button></div></>}<input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} data-testid="input-image" /></div>
        {fileName && <p className="mt-3 truncate font-mono-ui text-[10px] text-muted-foreground" data-testid="text-file-name">{fileName}</p>}
      </section>
      <aside className="space-y-4"><div className="rounded-2xl border border-card-border bg-card p-5"><SectionLabel>Demo product</SectionLabel><h2 className="mt-2 text-sm font-bold">Choose a label set</h2><p className="mt-1 text-xs leading-5 text-muted-foreground">Use a sample when testing the workflow without a photograph.</p><div className="mt-4 space-y-2">{[['rice', 'Sona Masoori Rice', '5 kg'], ['biscuits', 'Parle-G Biscuits', '800 g'], ['oil', 'Fortune Sunflower Oil', '1 L']].map(([value, name, size]) => <button key={value} onClick={() => setProduct(value as typeof product)} className={`flex w-full items-center justify-between rounded-xl border px-3 py-3 text-left transition-colors ${product === value ? 'border-primary bg-[#edf4ef]' : 'border-border hover:bg-muted/50'}`} data-testid={`button-product-${value}`}><span><span className="block text-xs font-bold">{name}</span><span className="mt-1 block font-mono-ui text-[9px] text-muted-foreground">{size}</span></span>{product === value && <span className="grid h-5 w-5 place-items-center rounded-full bg-primary text-primary-foreground"><Check size={12} /></span>}</button>)}</div></div><div className="rounded-2xl bg-[#f5edd7] p-5"><div className="flex items-center gap-2 text-[#795f21]"><Info size={15} /><span className="text-xs font-bold">For a dependable read</span></div><ul className="mt-3 space-y-2 text-[11px] leading-5 text-[#6b5a30]"><li>• Keep the full declaration panel in frame.</li><li>• Avoid glare across MRP and quantity.</li><li>• Officer verification remains the final call.</li></ul></div><button onClick={runAnalysis} disabled={busy} className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary text-xs font-bold text-primary-foreground transition-transform hover:-translate-y-0.5 disabled:cursor-wait disabled:opacity-60" data-testid="button-run-analysis">{busy ? <><Loader2 size={15} className="animate-spin" /> Reading label...</> : <><ScanLine size={16} /> Run label analysis</>}</button></aside>
    </div></div>
  </div>;
}