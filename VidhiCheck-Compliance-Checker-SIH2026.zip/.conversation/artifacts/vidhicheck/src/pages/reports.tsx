import { useEffect, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { ArrowDownToLine, CheckCircle2, FileText, Loader2, RefreshCw } from 'lucide-react';
import { useGenerateReport } from '@workspace/api-client-react';
import { demoInspection, getLocalInspection, makeLocalReport } from '@/lib/demo-data';
import { PageHeader, SectionLabel, StatusPill } from '@/components/app-shell';

function createPdfBytes(content: string): Uint8Array {
  const safeLines = content
    .replace(/\r/g, '')
    .split('\n')
    .map((line) => line.replace(/[^\x20-\x7E]/g, '?'));
  const escapePdf = (line: string) => line.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
  const stream = [
    'BT',
    '/F1 10 Tf',
    '50 760 Td',
    ...safeLines.flatMap((line) => [`(${escapePdf(line.slice(0, 105))}) Tj`, '0 -14 Td']),
    'ET',
  ].join('\n');
  let pdf = '%PDF-1.4\n';
  const offsets = [0];
  const addObject = (body: string) => {
    offsets.push(new TextEncoder().encode(pdf).length);
    pdf += `${offsets.length - 1} 0 obj\n${body}\nendobj\n`;
  };
  addObject('<< /Type /Catalog /Pages 2 0 R >>');
  addObject('<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
  addObject('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>');
  addObject('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');
  addObject(`<< /Length ${new TextEncoder().encode(stream).length} >>\nstream\n${stream}\nendstream`);
  const xrefOffset = new TextEncoder().encode(pdf).length;
  pdf += `xref\n0 ${offsets.length}\n0000000000 65535 f \n${offsets.slice(1).map((offset) => `${String(offset).padStart(10, '0')} 00000 n `).join('\n')}\ntrailer\n<< /Size ${offsets.length} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
  return new TextEncoder().encode(pdf);
}

export function ReportsPage() {
  const [location] = useLocation();
  const id = new URLSearchParams(location.split('?')[1] ?? '').get('id') ?? demoInspection.id;
  const inspection = getLocalInspection(id);
  const generate = useGenerateReport();
  const [report, setReport] = useState(() => { try { const value = localStorage.getItem('vidhicheck-report'); return value ? JSON.parse(value) as { id: string; fileName: string; content: string } : null; } catch { return null; } });
  useEffect(() => { if (!report && inspection) setReport(makeLocalReport(inspection.id, inspection)); }, [inspection, report]);
  const createReport = () => generate.mutate({ data: { id: inspection.id } }, { onSuccess: (data) => { setReport(data); localStorage.setItem('vidhicheck-report', JSON.stringify(data)); }, onError: () => { const local = makeLocalReport(inspection.id, inspection); setReport(local); localStorage.setItem('vidhicheck-report', JSON.stringify(local)); } });
  const download = () => { if (!report) return; const bytes = createPdfBytes(report.content); const blob = new Blob([bytes.buffer as ArrayBuffer], { type: 'application/pdf' }); const url = URL.createObjectURL(blob); const anchor = document.createElement('a'); anchor.href = url; anchor.download = report.fileName.endsWith('.pdf') ? report.fileName : `${report.fileName.replace(/\.[^.]+$/, '')}.pdf`; anchor.click(); URL.revokeObjectURL(url); };
  return <div><PageHeader eyebrow="Document centre" title="Reports" description="Presentation-ready verification records for your case file." action={<button onClick={createReport} disabled={generate.isPending} className="inline-flex h-10 items-center gap-2 rounded-xl bg-primary px-3 text-xs font-bold text-primary-foreground disabled:opacity-60" data-testid="button-refresh-report">{generate.isPending ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />} Generate latest</button>} /><div className="px-5 py-7 sm:px-8 lg:px-12 lg:py-9"><div className="grid gap-7 lg:grid-cols-[minmax(0,1fr)_310px]"><section className="overflow-hidden rounded-2xl border border-card-border bg-card"><div className="flex items-center gap-3 border-b border-border/70 px-5 py-4 sm:px-7"><div className="grid h-10 w-10 place-items-center rounded-xl bg-[#e8f1eb] text-primary"><FileText size={18} /></div><div><p className="text-sm font-bold">{report?.fileName ?? `vidhicheck-${inspection.id.toLowerCase()}.pdf`}</p><p className="mt-1 font-mono-ui text-[9px] text-muted-foreground">Generated from {inspection.id}</p></div><span className="ml-auto rounded-full bg-[#e1f0e8] px-2 py-1 font-mono-ui text-[9px] text-[#368266]">READY</span></div><div className="bg-[#f7f8f3] p-5 sm:p-8"><pre className="max-h-[540px] overflow-auto whitespace-pre-wrap rounded-xl border border-border/70 bg-card p-5 font-mono-ui text-[10px] leading-6 text-foreground/75 shadow-sm" data-testid="text-report-content">{report?.content ?? 'Your report will appear here after generation.'}</pre></div><div className="flex flex-wrap items-center justify-between gap-3 border-t border-border/70 px-5 py-4 sm:px-7"><p className="font-mono-ui text-[9px] uppercase tracking-[.1em] text-muted-foreground">PDF document · audit-safe copy</p><button onClick={download} disabled={!report} className="inline-flex h-10 items-center gap-2 rounded-lg bg-primary px-4 text-xs font-bold text-primary-foreground disabled:opacity-40" data-testid="button-download-report"><ArrowDownToLine size={15} /> Download report</button></div></section><aside className="space-y-5"><div className="rounded-2xl bg-[hsl(var(--sidebar))] p-6 text-white"><SectionLabel>Selected inspection</SectionLabel><h2 className="mt-3 text-lg font-extrabold leading-tight tracking-[-.03em]">{inspection.product}</h2><p className="mt-2 font-mono-ui text-[10px] text-white/50">{inspection.id}</p><div className="mt-6 flex items-center justify-between border-t border-white/10 pt-4"><span className="text-xs text-white/55">Final status</span><StatusPill status={inspection.finalStatus ?? inspection.status} /></div><div className="mt-3 flex items-center justify-between"><span className="text-xs text-white/55">Compliance score</span><span className="text-lg font-extrabold">{inspection.score}<small className="text-[10px] font-medium text-white/45"> /100</small></span></div></div><div className="rounded-2xl border border-card-border bg-card p-5"><div className="flex items-center gap-2 text-primary"><CheckCircle2 size={16} /><p className="text-xs font-bold">What is included</p></div><ul className="mt-4 space-y-3 text-xs text-muted-foreground"><li className="flex gap-2"><span className="text-primary">—</span> Extracted declarations and confidence</li><li className="flex gap-2"><span className="text-primary">—</span> Requirement-by-requirement checks</li><li className="flex gap-2"><span className="text-primary">—</span> Violations and applicable rules</li><li className="flex gap-2"><span className="text-primary">—</span> Officer decision and remarks</li></ul><Link href={`/result/${inspection.id}`} className="mt-5 inline-flex text-xs font-bold text-primary hover:underline" data-testid="link-open-result">Open full verification record →</Link></div></aside></div></div></div>;
}