import type { ReactNode } from 'react';
import { Link, useLocation } from 'wouter';
import { Activity, ClipboardCheck, FileText, History, Info, LogOut, ScanLine, ShieldCheck } from 'lucide-react';

const navItems = [
  { href: '/dashboard', label: 'Overview', icon: Activity },
  { href: '/scan', label: 'New inspection', icon: ScanLine },
  { href: '/history', label: 'Inspection history', icon: History },
  { href: '/reports', label: 'Reports', icon: FileText },
];

export function AppShell({ children }: { children: ReactNode }) {
  const [location, setLocation] = useLocation();
  const handleLogout = () => { localStorage.removeItem('vidhicheck-auth'); setLocation('/'); };
  return (
    <div className="min-h-[100dvh] bg-background lg:flex">
      <aside className="relative z-20 flex w-full shrink-0 flex-col bg-[hsl(var(--sidebar))] text-[hsl(var(--sidebar-foreground))] lg:min-h-[100dvh] lg:w-[252px]">
        <div className="flex items-center justify-between px-5 py-5 lg:block lg:px-6 lg:py-7">
          <Link href="/dashboard" className="flex items-center gap-3" data-testid="link-brand">
            <span className="grid h-10 w-10 place-items-center rounded-[13px] bg-[hsl(var(--sidebar-primary))] text-[hsl(var(--sidebar-primary-foreground))] shadow-sm"><ShieldCheck size={21} strokeWidth={2.5} /></span>
            <span><span className="block text-[15px] font-extrabold tracking-[-0.03em]">Vidhi<span className="text-[hsl(var(--sidebar-primary))]">Check</span></span><span className="mt-0.5 block font-mono-ui text-[9px] uppercase tracking-[0.18em] text-white/50">inspection desk</span></span>
          </Link>
          <div className="hidden lg:mt-12 lg:block">
            <p className="mb-3 px-3 font-mono-ui text-[9px] uppercase tracking-[0.2em] text-white/40">Workspace</p>
            <nav className="space-y-1">
              {navItems.map(({ href, label, icon: Icon }) => <Link key={href} href={href} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`} className={`flex items-center gap-3 rounded-xl px-3 py-3 text-[12px] font-semibold transition-colors ${location === href ? 'bg-white/[0.12] text-white' : 'text-white/65 hover:bg-white/[0.07] hover:text-white'}`}><Icon size={16} strokeWidth={1.8} /><span>{label}</span>{href === '/scan' && <span className="ml-auto rounded-md bg-[hsl(var(--sidebar-primary))] px-1.5 py-0.5 text-[9px] font-bold text-[hsl(var(--sidebar-primary-foreground))]">NEW</span>}</Link>)}
            </nav>
            <p className="mb-3 mt-10 px-3 font-mono-ui text-[9px] uppercase tracking-[0.2em] text-white/40">Reference</p>
            <Link href="/about" data-testid="link-nav-about" className={`flex items-center gap-3 rounded-xl px-3 py-3 text-[12px] font-semibold transition-colors ${location === '/about' ? 'bg-white/[0.12] text-white' : 'text-white/65 hover:bg-white/[0.07] hover:text-white'}`}><Info size={16} strokeWidth={1.8} /><span>About VidhiCheck</span></Link>
          </div>
          <button className="grid h-9 w-9 place-items-center rounded-lg text-white/60 hover:bg-white/10 hover:text-white lg:hidden" onClick={() => setLocation('/dashboard')} aria-label="Open dashboard" data-testid="button-mobile-dashboard"><Activity size={18} /></button>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-5 pb-4 lg:hidden">
          {navItems.map(({ href, label, icon: Icon }) => <Link key={href} href={href} data-testid={`link-mobile-nav-${label.toLowerCase().replaceAll(' ', '-')}`} className={`flex shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-[10px] font-semibold ${location === href ? 'bg-white/[0.12] text-white' : 'text-white/60'}`}><Icon size={13} />{label}</Link>)}
          <Link href="/about" data-testid="link-mobile-nav-about" className={`flex shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-[10px] font-semibold ${location === '/about' ? 'bg-white/[0.12] text-white' : 'text-white/60'}`}><Info size={13} />About</Link>
        </nav>
        <div className="hidden mt-auto px-6 pb-6 lg:block">
          <div className="mb-4 h-px bg-white/10" />
          <div className="flex items-center gap-3">
            <div className="grid h-8 w-8 place-items-center rounded-full bg-[#d5e5df] text-[11px] font-bold text-[#244746]">AM</div>
            <div className="min-w-0 flex-1"><p className="truncate text-[11px] font-bold">A. Mehta</p><p className="font-mono-ui text-[9px] text-white/45">Officer · Bengaluru</p></div>
            <button onClick={handleLogout} className="text-white/45 hover:text-white" aria-label="Log out" data-testid="button-logout"><LogOut size={15} /></button>
          </div>
        </div>
      </aside>
      <main className="min-w-0 flex-1">{children}</main>
    </div>
  );
}

export function PageHeader({ eyebrow, title, description, action }: { eyebrow: string; title: string; description?: string; action?: ReactNode }) {
  return <header className="flex flex-col gap-5 border-b border-border/80 px-5 py-7 sm:px-8 lg:flex-row lg:items-end lg:justify-between lg:px-12 lg:py-9"><div><p className="font-mono-ui text-[10px] font-medium uppercase tracking-[0.2em] text-primary">{eyebrow}</p><h1 className="mt-2 text-[27px] font-extrabold tracking-[-0.045em] text-foreground sm:text-[32px]">{title}</h1>{description && <p className="mt-2 max-w-2xl text-[13px] leading-6 text-muted-foreground">{description}</p>}</div>{action}</header>;
}

export function StatusPill({ status }: { status: string }) {
  const style = status === 'Compliant' || status === 'pass' ? 'bg-[#e1f0e8] text-[#1a6850]' : status === 'Non-Compliant' || status === 'fail' ? 'bg-[#f7e3df] text-[#a33e32]' : 'bg-[#fff0c9] text-[#7d5a09]';
  return <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 font-mono-ui text-[10px] font-medium ${style}`} data-testid={`status-${status.toLowerCase().replaceAll(' ', '-')}`}><span className="h-1.5 w-1.5 rounded-full bg-current" />{status}</span>;
}

export function SectionLabel({ children }: { children: ReactNode }) { return <p className="font-mono-ui text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{children}</p>; }