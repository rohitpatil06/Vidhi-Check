import { Router, type IRouter } from "express";
import healthRouter from "./health";
import inspectionsRouter from "./inspections";

const router: IRouter = Router();

router.use(healthRouter);
router.use(inspectionsRouter);

export default router;
