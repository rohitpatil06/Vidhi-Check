import { Router, type IRouter } from "express";
import {
  AnalyzeProductBody,
  CreateInspectionBody,
  GenerateReportBody,
  GetInspectionParams,
  VerifyInspectionBody,
} from "@workspace/api-zod";

type Status = "Compliant" | "Non-Compliant" | "Needs Verification";
type CheckStatus = "pass" | "fail" | "warning";

type Declaration = {
  field: string;
  label: string;
  value: string;
  confidence: number;
  status: CheckStatus;
};

type Check = {
  requirement: string;
  result: string;
  status: CheckStatus;
};

type Violation = {
  title: string;
  status: string;
  reason: string;
  rule: string;
};

type Inspection = {
  id: string;
  product: string;
  date: string;
  officer: string;
  status: Status;
  score: number;
  declarations: Declaration[];
  checks: Check[];
  violations: Violation[];
  ocrText: string;
  imageData: string | null;
  remarks: string;
  finalStatus: string | null;
};

const officer = "officer001";

function declarationsFor(kind: "rice" | "biscuits" | "oil"): Declaration[] {
  const base = [
    { field: "manufacturer", label: "Manufacturer", value: "ABC Foods Pvt. Ltd.", confidence: 0.98, status: "pass" as CheckStatus },
    { field: "net_quantity", label: "Net Quantity", value: kind === "oil" ? "1 L" : kind === "biscuits" ? "200 g" : "5 kg", confidence: kind === "oil" ? 0.77 : 0.99, status: kind === "oil" ? "warning" as CheckStatus : "pass" as CheckStatus },
    { field: "mrp", label: "MRP", value: kind === "oil" ? "₹165" : kind === "biscuits" ? "₹80" : "₹650", confidence: kind === "oil" ? 0.84 : 0.97, status: "pass" as CheckStatus },
    { field: "manufacturing_date", label: "Manufacturing Date", value: kind === "oil" ? "08/2026" : "08/2026", confidence: kind === "oil" ? 0.68 : 0.96, status: kind === "oil" ? "warning" as CheckStatus : "pass" as CheckStatus },
    { field: "consumer_care", label: "Consumer Care", value: kind === "biscuits" ? "Not detected" : "1800-XXX-XXXX", confidence: kind === "biscuits" ? 0.18 : 0.94, status: kind === "biscuits" ? "fail" as CheckStatus : "pass" as CheckStatus },
    { field: "country_of_origin", label: "Country of Origin", value: "India", confidence: kind === "oil" ? 0.72 : 0.95, status: kind === "oil" ? "warning" as CheckStatus : "pass" as CheckStatus },
  ];
  return base;
}

function makeInspection(
  id: string,
  kind: "rice" | "biscuits" | "oil",
  imageData: string | null = null,
): Inspection {
  const product = kind === "rice" ? "Premium Basmati Rice" : kind === "biscuits" ? "Packaged Biscuits" : "Cooking Oil";
  const declarations = declarationsFor(kind);
  const checks: Check[] = declarations.slice(0, 5).map((declaration) => ({
    requirement: declaration.label === "Consumer Care" ? "Consumer Care Details" : declaration.label,
    result: declaration.status === "pass" ? "Detected" : declaration.status === "fail" ? "Missing" : "Unclear",
    status: declaration.status,
  }));
  checks.push({ requirement: "Label Readability", result: kind === "oil" ? "Unclear" : "Clear", status: kind === "oil" ? "warning" : "pass" });
  const violations: Violation[] = kind === "biscuits"
    ? [{
        title: "Consumer Care Details Missing",
        status: "Non-Compliant",
        reason: "Required consumer care information was not detected on the uploaded label.",
        rule: "Mandatory declaration requirement",
      }]
    : kind === "oil"
      ? [{
          title: "Label requires officer review",
          status: "Needs Verification",
          reason: "Several declarations were detected with low OCR confidence.",
          rule: "Low-confidence OCR requires manual verification",
        }]
      : [];
  const score = kind === "rice" ? 92 : kind === "biscuits" ? 68 : 76;
  const status: Status = kind === "rice" ? "Compliant" : kind === "biscuits" ? "Non-Compliant" : "Needs Verification";
  return {
    id,
    product,
    date: "10 Sep 2026",
    officer,
    status,
    score,
    declarations,
    checks,
    violations,
    ocrText: `${product}\n${declarations.map((item) => `${item.label}: ${item.value}`).join("\n")}`,
    imageData,
    remarks: "",
    finalStatus: null,
  };
}

const inspections: Inspection[] = [
  makeInspection("VC-001", "rice"),
  makeInspection("VC-002", "biscuits"),
  { ...makeInspection("VC-003", "oil"), date: "09 Sep 2026" },
];

const router: IRouter = Router();

router.get("/dashboard", (_req, res) => {
  res.json({
    total: 128,
    compliant: 82,
    nonCompliant: 31,
    needsVerification: 15,
    recent: inspections,
  });
});

router.get("/inspections", (_req, res) => {
  res.json(inspections);
});

router.get("/inspections/:id", (req, res) => {
  const { id } = GetInspectionParams.parse(req.params);
  const inspection = inspections.find((item) => item.id === id);
  if (!inspection) {
    res.status(404).json({ error: "Inspection not found" });
    return;
  }
  res.json(inspection);
});

router.post("/analyze", (req, res) => {
  const body = AnalyzeProductBody.parse(req.body);
  const id = `VC-${String(inspections.length + 1).padStart(3, "0")}`;
  const inspection = makeInspection(id, body.demoProduct ?? "rice", body.imageData ?? null);
  inspections.unshift(inspection);
  res.json(inspection);
});

router.post("/inspections", (req, res) => {
  const body = CreateInspectionBody.parse(req.body);
  const inspection: Inspection = {
    ...body,
    status: body.status as Status,
    id: `VC-${String(inspections.length + 1).padStart(3, "0")}`,
    date: "10 Sep 2026",
    officer,
    remarks: "",
    finalStatus: null,
  };
  inspections.unshift(inspection);
  res.status(201).json(inspection);
});

router.post("/verify", (req, res) => {
  const body = VerifyInspectionBody.parse(req.body);
  const inspection = inspections.find((item) => item.id === body.id);
  if (!inspection) {
    res.status(404).json({ error: "Inspection not found" });
    return;
  }
  inspection.remarks = body.remarks;
  inspection.finalStatus = body.decision === "confirm" ? "Non-Compliant" : body.decision === "reject" ? "Compliant" : "Needs Verification";
  inspection.status = inspection.finalStatus as Status;
  res.json(inspection);
});

router.post("/report", (req, res) => {
  const body = GenerateReportBody.parse(req.body);
  const inspection = inspections.find((item) => item.id === body.id);
  if (!inspection) {
    res.status(404).json({ error: "Inspection not found" });
    return;
  }
  const content = [
    "VIDHICHECK",
    "Compliance Inspection Report",
    "",
    `Inspection ID: ${inspection.id}`,
    `Date: ${inspection.date}`,
    `Officer: ${inspection.officer}`,
    `Product: ${inspection.product}`,
    `Status: ${inspection.finalStatus ?? inspection.status}`,
    `Compliance Score: ${inspection.score}/100`,
    "",
    "Extracted Declarations",
    ...inspection.declarations.map((item) => `- ${item.label}: ${item.value} (${item.confidence}% confidence)`),
    "",
    "Detected Violations",
    ...(inspection.violations.length ? inspection.violations.map((item) => `- ${item.title}: ${item.reason}`) : ["- None"]),
    "",
    `Officer Remarks: ${inspection.remarks || "Not provided"}`,
    "",
    "Generated by VidhiCheck — AI-assisted compliance analysis",
  ].join("\n");
  res.json({ id: inspection.id, fileName: `vidhicheck-${inspection.id}.pdf`, content });
});

export default router;