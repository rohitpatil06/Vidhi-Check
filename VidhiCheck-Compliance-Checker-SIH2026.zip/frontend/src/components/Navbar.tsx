import React from 'react';
import { Shield, CheckCircle2, AlertCircle, Sparkles } from 'lucide-react';

interface NavbarProps {
  isBackendOnline: boolean;
  officerId: string;
}

export const Navbar: React.FC<NavbarProps> = ({ isBackendOnline, officerId }) => {
  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-gov-200 bg-white/95 px-4 backdrop-blur sm:px-6">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gov-900 text-white shadow-sm">
          <Shield className="h-5 w-5" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-bold tracking-tight text-gov-900 text-lg">VIDHICHECK</span>
            <span className="rounded-full bg-gov-100 px-2 py-0.5 text-[11px] font-semibold text-gov-700">SIH 2026</span>
          </div>
          <p className="text-xs text-gov-500 font-medium">Scan. Verify. Comply.</p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Backend connectivity indicator */}
        <div 
          className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium border ${
            isBackendOnline 
              ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
              : 'bg-amber-50 text-amber-800 border-amber-200'
          }`}
          title={isBackendOnline ? 'Connected to FastAPI Backend on port 8000' : 'Backend offline — Running in Standalone Demo Mode'}
        >
          {isBackendOnline ? (
            <>
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span>FastAPI Online</span>
            </>
          ) : (
            <>
              <Sparkles className="h-3 w-3 text-amber-600" />
              <span>Demo Mode</span>
            </>
          )}
        </div>

        {/* Officer pill */}
        <div className="hidden sm:flex items-center gap-2 rounded-lg border border-gov-200 bg-gov-50 px-3 py-1.5 text-xs text-gov-700">
          <div className="h-2 w-2 rounded-full bg-gov-400"></div>
          <span>Officer: <strong className="text-gov-900 font-semibold">{officerId}</strong></span>
        </div>
      </div>
    </header>
  );
};
