import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  ScanLine, 
  History, 
  FileText, 
  Info, 
  LogOut, 
  UserCheck,
  Scale,
  Building2
} from 'lucide-react';

interface SidebarProps {
  officerId: string;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ officerId, onLogout }) => {
  const navigate = useNavigate();

  const navItems = [
    { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/scan', label: 'Scan Product', icon: ScanLine },
    { to: '/history', label: 'Inspections', icon: History },
    { to: '/reports', label: 'Reports', icon: FileText },
    { to: '/rules', label: 'Statutory Rules', icon: Scale },
    { to: '/about', label: 'About', icon: Info },
  ];

  return (
    <aside className="w-64 flex-shrink-0 border-r border-gov-200 bg-white flex flex-col justify-between h-[calc(100vh-4rem)] sticky top-16">
      {/* Upper Navigation */}
      <div className="p-4 space-y-6">
        <div className="px-3 py-2 bg-gov-50 rounded-lg border border-gov-200/70">
          <div className="flex items-center gap-2 text-xs font-semibold text-gov-700 uppercase tracking-wider">
            <Building2 className="w-3.5 h-3.5 text-gov-500" />
            <span>Legal Metrology</span>
          </div>
          <p className="text-[11px] text-gov-500 mt-0.5">Government of India Portal</p>
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-gov-900 text-white shadow-sm'
                      : 'text-gov-600 hover:bg-gov-100 hover:text-gov-900'
                  }`
                }
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </nav>
      </div>

      {/* Bottom Officer Profile & Logout */}
      <div className="p-4 border-t border-gov-200 space-y-3">
        <div className="flex items-center gap-3 px-3 py-2 rounded-lg bg-gov-50 border border-gov-200">
          <div className="w-8 h-8 rounded-full bg-gov-200 flex items-center justify-center text-gov-700">
            <UserCheck className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-gov-900 truncate">Officer Portal</p>
            <p className="text-[11px] text-gov-500 truncate">ID: {officerId}</p>
          </div>
        </div>

        <button
          onClick={onLogout}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-red-600 hover:bg-red-50 rounded-lg border border-transparent hover:border-red-200 transition-colors"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
};
