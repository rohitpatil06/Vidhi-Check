import React, { useState } from 'react';
import { BoundingBox, DeclarationItem } from '../data/demoData';
import { Eye, EyeOff, Layers, Sparkles } from 'lucide-react';

interface AnnotatedImageProps {
  imageData?: string | null;
  productName: string;
  boxes: BoundingBox[];
  declarations: DeclarationItem[];
}

export const AnnotatedImage: React.FC<AnnotatedImageProps> = ({
  imageData,
  productName,
  boxes,
  declarations
}) => {
  const [showBoxes, setShowBoxes] = useState<boolean>(true);
  const [activeBox, setActiveBox] = useState<string | null>(null);

  const getBorderColor = (color: string) => {
    switch (color) {
      case 'green': return 'border-emerald-500 bg-emerald-500/10 text-emerald-900';
      case 'red': return 'border-red-500 bg-red-500/15 text-red-900';
      case 'yellow': return 'border-amber-500 bg-amber-500/15 text-amber-900';
      default: return 'border-blue-500 bg-blue-500/10 text-blue-900';
    }
  };

  const getBadgeColor = (color: string) => {
    switch (color) {
      case 'green': return 'bg-emerald-600 text-white';
      case 'red': return 'bg-red-600 text-white';
      case 'yellow': return 'bg-amber-500 text-white';
      default: return 'bg-gov-800 text-white';
    }
  };

  return (
    <div className="rounded-xl border border-gov-200 bg-white p-4 shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="text-sm font-bold text-gov-900">Annotated Label Analysis</h3>
          <p className="text-xs text-gov-500">Optical Detection & Bounding Box Regions</p>
        </div>

        <button
          type="button"
          onClick={() => setShowBoxes(!showBoxes)}
          className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md border border-gov-300 hover:bg-gov-50 text-gov-700 transition-colors"
        >
          {showBoxes ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
          <span>{showBoxes ? 'Hide Overlays' : 'Show Overlays'}</span>
        </button>
      </div>

      {/* Main Image Stage */}
      <div className="relative aspect-[4/3] w-full rounded-lg overflow-hidden border border-gov-200 bg-gov-100 flex items-center justify-center">
        {imageData ? (
          <img
            src={imageData}
            alt={productName}
            className="w-full h-full object-contain"
          />
        ) : (
          /* Simulated high-fidelity packaged label graphic */
          <div className="w-full h-full bg-gradient-to-br from-gov-50 to-gov-200 p-6 flex flex-col justify-between select-none">
            <div className="flex justify-between items-start border-b border-gov-300 pb-2">
              <div>
                <span className="text-[10px] font-bold tracking-wider text-gov-500 uppercase">Commodity Label Preview</span>
                <p className="text-base font-bold text-gov-900">{productName}</p>
              </div>
              <span className="text-xs font-mono font-bold bg-gov-800 text-white px-2 py-0.5 rounded">ORIGINAL</span>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs font-mono text-gov-800 my-auto py-2">
              <div className="bg-white/80 p-2.5 rounded border border-gov-200">
                <span className="text-[10px] text-gov-500 block font-sans">NET QUANTITY</span>
                <span className="font-bold">{declarations.find(d => d.field === 'net_quantity')?.value || '5 kg'}</span>
              </div>
              <div className="bg-white/80 p-2.5 rounded border border-gov-200">
                <span className="text-[10px] text-gov-500 block font-sans">MAX. RETAIL PRICE</span>
                <span className="font-bold">{declarations.find(d => d.field === 'mrp')?.value || '₹650.00'}</span>
              </div>
              <div className="bg-white/80 p-2.5 rounded border border-gov-200 col-span-2">
                <span className="text-[10px] text-gov-500 block font-sans">MANUFACTURED & PACKED BY</span>
                <span className="font-medium text-[11px] truncate block">{declarations.find(d => d.field === 'manufacturer')?.value || 'ABC Foods Pvt. Ltd.'}</span>
              </div>
              <div className="bg-white/80 p-2.5 rounded border border-gov-200 col-span-2 flex justify-between">
                <div>
                  <span className="text-[10px] text-gov-500 block font-sans">MFG DATE</span>
                  <span className="font-semibold">{declarations.find(d => d.field === 'manufacturing_date')?.value || '08/2026'}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-gov-500 block font-sans">CONSUMER HELPLINE</span>
                  <span className="font-semibold">{declarations.find(d => d.field === 'consumer_care')?.value || '1800-202-6000'}</span>
                </div>
              </div>
            </div>

            <div className="text-[9px] text-gov-500 text-center border-t border-gov-300 pt-1">
              Legal Metrology Standard Declaration Format &bull; Rule 6(1)
            </div>
          </div>
        )}

        {/* Dynamic Bounding Boxes Overlay */}
        {showBoxes && boxes.map((box, idx) => (
          <div
            key={idx}
            style={{
              left: `${box.x}%`,
              top: `${box.y}%`,
              width: `${box.width}%`,
              height: `${box.height}%`,
            }}
            onMouseEnter={() => setActiveBox(box.field)}
            onMouseLeave={() => setActiveBox(null)}
            className={`absolute border-2 rounded transition-all cursor-pointer ${getBorderColor(box.color)} ${
              activeBox === box.field ? 'ring-2 ring-gov-900 ring-offset-1 z-20' : 'z-10'
            }`}
          >
            <span className={`absolute -top-3 left-1 text-[9px] font-bold px-1.5 py-0.5 rounded shadow-xs whitespace-nowrap ${getBadgeColor(box.color)}`}>
              {box.label}
            </span>
          </div>
        ))}
      </div>

      {/* Legend */}
      <div className="mt-3 flex items-center justify-between text-xs border-t border-gov-100 pt-2.5">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            <span className="text-gov-600">Valid Declaration</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500"></span>
            <span className="text-gov-600">Possible Violation</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            <span className="text-gov-600">Needs Verification</span>
          </div>
        </div>
        <span className="text-[11px] text-gov-400">Hover box to highlight</span>
      </div>
    </div>
  );
};
