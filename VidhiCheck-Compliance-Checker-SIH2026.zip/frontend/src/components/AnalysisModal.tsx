import React, { useEffect, useState } from 'react';
import { Check, Loader2, ShieldAlert, Cpu } from 'lucide-react';

interface AnalysisModalProps {
  isOpen: boolean;
  onComplete: () => void;
}

const STEPS = [
  "Image Processing",
  "Detecting Label",
  "Extracting Text",
  "Identifying Declarations",
  "Checking Legal Metrology Rules",
  "Generating Compliance Result"
];

export const AnalysisModal: React.FC<AnalysisModalProps> = ({ isOpen, onComplete }) => {
  const [currentStep, setCurrentStep] = useState<number>(0);

  useEffect(() => {
    if (!isOpen) {
      setCurrentStep(0);
      return;
    }

    // Progress through the 6 steps sequentially
    const stepDuration = 350; // ms per step
    const interval = setInterval(() => {
      setCurrentStep((prev) => {
        if (prev < STEPS.length - 1) {
          return prev + 1;
        } else {
          clearInterval(interval);
          setTimeout(() => {
            onComplete();
          }, 350);
          return prev;
        }
      });
    }, stepDuration);

    return () => clearInterval(interval);
  }, [isOpen, onComplete]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl border border-gov-200 animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center gap-3 mb-5 border-b border-gov-100 pb-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gov-900 text-white">
            <Cpu className="h-5 w-5 animate-pulse" />
          </div>
          <div>
            <h3 className="text-base font-bold text-gov-900">VidhiCheck AI Engine</h3>
            <p className="text-xs text-gov-500">Executing Packaged Commodity Verification</p>
          </div>
        </div>

        <div className="space-y-3.5 my-4">
          {STEPS.map((step, idx) => {
            const isFinished = idx < currentStep;
            const isCurrent = idx === currentStep;

            return (
              <div 
                key={step} 
                className={`flex items-center justify-between p-2.5 rounded-lg border text-xs transition-all duration-300 ${
                  isFinished
                    ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900 font-medium'
                    : isCurrent
                    ? 'bg-blue-50/80 border-blue-300 text-blue-900 font-semibold shadow-xs'
                    : 'bg-gov-50/50 border-gov-200/60 text-gov-400'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] bg-white border border-current">
                    {idx + 1}
                  </span>
                  <span>{step}</span>
                </div>

                <div>
                  {isFinished && (
                    <div className="flex items-center gap-1 text-emerald-600 font-bold">
                      <span>✓</span>
                    </div>
                  )}
                  {isCurrent && (
                    <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Progress bar */}
        <div className="mt-5 pt-3 border-t border-gov-100">
          <div className="flex justify-between text-[11px] text-gov-500 mb-1.5 font-medium">
            <span>Overall Verification Progress</span>
            <span>{Math.round(((currentStep + 1) / STEPS.length) * 100)}%</span>
          </div>
          <div className="h-2 w-full bg-gov-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gov-900 transition-all duration-300 rounded-full"
              style={{ width: `${((currentStep + 1) / STEPS.length) * 100}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
