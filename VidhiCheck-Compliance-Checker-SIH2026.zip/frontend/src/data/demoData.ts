export interface DeclarationItem {
  field: string;
  label: string;
  value: string;
  confidence: number;
  status: 'pass' | 'warning' | 'fail';
}

export interface ComplianceCheck {
  requirement: string;
  result: string;
  status: 'COMPLIANT' | 'NON-COMPLIANT' | 'NEEDS VERIFICATION';
}

export interface ViolationItem {
  id?: string;
  title: string;
  status: string;
  reason: string;
  rule: string;
  severity?: string;
}

export interface BoundingBox {
  field: string;
  label: string;
  color: 'green' | 'red' | 'yellow';
  x: number; // percentage
  y: number;
  width: number;
  height: number;
}

export interface ScoreBreakdown {
  mandatory_declarations: number;
  format_checks: number;
  readability: number;
}

export interface Inspection {
  id: string;
  product: string;
  date: string;
  officer: string;
  status: 'Compliant' | 'Non-Compliant' | 'Needs Verification';
  score: number;
  breakdown: ScoreBreakdown;
  declarations: DeclarationItem[];
  checks: ComplianceCheck[];
  violations: ViolationItem[];
  bounding_boxes: BoundingBox[];
  ocr_text: string;
  image_data?: string | null;
  remarks: string;
  final_status?: string | null;
}

export interface DashboardStats {
  total: number;
  compliant: number;
  non_compliant: number;
  needs_verification: number;
  recent: Inspection[];
}

export const SAMPLE_PRODUCTS: Record<string, Inspection> = {
  sample_rice: {
    id: 'VC-001',
    product: 'Premium Basmati Rice',
    date: '2026-09-10',
    officer: 'officer001',
    status: 'Compliant',
    score: 96,
    breakdown: {
      mandatory_declarations: 98,
      format_checks: 95,
      readability: 95
    },
    declarations: [
      { field: 'product_name', label: 'Commodity Name', value: 'Premium Basmati Rice', confidence: 0.99, status: 'pass' },
      { field: 'manufacturer', label: 'Manufacturer / Packer', value: 'ABC Foods Pvt. Ltd., GT Road, Karnal - 132001', confidence: 0.96, status: 'pass' },
      { field: 'net_quantity', label: 'Net Quantity', value: '5 kg', confidence: 0.98, status: 'pass' },
      { field: 'mrp', label: 'Maximum Retail Price', value: '₹650.00 (Incl. of all taxes)', confidence: 0.97, status: 'pass' },
      { field: 'manufacturing_date', label: 'Date of Packing / Mfg', value: '08/2026', confidence: 0.96, status: 'pass' },
      { field: 'consumer_care', label: 'Consumer Care Helpline', value: '1800-202-6000, care@abcfoods.in', confidence: 0.98, status: 'pass' },
      { field: 'country_of_origin', label: 'Country of Origin', value: 'India', confidence: 0.99, status: 'pass' },
      { field: 'label_readability', label: 'Label Legibility & Visual Contrast', value: 'High optical contrast conforming to Rule 9(1)', confidence: 0.96, status: 'pass' },
    ],
    checks: [
      { requirement: 'Generic or Common Commodity Name (Rule 6(1)(b))', result: 'Detected: Premium Basmati Rice on principal display panel', status: 'COMPLIANT' },
      { requirement: 'Manufacturer / Packer Complete Address with PIN (Rule 6(1)(a) & Rule 10)', result: 'Detected: ABC Foods Pvt. Ltd., GT Road, Karnal - 132001', status: 'COMPLIANT' },
      { requirement: 'Net Quantity in Standard SI Metric Units (Rule 6(1)(c) & Rule 13)', result: 'Detected: 5 kg (Standard metric unit, no prohibited qualifiers)', status: 'COMPLIANT' },
      { requirement: 'Maximum Retail Price with Taxes Included (Rule 6(1)(e) & Rule 2(m))', result: 'Detected: ₹650.00 (Incl. of all taxes)', status: 'COMPLIANT' },
      { requirement: 'Month & Year of Packing/Manufacture (Rule 6(1)(d))', result: 'Detected: 08/2026 (Statutory MM/YYYY format)', status: 'COMPLIANT' },
      { requirement: 'Consumer Care / Grievance Redressal (Rule 6(2))', result: 'Detected: 1800-202-6000, care@abcfoods.in', status: 'COMPLIANT' },
      { requirement: 'Country of Origin (Rule 6(1)(a) Second Proviso)', result: 'Detected: Made in India', status: 'COMPLIANT' },
      { requirement: 'Minimum Numeral Height (Rule 7 & Table-I)', result: 'Compliant: > 500g requires min 4 mm (meets 4.5 mm font)', status: 'COMPLIANT' },
      { requirement: 'Clear Background Spacing around Quantity (Rule 8)', result: 'Compliant: Adequate free space above, below and sides', status: 'COMPLIANT' },
      { requirement: 'Conspicuous Legibility & Contrast (Rule 9(1))', result: 'Detected: High contrast dark typography on light background', status: 'COMPLIANT' },
      { requirement: 'Standard Pack Size Conformity (Rule 5 & Second Schedule)', result: 'Compliant: 5 kg is a prescribed standard quantity for Cereals/Rice', status: 'COMPLIANT' },
    ],
    violations: [],
    bounding_boxes: [
      { field: 'product_name', label: 'Commodity: Basmati Rice', color: 'green', x: 18, y: 14, width: 64, height: 12 },
      { field: 'net_quantity', label: 'Net Qty: 5 kg', color: 'green', x: 15, y: 32, width: 32, height: 10 },
      { field: 'mrp', label: 'MRP ₹650', color: 'green', x: 55, y: 32, width: 32, height: 10 },
      { field: 'manufacturer', label: 'ABC Foods Pvt. Ltd.', color: 'green', x: 15, y: 48, width: 70, height: 14 },
      { field: 'consumer_care', label: 'Care: 1800-202-6000', color: 'green', x: 15, y: 70, width: 70, height: 12 },
    ],
    ocr_text: 'PREMIUM BASMATI RICE | NET QTY: 5 kg | MRP ₹650.00 (INCL. OF ALL TAXES) | MFG DATE: 08/2026 | PACKED BY ABC FOODS PVT LTD, GT ROAD, KARNAL - 132001 | CARE: 1800-202-6000 | MADE IN INDIA',
    image_data: null,
    remarks: 'Verified against physical label. All 11 statutory declarations conform to The Legal Metrology (Packaged Commodities) Rules, 2011.',
    final_status: 'Compliant'
  },

  sample_biscuit: {
    id: 'VC-002',
    product: 'Packaged Biscuits',
    date: '2026-09-10',
    officer: 'officer001',
    status: 'Non-Compliant',
    score: 62,
    breakdown: {
      mandatory_declarations: 65,
      format_checks: 70,
      readability: 60
    },
    declarations: [
      { field: 'product_name', label: 'Commodity Name', value: 'Choco Delight Biscuits', confidence: 0.98, status: 'pass' },
      { field: 'manufacturer', label: 'Manufacturer / Packer', value: 'Sun Bakers Ltd., Plot 12, Phase-II Ind. Area, Mumbai - 400072', confidence: 0.91, status: 'pass' },
      { field: 'net_quantity', label: 'Net Quantity', value: '200 g', confidence: 0.95, status: 'pass' },
      { field: 'mrp', label: 'Maximum Retail Price', value: '₹40.00 (Taxes included)', confidence: 0.94, status: 'pass' },
      { field: 'manufacturing_date', label: 'Date of Packing / Mfg', value: '07/2026', confidence: 0.92, status: 'pass' },
      { field: 'consumer_care', label: 'Consumer Care Helpline', value: 'Missing / Not Found', confidence: 0.00, status: 'fail' },
      { field: 'country_of_origin', label: 'Country of Origin', value: 'India', confidence: 0.97, status: 'pass' },
      { field: 'label_readability', label: 'Label Legibility & Visual Contrast', value: 'Standard contrast', confidence: 0.92, status: 'pass' },
    ],
    checks: [
      { requirement: 'Generic or Common Commodity Name (Rule 6(1)(b))', result: 'Detected: Choco Delight Biscuits', status: 'COMPLIANT' },
      { requirement: 'Manufacturer Details & PIN (Rule 6(1)(a) & Rule 10)', result: 'Detected: Sun Bakers Ltd., Mumbai - 400072', status: 'COMPLIANT' },
      { requirement: 'Net Quantity in Standard Units (Rule 6(1)(c) & Rule 13)', result: 'Detected: 200 g (SI metric unit)', status: 'COMPLIANT' },
      { requirement: 'Maximum Retail Price (MRP) (Rule 6(1)(e) & Rule 2(m))', result: 'Detected: ₹40.00 (Taxes included)', status: 'COMPLIANT' },
      { requirement: 'Month & Year of Packing/Mfg (Rule 6(1)(d))', result: 'Detected: 07/2026', status: 'COMPLIANT' },
      { requirement: 'Consumer Care Details (Rule 6(2))', result: 'Missing: No helpline phone, email, or address found on label', status: 'NON-COMPLIANT' },
      { requirement: 'Country of Origin (Rule 6(1)(a) Second Proviso)', result: 'Detected: India', status: 'COMPLIANT' },
      { requirement: 'Minimum Numeral Height (Rule 7 & Table-I)', result: 'Compliant: 200g net weight requires min 1 mm (detected 2.1 mm)', status: 'COMPLIANT' },
      { requirement: 'Standard Pack Size Conformity (Rule 5 & Second Schedule)', result: 'Compliant: 200 g is a recognized pack size for Biscuits under Schedule 2', status: 'COMPLIANT' },
      { requirement: 'Conspicuous Legibility & Contrast (Rule 9(1))', result: 'Detected: Legible and prominent', status: 'COMPLIANT' },
    ],
    violations: [
      {
        id: 'V-01',
        title: 'Consumer Care Details Missing',
        status: 'Open',
        reason: 'Required statutory consumer care information (telephone number, email, or office address) was not detected on the uploaded label as mandated under Rule 6(2).',
        rule: 'The Legal Metrology (Packaged Commodities) Rules, 2011 — Rule 6(2)',
        severity: 'Critical'
      }
    ],
    bounding_boxes: [
      { field: 'product_name', label: 'Commodity Name: Biscuits', color: 'green', x: 16, y: 14, width: 68, height: 14 },
      { field: 'net_quantity', label: 'Net Qty: 200 g', color: 'green', x: 16, y: 34, width: 30, height: 10 },
      { field: 'mrp', label: 'MRP ₹40.00', color: 'green', x: 54, y: 34, width: 30, height: 10 },
      { field: 'manufacturer', label: 'Sun Bakers Ltd', color: 'green', x: 16, y: 50, width: 68, height: 14 },
      { field: 'consumer_care', label: 'Consumer Care: MISSING', color: 'red', x: 16, y: 72, width: 68, height: 14 },
    ],
    ocr_text: 'CHOCO DELIGHT BISCUITS | NET WT: 200 g | MRP ₹40.00 INCL ALL TAXES | MFG: 07/2026 | SUN BAKERS LTD, MUMBAI - 400072 | [NO CONSUMER HELPLINE LOCATED]',
    image_data: null,
    remarks: 'Consumer care contact information is entirely absent from the package. Statutory notice issued under Rule 6(2).',
    final_status: 'Non-Compliant'
  },

  sample_oil: {
    id: 'VC-003',
    product: 'Cooking Oil',
    date: '2026-09-09',
    officer: 'officer001',
    status: 'Needs Verification',
    score: 72,
    breakdown: {
      mandatory_declarations: 80,
      format_checks: 75,
      readability: 55
    },
    declarations: [
      { field: 'product_name', label: 'Commodity Name', value: 'Refined Sunflower Oil', confidence: 0.97, status: 'pass' },
      { field: 'manufacturer', label: 'Manufacturer / Packer', value: 'Gold Agro Oil Mills, [Address Partially Smudged]', confidence: 0.48, status: 'warning' },
      { field: 'net_quantity', label: 'Net Quantity', value: '1 L', confidence: 0.96, status: 'pass' },
      { field: 'mrp', label: 'Maximum Retail Price', value: '₹165.00', confidence: 0.94, status: 'pass' },
      { field: 'manufacturing_date', label: 'Date of Packing / Mfg', value: '06/2026', confidence: 0.91, status: 'pass' },
      { field: 'consumer_care', label: 'Consumer Care Helpline', value: '1800-419-5050', confidence: 0.95, status: 'pass' },
      { field: 'country_of_origin', label: 'Country of Origin', value: 'India', confidence: 0.96, status: 'pass' },
      { field: 'label_readability', label: 'Label Legibility & Visual Contrast', value: 'Low contrast on address panel (Confidence: 48%)', confidence: 0.48, status: 'warning' },
    ],
    checks: [
      { requirement: 'Generic or Common Commodity Name (Rule 6(1)(b))', result: 'Detected: Refined Sunflower Oil', status: 'COMPLIANT' },
      { requirement: 'Manufacturer Details & Complete Address (Rule 6(1)(a) & Rule 10)', result: 'Gold Agro Oil Mills — Address partially smudged / incomplete PIN', status: 'NEEDS VERIFICATION' },
      { requirement: 'Net Quantity in Standard Units (Rule 6(1)(c) & Rule 13)', result: 'Detected: 1 L (Standard SI volume)', status: 'COMPLIANT' },
      { requirement: 'Maximum Retail Price (MRP) (Rule 6(1)(e) & Rule 2(m))', result: 'Detected: ₹165.00 (Taxes included)', status: 'COMPLIANT' },
      { requirement: 'Month & Year of Packing/Mfg (Rule 6(1)(d))', result: 'Detected: 06/2026', status: 'COMPLIANT' },
      { requirement: 'Consumer Care Details (Rule 6(2))', result: 'Detected: 1800-419-5050', status: 'COMPLIANT' },
      { requirement: 'Country of Origin (Rule 6(1)(a) Second Proviso)', result: 'Detected: India', status: 'COMPLIANT' },
      { requirement: 'Minimum Numeral Height (Rule 7 & Table-I)', result: 'Compliant: 1 L volume requires min 4 mm numeral height', status: 'COMPLIANT' },
      { requirement: 'Label Readability & Optical Contrast (Rule 9(1))', result: 'Low optical contrast on packer address panel', status: 'NEEDS VERIFICATION' },
      { requirement: 'Standard Pack Size Conformity (Rule 5 & Second Schedule)', result: 'Compliant: 1 Litre is an approved pack size under Second Schedule', status: 'COMPLIANT' },
    ],
    violations: [
      {
        id: 'V-02',
        title: 'Packer Address Legibility Compromised',
        status: 'Review',
        reason: 'Registered packer address has low print contrast and OCR confidence (48%), requiring physical officer inspection under Rule 9(1) & Rule 10.',
        rule: 'The Legal Metrology (Packaged Commodities) Rules, 2011 — Rule 9(1) & Rule 10',
        severity: 'Minor'
      }
    ],
    bounding_boxes: [
      { field: 'product_name', label: 'Sunflower Oil', color: 'green', x: 18, y: 14, width: 64, height: 12 },
      { field: 'net_quantity', label: 'Net Vol: 1 L', color: 'green', x: 18, y: 32, width: 28, height: 10 },
      { field: 'mrp', label: 'MRP ₹165', color: 'green', x: 54, y: 32, width: 28, height: 10 },
      { field: 'manufacturer', label: 'Packer: Low OCR Confidence (48%)', color: 'yellow', x: 15, y: 48, width: 70, height: 18 },
      { field: 'consumer_care', label: 'Helpline: 1800-419-5050', color: 'green', x: 18, y: 72, width: 64, height: 12 },
    ],
    ocr_text: 'REFINED SUNFLOWER OIL | NET VOLUME: 1 LITRE | MRP ₹165.00 | PACKED: 06/2026 | GOLD AGRO OIL MILLS, PLOT ?? IND ESTATE | CARE: 1800-419-5050',
    image_data: null,
    remarks: '',
    final_status: null
  }
};

export const INITIAL_INSPECTIONS: Inspection[] = [
  SAMPLE_PRODUCTS.sample_rice,
  SAMPLE_PRODUCTS.sample_biscuit,
  SAMPLE_PRODUCTS.sample_oil
];
