import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { ScanPage } from './pages/ScanPage';
import { ResultPage } from './pages/ResultPage';
import { HistoryPage } from './pages/HistoryPage';
import { ReportsPage } from './pages/ReportsPage';
import { RulesPage } from './pages/RulesPage';
import { AboutPage } from './pages/AboutPage';
import { api } from './services/api';

interface LayoutProps {
  children: React.ReactNode;
  officerId: string;
  isBackendOnline: boolean;
  onLogout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, officerId, isBackendOnline, onLogout }) => {
  return (
    <div className="min-h-screen bg-gov-50 flex flex-col">
      <Navbar isBackendOnline={isBackendOnline} officerId={officerId} />
      <div className="flex flex-1">
        <Sidebar officerId={officerId} onLogout={onLogout} />
        <main className="flex-1 p-6 md:p-8 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
};

export function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('vidhicheck_auth') === 'true';
  });
  const [officerId, setOfficerId] = useState<string>(() => {
    return localStorage.getItem('vidhicheck_officer') || 'officer001';
  });
  const [isBackendOnline, setIsBackendOnline] = useState<boolean>(false);

  useEffect(() => {
    checkHealth();
    const interval = setInterval(checkHealth, 8000);
    return () => clearInterval(interval);
  }, []);

  const checkHealth = async () => {
    const online = await api.checkBackendHealth();
    setIsBackendOnline(online);
  };

  const handleLogin = (id: string) => {
    setIsAuthenticated(true);
    setOfficerId(id);
    localStorage.setItem('vidhicheck_auth', 'true');
    localStorage.setItem('vidhicheck_officer', id);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('vidhicheck_auth');
  };

  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/"
          element={
            isAuthenticated ? (
              <Navigate to="/dashboard" replace />
            ) : (
              <LoginPage onLogin={handleLogin} />
            )
          }
        />

        <Route
          path="/dashboard"
          element={
            isAuthenticated ? (
              <Layout officerId={officerId} isBackendOnline={isBackendOnline} onLogout={handleLogout}>
                <DashboardPage />
              </Layout>
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        <Route
          path="/scan"
          element={
            isAuthenticated ? (
              <Layout officerId={officerId} isBackendOnline={isBackendOnline} onLogout={handleLogout}>
                <ScanPage />
              </Layout>
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        <Route
          path="/result/:id"
          element={
            isAuthenticated ? (
              <Layout officerId={officerId} isBackendOnline={isBackendOnline} onLogout={handleLogout}>
                <ResultPage />
              </Layout>
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        <Route
          path="/history"
          element={
            isAuthenticated ? (
              <Layout officerId={officerId} isBackendOnline={isBackendOnline} onLogout={handleLogout}>
                <HistoryPage />
              </Layout>
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        <Route
          path="/reports"
          element={
            isAuthenticated ? (
              <Layout officerId={officerId} isBackendOnline={isBackendOnline} onLogout={handleLogout}>
                <ReportsPage />
              </Layout>
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        <Route
          path="/rules"
          element={
            isAuthenticated ? (
              <Layout officerId={officerId} isBackendOnline={isBackendOnline} onLogout={handleLogout}>
                <RulesPage />
              </Layout>
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        <Route
          path="/about"
          element={
            isAuthenticated ? (
              <Layout officerId={officerId} isBackendOnline={isBackendOnline} onLogout={handleLogout}>
                <AboutPage />
              </Layout>
            ) : (
              <Navigate to="/" replace />
            )
          }
        />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
