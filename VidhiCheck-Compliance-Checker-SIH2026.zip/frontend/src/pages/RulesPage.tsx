import React, { useState } from 'react';
import { 
  Scale, 
  BookOpen, 
  Calculator, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldAlert, 
  FileText, 
  Sparkles,
  Info,
  Layers,
  Search,
  Check,
  Package,
  HelpCircle
} from 'lucide-react';

export const RulesPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'tools' | 'rules' | 'schedules' | 'exemptions'>('tools');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Table-I / Table-II Calculator state
  const [calcType, setCalcType] = useState<'weight_volume' | 'area'>('weight_volume');
  const [calcValue, setCalcValue] = useState<number>(500);
  const [isBlown, setIsBlown] = useState<boolean>(false);

  // Second Schedule state
  const [selectedCommodity, setSelectedCommodity] = useState<string>('Biscuits');
  const [packCheckQty, setPackCheckQty] = useState<string>('200g');

  // First Schedule MPE state
  const [mpeQty, setMpeQty] = useState<number>(500);

  // Table I / Table II calculation logic
  const calculateNumeralHeight = () => {
    if (calcType === 'weight_volume') {
      // Table-I
      if (calcValue <= 200) {
        return {
          minHeight: isBlown ? 2.0 : 1.0,
          table: 'Table-I (Up to 200g / ml)',
          ruleCite: 'Rule 7(2)(i)',
          letterHeight: isBlown ? 2.0 : 1.0,
          bufferAboveBelow: isBlown ? 2.0 : 1.0,
          bufferSides: (isBlown ? 2.0 : 1.0) * 2
        };
      } else if (calcValue <= 500) {
        return {
          minHeight: isBlown ? 4.0 : 2.0,
          table: 'Table-I (Above 200g/ml up to 500g/ml)',
          ruleCite: 'Rule 7(2)(i)',
          letterHeight: isBlown ? 2.0 : 1.0,
          bufferAboveBelow: isBlown ? 4.0 : 2.0,
          bufferSides: (isBlown ? 4.0 : 2.0) * 2
        };
      } else {
        return {
          minHeight: isBlown ? 6.0 : 4.0,
          table: 'Table-I (Above 500g / ml)',
          ruleCite: 'Rule 7(2)(i)',
          letterHeight: isBlown ? 2.0 : 1.0,
          bufferAboveBelow: isBlown ? 6.0 : 4.0,
          bufferSides: (isBlown ? 6.0 : 4.0) * 2
        };
      }
    } else {
      // Table-II
      if (calcValue <= 100) {
        return {
          minHeight: isBlown ? 2.0 : 1.0,
          table: 'Table-II (Up to 100 cm²)',
          ruleCite: 'Rule 7(2)(ii)',
          letterHeight: isBlown ? 2.0 : 1.0,
          bufferAboveBelow: isBlown ? 2.0 : 1.0,
          bufferSides: (isBlown ? 2.0 : 1.0) * 2
        };
      } else if (calcValue <= 500) {
        return {
          minHeight: isBlown ? 4.0 : 2.0,
          table: 'Table-II (100 cm² to 500 cm²)',
          ruleCite: 'Rule 7(2)(ii)',
          letterHeight: isBlown ? 2.0 : 1.0,
          bufferAboveBelow: isBlown ? 4.0 : 2.0,
          bufferSides: (isBlown ? 4.0 : 2.0) * 2
        };
      } else if (calcValue <= 2500) {
        return {
          minHeight: isBlown ? 6.0 : 4.0,
          table: 'Table-II (500 cm² to 2500 cm²)',
          ruleCite: 'Rule 7(2)(ii)',
          letterHeight: isBlown ? 2.0 : 1.0,
          bufferAboveBelow: isBlown ? 6.0 : 4.0,
          bufferSides: (isBlown ? 6.0 : 4.0) * 2
        };
      } else {
        return {
          minHeight: 6.0,
          table: 'Table-II (Above 2500 cm²)',
          ruleCite: 'Rule 7(2)(ii)',
          letterHeight: isBlown ? 2.0 : 1.0,
          bufferAboveBelow: 6.0,
          bufferSides: 12.0
        };
      }
    }
  };

  const numeralCalc = calculateNumeralHeight();

  // First Schedule MPE Calculation logic
  const calculateMPE = (qty: number) => {
    if (qty <= 50) return { percent: 9.0, fixed: null, value: (qty * 0.09).toFixed(1) };
    if (qty <= 100) return { percent: null, fixed: 4.5, value: '4.5' };
    if (qty <= 200) return { percent: 4.5, fixed: null, value: (qty * 0.045).toFixed(1) };
    if (qty <= 300) return { percent: null, fixed: 9.0, value: '9.0' };
    if (qty <= 500) return { percent: 3.0, fixed: null, value: (qty * 0.03).toFixed(1) };
    if (qty <= 1000) return { percent: null, fixed: 15.0, value: '15.0' };
    if (qty <= 10000) return { percent: 1.5, fixed: null, value: (qty * 0.015).toFixed(1) };
    if (qty <= 15000) return { percent: null, fixed: 150.0, value: '150.0' };
    return { percent: 1.0, fixed: null, value: (qty * 0.01).toFixed(1) };
  };

  const mpeResult = calculateMPE(mpeQty);

  // Second Schedule standard pack sizes
  const schedule2Items: Record<string, string> = {
    'Biscuits': '25g, 50g, 75g, 100g, 150g, 200g, 250g, 300g and thereafter in multiples of 100g up to 1 kg',
    'Baby food': '100g, 200g, 300g, 400g, 500g, 600g, 700g, 800g, 900g, 1 kg, 2kg, 5 kg and 10 kg',
    'Weaning food': '100g, 200g, 300g, 400g, 500g, 600g, 700g, 800g, 900g, 1 kg, 2 kg, 5 kg and 10 kg',
    'Bread': '100g and thereafter in multiples of 100g',
    'Butter and margarine': '25g, 50g, 100g, 200g, 500g, 1 kg, 2 kg, 5 kg, and thereafter in multiples of 5 kg',
    'Cereals and Pulses': '100g, 200g, 500g, 1 kg, 2 kg, 5 kg and thereafter multiples of 5 kg',
    'Coffee': '25g, 50g, 100g, 200g, 250g, 500g, 1kg and thereafter in multiples of 1kg',
    'Tea': '25g, 50g, 100g, 125g, 250g, 500g, 1kg and thereafter in multiples of 1kg',
    'Edible Oils, Vanaspati, Ghee': '50g, 100g, 200g, 500g, 1 kg, 2 kg, 3 kg, 5 kg and thereafter in multiples of 5 kg (or equivalent volume in ml/liters)',
    'Milk Powder': 'Below 50g no restriction, 50g, 100g, 200g, 500g, 1 kg and thereafter in multiples of 500g',
    'Non-soapy detergents (powder)': 'Below 50g no restriction, 50g, 100g, 200g, 500g, 700g, 1kg, 1.5kg, 2 kg and thereafter in multiples of 1 kg',
    'Rice, flour, atta, rawa, suji': '100g, 200g, 500g, 1kg, 2kg, 5 kg and thereafter in multiples of 5 kg',
    'Salt': 'Below 50g in multiples of 10g, 50g, 100g, 200g, 500g, 750g, 1 kg, 2 kg, 5 kg and thereafter in multiples of 5 kg',
    'Laundry Soap': '50g, 75g, 100g, and thereafter in multiples of 50g',
    'Non-soapy detergent cakes/bars': '50g, 75g, 100g, 125g, 150g, 200g, 250g, 300g and thereafter in multiples of 100g',
    'Toilet Soap (cakes)': '25g, 50g, 75g, 100g, 125g, 150g and thereafter in multiples of 50g',
    'Aerated soft drinks & beverages': '65ml, 100ml, 125ml, 150ml, 200ml, 250ml, 300ml, 330ml (cans), 500ml, 750ml, 1L, 1.5L, 2L, 3L, 4L, 5L',
    'Mineral water and drinking water': '100ml, 150ml, 200ml, 250ml, 300ml, 500ml, 750ml, 1L, 1.5L, 2L, 3L, 4L, 5L',
    'Cement in bags': '1 kg, 2 kg, 5 kg, 10 kg, 20 kg, 25 kg, 40 kg (white cement) and 50 kg',
    'Paint, varnish, enamels': '50ml, 100ml, 200ml, 500ml, 1L, 2L, 3L, 4L, 5L and thereafter in multiples of 5L'
  };

  const statutoryChapters = [
    {
      num: 'Chapter I',
      title: 'Preliminary & Key Definitions (Rule 1 & 2)',
      sections: [
        { name: 'Rule 1: Short title & Commencement', text: 'These rules may be called The Legal Metrology (Packaged Commodities) Rules, 2011. Came into force on 1st April 2011.' },
        { name: 'Rule 2(d): Manufacturer Defined', text: 'Person or firm who produces, makes or manufactures, or puts/causes to be put their mark claiming commodity to be produced by them.' },
        { name: 'Rule 2(e): Maximum Permissible Error (MPE)', text: 'Error in deficiency which does not exceed limits specified in the First Schedule.' },
        { name: 'Rule 2(f): Net Quantity Defined', text: 'Quantity by weight, measure or number of commodity contained in a package, strictly excluding packaging or wrapper.' },
        { name: 'Rule 2(h): Principal Display Panel (PDP)', text: 'Total surface area of the package where required statutory information is grouped together.' },
        { name: 'Rule 2(m): Retail Sale Price / MRP', text: 'Printed as "Maximum or Max. retail price Rs/₹ ... inclusive of all taxes" or "MRP Rs/₹ ... incl., of all taxes". Fractions rounded off (<50 paise to preceding rupee; 50-95 paise to 50 paise).' },
        { name: 'Rule 2(r): Wholesale Package', text: 'Package containing retail packages for sale/distribution to intermediaries, or containing 10+ retail packages.' }
      ]
    },
    {
      num: 'Chapter II',
      title: 'Provisions for Packages Intended for Retail Sale (Rule 3 to 23)',
      sections: [
        { name: 'Rule 3: Applicability & Exemptions', text: 'Does not apply to packages > 25 kg or 25 litre (except cement and fertilizer up to 50 kg) or industrial/institutional consumers.' },
        { name: 'Rule 4: Regulation for Pre-packing', text: 'No person shall pre-pack or sell any commodity unless package bears securely affixed statutory declarations.' },
        { name: 'Rule 5: Recommended Standard Packages', text: 'Commodities specified in Second Schedule shall be packed in standard quantities, or bear prominent declaration: "Not a standard pack size under Legal Metrology Rules, 2011".' },
        { name: 'Rule 6(1)(a) & Rule 10: Manufacturer / Packer Details', text: 'Name and complete postal address with factory location, street, city, state and PIN code. Importer address required for foreign commodities.' },
        { name: 'Rule 6(1)(b): Generic Commodity Name', text: 'Common or generic name of commodity plainly declared on principal display panel.' },
        { name: 'Rule 6(1)(c) & Rule 13: Net Quantity & Standard SI Units', text: 'Net quantity in standard metric units (g, kg, ml, L, N, U). Use of dozen, score, gross prohibited under Rule 13(4).' },
        { name: 'Rule 6(1)(d): Month & Year of Manufacture/Packing', text: 'Month and year of manufacture or pre-packing expressed in words or numerals (e.g. 08/2026).' },
        { name: 'Rule 6(1)(e): Maximum Retail Price (MRP)', text: 'MRP inclusive of all taxes declared prominently in statutory format.' },
        { name: 'Rule 6(2): Consumer Care Grievance Redressal', text: 'Name, address, telephone number, and email address for consumer complaints.' },
        { name: 'Rule 6(3): Prohibition of Individual Stickers', text: 'Individual stickers prohibited for altering declarations, except for reducing MRP without obscuring original MRP.' },
        { name: 'Rule 7: Principal Display Panel & Numeral Height', text: 'Numerals must meet minimum height in Table-I (weight/vol) or Table-II (area). Letter height >= 1 mm (>= 2 mm blown/molded).' },
        { name: 'Rule 8: Free Space Around Quantity', text: 'Area surrounding net quantity must be free of text: above/below >= numeral height, sides >= 2x numeral height.' },
        { name: 'Rule 9: Manner of Declaration & Contrast', text: 'Legible, prominent, contrasting conspicuously with background. Specified in Hindi (Devanagari) or English.' },
        { name: 'Rule 11 & 12: General Quantity Provisions', text: 'Prohibits qualifiers like "approximate", "average", or "when packed" (unless permitted in Third Schedule).' },
        { name: 'Rule 18: Retail Sale Obligations', text: 'No sale above MRP. Obliteration, smudging, or alteration of price by retailers is punishable.' },
        { name: 'Rule 19, 20, 21: Inspection & Sample Testing', text: 'Empowers Legal Metrology Officers to inspect premises, draw samples (Fifth Schedule), test net quantity (Sixth Schedule), and seize non-conforming lots.' },
        { name: 'Rule 23: Deceptive Packages', text: 'Deceptive packages deliberately misleading consumers regarding quantity are liable for seizure.' }
      ]
    },
    {
      num: 'Chapter III to VII',
      title: 'Wholesale, Import/Export, Registration & Penalties (Rule 24 to 34)',
      sections: [
        { name: 'Rule 24: Wholesale Packages', text: 'Must declare manufacturer/importer address, commodity identity, and total number of retail packages or net quantity.' },
        { name: 'Rule 25: Export Packages', text: 'Export packages shall not be sold in India unless re-packed or re-labeled under Chapter II.' },
        { name: 'Rule 26: Exemptions', text: 'Exempts commodities <= 10g or <= 10ml, restaurant fast foods, DPCO 1995 drug formulations, and agricultural produce > 50kg.' },
        { name: 'Rule 27: Registration of Manufacturers & Packers', text: 'Mandatory application for registration to Director or Controller with fee of ₹500 within 90 days of commencement.' },
        { name: 'Rule 31: Advertisements', text: 'Advertisements mentioning price must declare net quantity in the same font size as retail price.' },
        { name: 'Rule 32: Penalty for Contravention', text: 'Fine of ₹4,000 for contraventions of rules 27 to 31; fine of ₹2,000 for any other contravention.' }
      ]
    }
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Header Banner */}
      <div className="border-b border-gov-200 pb-5">
        <div className="flex items-center gap-3 mb-2">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gov-900 text-white shadow-sm">
            <Scale className="h-6 w-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold tracking-tight text-gov-900">
                Legal Metrology Statutory Standards
              </h1>
              <span className="rounded-full bg-gov-100 text-gov-800 px-2.5 py-0.5 text-xs font-bold">
                G.S.R. 202(E)
              </span>
            </div>
            <p className="text-xs text-gov-500 font-medium">
              The Legal Metrology (Packaged Commodities) Rules, 2011 &bull; Comprehensive Statutory Reference &amp; Officer Tools
            </p>
          </div>
        </div>

        <p className="text-sm text-gov-700 mt-2 leading-relaxed">
          Official statutory rule specifications, interactive minimum numeral height calculators (Table I &amp; II), Second Schedule pack size lookup, and First Schedule Maximum Permissible Error (MPE) tolerances.
        </p>
      </div>

      {/* Mode Navigation Tabs */}
      <div className="flex rounded-xl bg-gov-100 p-1 border border-gov-200/80 max-w-xl">
        <button
          type="button"
          onClick={() => setActiveTab('tools')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
            activeTab === 'tools' ? 'bg-white text-gov-900 shadow-xs' : 'text-gov-600 hover:text-gov-900'
          }`}
        >
          <Calculator className="w-3.5 h-3.5 text-gov-700" />
          <span>Interactive Calculators</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('rules')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
            activeTab === 'rules' ? 'bg-white text-gov-900 shadow-xs' : 'text-gov-600 hover:text-gov-900'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5 text-gov-700" />
          <span>Rules Reference (1 to 34)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('schedules')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
            activeTab === 'schedules' ? 'bg-white text-gov-900 shadow-xs' : 'text-gov-600 hover:text-gov-900'
          }`}
        >
          <Layers className="w-3.5 h-3.5 text-gov-700" />
          <span>Schedules (I to VII)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('exemptions')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
            activeTab === 'exemptions' ? 'bg-white text-gov-900 shadow-xs' : 'text-gov-600 hover:text-gov-900'
          }`}
        >
          <CheckCircle2 className="w-3.5 h-3.5 text-gov-700" />
          <span>Rule 26 Exemptions</span>
        </button>
      </div>

      {/* Tab 1: Interactive Calculators */}
      {activeTab === 'tools' && (
        <div className="space-y-6">
          {/* Tool 1: Table-I & Table-II Numeral Height Calculator */}
          <div className="rounded-2xl border border-gov-200 bg-white p-6 shadow-xs space-y-5">
            <div className="border-b border-gov-100 pb-3 flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-gov-900 flex items-center gap-2">
                  <Calculator className="w-4 h-4 text-gov-900" />
                  Principal Display Panel Numeral &amp; Letter Height Calculator
                </h2>
                <p className="text-xs text-gov-500">
                  Calculates statutory minimum font height under Rule 7 Table-I &amp; Table-II and clear buffer area under Rule 8
                </p>
              </div>
              <span className="text-xs font-bold bg-gov-100 text-gov-800 px-2.5 py-1 rounded">
                Rule 7 &amp; 8
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Input side */}
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-gov-800 mb-1.5">
                    1. Measurement Basis
                  </label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setCalcType('weight_volume')}
                      className={`flex-1 py-2 px-3 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                        calcType === 'weight_volume'
                          ? 'bg-gov-900 text-white border-gov-900 shadow-xs'
                          : 'bg-gov-50 text-gov-700 border-gov-200 hover:bg-gov-100'
                      }`}
                    >
                      Weight / Volume (Table-I)
                    </button>
                    <button
                      type="button"
                      onClick={() => setCalcType('area')}
                      className={`flex-1 py-2 px-3 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                        calcType === 'area'
                          ? 'bg-gov-900 text-white border-gov-900 shadow-xs'
                          : 'bg-gov-50 text-gov-700 border-gov-200 hover:bg-gov-100'
                      }`}
                    >
                      PDP Area (Table-II)
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gov-800 mb-1">
                    {calcType === 'weight_volume' ? '2. Declared Net Quantity (g or ml)' : '2. Principal Display Panel Surface Area (cm²)'}
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min="1"
                      value={calcValue}
                      onChange={(e) => setCalcValue(Math.max(1, Number(e.target.value)))}
                      className="w-full rounded-xl border border-gov-300 p-2.5 text-sm font-semibold text-gov-900 focus:outline-none focus:border-gov-900 focus:ring-1 focus:ring-gov-900"
                    />
                    <span className="text-xs font-bold text-gov-600 bg-gov-100 px-3 py-2.5 rounded-xl border border-gov-200">
                      {calcType === 'weight_volume' ? 'g / ml' : 'cm²'}
                    </span>
                  </div>
                </div>

                {/* Packaging container method */}
                <div>
                  <label className="block text-xs font-bold text-gov-800 mb-1.5">
                    3. Printing / Fabrication Type
                  </label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setIsBlown(false)}
                      className={`flex-1 py-2 px-3 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                        !isBlown
                          ? 'bg-gov-900 text-white border-gov-900 shadow-xs'
                          : 'bg-gov-50 text-gov-700 border-gov-200 hover:bg-gov-100'
                      }`}
                    >
                      Normal Printed Case
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsBlown(true)}
                      className={`flex-1 py-2 px-3 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                        isBlown
                          ? 'bg-gov-900 text-white border-gov-900 shadow-xs'
                          : 'bg-gov-50 text-gov-700 border-gov-200 hover:bg-gov-100'
                      }`}
                    >
                      Blown / Molded / Embossed
                    </button>
                  </div>
                </div>
              </div>

              {/* Output Result Card */}
              <div className="rounded-xl border border-gov-200 bg-gov-50/70 p-5 flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-gov-500">
                      Statutory Minimum Specification
                    </span>
                    <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                      {numeralCalc.ruleCite}
                    </span>
                  </div>

                  <div className="mt-3 mb-4">
                    <span className="text-xs text-gov-500 block mb-1">Minimum Numeral Height:</span>
                    <div className="flex items-baseline gap-2">
                      <span className="text-4xl font-extrabold text-gov-900">{numeralCalc.minHeight}</span>
                      <span className="text-base font-bold text-gov-600">mm</span>
                    </div>
                    <p className="text-xs font-semibold text-gov-700 mt-1">
                      {numeralCalc.table}
                    </p>
                  </div>

                  <div className="space-y-2 border-t border-gov-200 pt-3 text-xs text-gov-700">
                    <div className="flex justify-between">
                      <span>Minimum Letter Height (Rule 7(3)):</span>
                      <strong className="text-gov-900">&ge; {numeralCalc.letterHeight} mm</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>Letter Width Specification:</span>
                      <strong className="text-gov-900">&ge; 1/3 of letter height</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>Rule 8 Clear Buffer (Above &amp; Below):</span>
                      <strong className="text-gov-900">&ge; {numeralCalc.bufferAboveBelow} mm</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>Rule 8 Clear Buffer (Left &amp; Right):</span>
                      <strong className="text-gov-900">&ge; {numeralCalc.bufferSides} mm (2x height)</strong>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-white rounded-lg border border-gov-200 text-[11px] text-gov-600">
                  <strong>Notice under Rule 7(3):</strong> Numeral '1' and letters 'i', 'I', 'l' are exempt from the 1/3 width restriction.
                </div>
              </div>
            </div>
          </div>

          {/* Tool 2: First Schedule MPE (Maximum Permissible Error) Calculator */}
          <div className="rounded-2xl border border-gov-200 bg-white p-6 shadow-xs space-y-5">
            <div className="border-b border-gov-100 pb-3 flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-gov-900 flex items-center gap-2">
                  <Scale className="w-4 h-4 text-gov-900" />
                  First Schedule Maximum Permissible Error (MPE) Calculator
                </h2>
                <p className="text-xs text-gov-500">
                  Calculates legal tolerance limits in excess and deficiency for net quantity under Rule 2(e) &amp; Rule 22
                </p>
              </div>
              <span className="text-xs font-bold bg-gov-100 text-gov-800 px-2.5 py-1 rounded">
                First Schedule
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-gov-800 mb-1">
                    Declared Net Quantity (g or ml)
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min="1"
                      value={mpeQty}
                      onChange={(e) => setMpeQty(Math.max(1, Number(e.target.value)))}
                      className="w-full rounded-xl border border-gov-300 p-2.5 text-sm font-semibold text-gov-900 focus:outline-none focus:border-gov-900"
                    />
                    <span className="text-xs font-bold text-gov-600 bg-gov-100 px-3 py-2.5 rounded-xl border border-gov-200">
                      g / ml
                    </span>
                  </div>
                </div>

                <div className="flex gap-2">
                  {[50, 100, 200, 500, 1000, 5000].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setMpeQty(preset)}
                      className={`py-1 px-2.5 text-xs font-semibold rounded-lg border cursor-pointer ${
                        mpeQty === preset ? 'bg-gov-900 text-white' : 'bg-gov-50 text-gov-700 hover:bg-gov-100'
                      }`}
                    >
                      {preset >= 1000 ? `${preset/1000}kg` : `${preset}g`}
                    </button>
                  ))}
                </div>
              </div>

              <div className="rounded-xl border border-blue-200 bg-blue-50/50 p-5 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-blue-900">Permissible Error Allowance</span>
                  <span className="text-[11px] font-bold text-blue-700 bg-blue-100 px-2 py-0.5 rounded">
                    First Schedule Table I
                  </span>
                </div>

                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-extrabold text-blue-950">&plusmn; {mpeResult.value}</span>
                  <span className="text-sm font-bold text-blue-800">g or ml</span>
                  {mpeResult.percent && (
                    <span className="text-xs text-blue-700">({mpeResult.percent}% of declared qty)</span>
                  )}
                  {mpeResult.fixed && (
                    <span className="text-xs text-blue-700">(Fixed statutory tolerance)</span>
                  )}
                </div>

                <p className="text-[11px] text-blue-800 leading-relaxed border-t border-blue-200/80 pt-2">
                  <strong>Statutory Provision:</strong> Any sample package with deficiency exceeding <strong>{mpeResult.value} g/ml</strong> constitutes an offense under Rule 19(4)(b) &amp; Rule 21(3).
                </p>
              </div>
            </div>
          </div>

          {/* Tool 3: Second Schedule Standard Pack Size Checker */}
          <div className="rounded-2xl border border-gov-200 bg-white p-6 shadow-xs space-y-5">
            <div className="border-b border-gov-100 pb-3 flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-gov-900 flex items-center gap-2">
                  <Package className="w-4 h-4 text-gov-900" />
                  Second Schedule Standard Pack Sizes Verifier
                </h2>
                <p className="text-xs text-gov-500">
                  Inspect mandatory prescribed quantities for 20 essential commodities under Rule 5
                </p>
              </div>
              <span className="text-xs font-bold bg-gov-100 text-gov-800 px-2.5 py-1 rounded">
                Second Schedule
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
              <div className="space-y-3">
                <label className="block text-xs font-bold text-gov-800">
                  Select Regulated Commodity:
                </label>
                <select
                  value={selectedCommodity}
                  onChange={(e) => setSelectedCommodity(e.target.value)}
                  className="w-full rounded-xl border border-gov-300 bg-white p-2.5 text-xs font-semibold text-gov-900 focus:outline-none focus:border-gov-900"
                >
                  {Object.keys(schedule2Items).map((name) => (
                    <option key={name} value={name}>{name}</option>
                  ))}
                </select>
              </div>

              <div className="md:col-span-2 rounded-xl border border-gov-200 bg-gov-50/70 p-5 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-gov-900">
                    Prescribed Standard Quantities for: <span className="text-blue-700">{selectedCommodity}</span>
                  </h3>
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                    Rule 5 Mandatory
                  </span>
                </div>
                <p className="text-xs font-mono text-gov-800 bg-white p-3 rounded-lg border border-gov-200 leading-relaxed">
                  {schedule2Items[selectedCommodity]}
                </p>
                <p className="text-[11px] text-gov-500 pt-1">
                  <strong>Rule 5 Proviso:</strong> If packed in any size other than prescribed above, the package must prominently bear the declaration: <em className="text-gov-800 font-semibold">'Not a standard pack size under the Legal Metrology (Packaged Commodities) Rules, 2011'</em>.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Chapter-by-Chapter Statutory Rules */}
      {activeTab === 'rules' && (
        <div className="space-y-6">
          <div className="relative">
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-gov-400">
              <Search className="h-4 w-4" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by rule number (e.g. Rule 6, Rule 10, Rule 18) or topic..."
              className="w-full rounded-xl border border-gov-300 bg-white py-2 pl-9 pr-3 text-xs text-gov-900 placeholder:text-gov-400 focus:border-gov-900 focus:outline-none"
            />
          </div>

          <div className="space-y-6">
            {statutoryChapters.map((ch, idx) => {
              const filteredSections = ch.sections.filter(s =>
                s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                s.text.toLowerCase().includes(searchQuery.toLowerCase())
              );

              if (searchQuery && filteredSections.length === 0) return null;

              return (
                <div key={idx} className="rounded-2xl border border-gov-200 bg-white p-6 shadow-xs space-y-4">
                  <div className="border-b border-gov-100 pb-3 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-gov-400">{ch.num}</span>
                      <h2 className="text-sm font-bold text-gov-900">{ch.title}</h2>
                    </div>
                    <span className="text-xs font-semibold text-gov-500 bg-gov-100 px-2 py-0.5 rounded">
                      Statutory Text
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                    {filteredSections.map((sec, sIdx) => (
                      <div key={sIdx} className="p-3.5 rounded-xl border border-gov-200 bg-gov-50/40 hover:bg-gov-50 transition-colors">
                        <strong className="text-xs font-bold text-gov-900 block mb-1">
                          {sec.name}
                        </strong>
                        <p className="text-xs text-gov-600 leading-relaxed">
                          {sec.text}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 3: Schedules Summary */}
      {activeTab === 'schedules' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-gov-200 bg-white p-6 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-gov-900">
              Statutory Schedules Overview (Schedules I through VII)
            </h2>
            <p className="text-xs text-gov-500">
              Appended to The Legal Metrology (Packaged Commodities) Rules, 2011
            </p>

            <div className="space-y-3 pt-2">
              <div className="p-4 rounded-xl border border-gov-200 bg-gov-50/50">
                <span className="text-xs font-bold text-gov-900 block mb-1">First Schedule [See Rule 2(e) &amp; Rule 22]</span>
                <p className="text-xs text-gov-600">
                  <strong>Maximum Permissible Errors (MPE):</strong> Table I specifies maximum errors in deficiency/excess for net quantities declared by weight or volume (up to 50g: 9%; 50-100g: 4.5g; 100-200g: 4.5%; 200-300g: 9g; 300-500g: 3%; 500-1000g: 15g; 1-10kg: 1.5%; 10-15kg: 150g; &gt; 15kg: 1%). Table II specifies MPE for length (2%), area (4%), and number (2%).
                </p>
              </div>

              <div className="p-4 rounded-xl border border-gov-200 bg-gov-50/50">
                <span className="text-xs font-bold text-gov-900 block mb-1">Second Schedule [See Rule 5]</span>
                <p className="text-xs text-gov-600">
                  <strong>Commodities to be packed in specified quantities:</strong> Regulates 19 commodities including baby food, biscuits, bread, cereals/pulses, tea, coffee, edible oil, milk powder, salt, soaps, soft drinks, cement, paints.
                </p>
              </div>

              <div className="p-4 rounded-xl border border-gov-200 bg-gov-50/50">
                <span className="text-xs font-bold text-gov-900 block mb-1">Third Schedule [See Rule 11(4)]</span>
                <p className="text-xs text-gov-600">
                  <strong>Declaration of quantity qualified by "When packed":</strong> Strictly limited to three commodities: 1. All kinds of Soaps; 2. Lotions; 3. Cream (other than cream of milk). All other packaged goods are prohibited from using "when packed".
                </p>
              </div>

              <div className="p-4 rounded-xl border border-gov-200 bg-gov-50/50">
                <span className="text-xs font-bold text-gov-900 block mb-1">Fourth Schedule [See Rule 12(2)]</span>
                <p className="text-xs text-gov-600">
                  <strong>Exceptions to weight/volume declaration rules:</strong> Commodities like electric wire (length or weight), aerosol products (weight), compressed gas (weight and equivalent volume), fruits (number or weight), garments (number).
                </p>
              </div>

              <div className="p-4 rounded-xl border border-gov-200 bg-gov-50/50">
                <span className="text-xs font-bold text-gov-900 block mb-1">Fifth Schedule [See Rule 19]</span>
                <p className="text-xs text-gov-600">
                  <strong>Manner of Selection of Sample Packages:</strong> Lot size less than 4,000 packages &rarr; Sample size = 32 packages. Lot size greater than 4,000 packages &rarr; Sample size = 80 packages.
                </p>
              </div>

              <div className="p-4 rounded-xl border border-gov-200 bg-gov-50/50">
                <span className="text-xs font-bold text-gov-900 block mb-1">Sixth Schedule [See Rule 19]</span>
                <p className="text-xs text-gov-600">
                  <strong>Testing equipment and determination of net quantity &amp; tare weight:</strong> Detailed testing protocol for determining gross weight, tare weight, liquid specific gravity, and actual net contents.
                </p>
              </div>

              <div className="p-4 rounded-xl border border-gov-200 bg-gov-50/50">
                <span className="text-xs font-bold text-gov-900 block mb-1">Seventh Schedule [Form A &amp; Form B]</span>
                <p className="text-xs text-gov-600">
                  <strong>Official Inspection Data Sheets:</strong> Form A (Weight Checking Data Sheet) and Form B (Volume / Length Checking Data Sheet) used by officers to record test results and signatures.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Rule 26 Statutory Exemptions */}
      {activeTab === 'exemptions' && (
        <div className="rounded-2xl border border-gov-200 bg-white p-6 shadow-xs space-y-5">
          <div className="border-b border-gov-100 pb-3 flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-gov-900">
                Rule 26: Statutory Exemptions from Packaging Rules
              </h2>
              <p className="text-xs text-gov-500">
                Criteria where packaged commodities are legally exempt from provisions of Chapter II
              </p>
            </div>
            <span className="text-xs font-bold bg-amber-100 text-amber-900 px-2.5 py-1 rounded">
              Rule 26
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/40">
              <div className="flex items-center gap-2 mb-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                <strong className="text-xs font-bold text-emerald-950">Clause (a): Small Quantity Packages</strong>
              </div>
              <p className="text-xs text-emerald-900 leading-relaxed">
                Commodities with net weight or measure of <strong>10 gram or 10 milli litre or less</strong>, if sold by weight or measure. (Proviso for 10g-20g was withdrawn).
              </p>
            </div>

            <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/40">
              <div className="flex items-center gap-2 mb-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                <strong className="text-xs font-bold text-emerald-950">Clause (b): Fast Food by Restaurants</strong>
              </div>
              <p className="text-xs text-emerald-900 leading-relaxed">
                Packages containing <strong>fast food items packed by restaurant or hotel</strong> and the like.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/40">
              <div className="flex items-center gap-2 mb-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                <strong className="text-xs font-bold text-emerald-950">Clause (c): DPCO Scheduled Formulations</strong>
              </div>
              <p className="text-xs text-emerald-900 leading-relaxed">
                Scheduled and non-scheduled drug formulations covered under the <strong>Drugs (Price Control) Order, 1995 (DPCO)</strong> made under section 3 of Essential Commodities Act, 1955.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/40">
              <div className="flex items-center gap-2 mb-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                <strong className="text-xs font-bold text-emerald-950">Clause (d): Bulk Agricultural Produce</strong>
              </div>
              <p className="text-xs text-emerald-900 leading-relaxed">
                Agricultural farm produce packed in packages of <strong>above 50 kg</strong>.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-blue-200 bg-blue-50/40 md:col-span-2">
              <div className="flex items-center gap-2 mb-1.5">
                <Info className="w-4 h-4 text-blue-700" />
                <strong className="text-xs font-bold text-blue-950">Rule 3 Institutional Exemption</strong>
              </div>
              <p className="text-xs text-blue-900 leading-relaxed">
                Chapter II also does not apply to packages containing quantity &gt; 25 kg or 25 L (excluding cement &amp; fertilizer in bags up to 50 kg) or commodities meant directly for industrial consumers or institutional consumers (transportation, airways, railways, hotels, hospitals).
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
