import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  ClipboardList, 
  ScanLine, 
  ArrowRight, 
  ExternalLink,
  ShieldCheck
} from 'lucide-react';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Tooltip, 
  Legend 
} from 'recharts';
import { api } from '../services/api';
import { DashboardStats, Inspection } from '../data/demoData';

export const DashboardPage: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {
    try {
      const data = await api.getDashboard();
      setStats(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const chartData = stats ? [
    { name: 'Compliant', value: stats.compliant, color: '#16a34a' },
    { name: 'Non-Compliant', value: stats.non_compliant, color: '#dc2626' },
    { name: 'Needs Verification', value: stats.needs_verification, color: '#d97706' },
  ] : [];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Compliant':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-0.5 text-xs font-semibold text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3" />
            Compliant
          </span>
        );
      case 'Non-Compliant':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-red-50 px-2.5 py-0.5 text-xs font-semibold text-red-700 border border-red-200">
            <XCircle className="w-3 h-3" />
            Non-Compliant
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2.5 py-0.5 text-xs font-semibold text-amber-800 border border-amber-200">
            <AlertTriangle className="w-3 h-3" />
            Needs Verification
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header section */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-gov-200 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gov-900">
            VidhiCheck Dashboard
          </h1>
          <p className="text-sm text-gov-500 mt-0.5">
            Packaged Commodity Compliance Monitoring &bull; Legal Metrology Division
          </p>
        </div>

        <button
          onClick={() => navigate('/scan')}
          className="inline-flex items-center justify-center gap-2 rounded-lg bg-gov-900 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-gov-800 transition-colors cursor-pointer"
        >
          <ScanLine className="w-4 h-4" />
          <span>Scan Product</span>
        </button>
      </div>

      {/* 4 Stat Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Total Inspections */}
        <div className="rounded-xl border border-gov-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gov-500 uppercase tracking-wider">
              Total Inspections
            </span>
            <div className="p-2 rounded-lg bg-gov-100 text-gov-700">
              <ClipboardList className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-gov-900 tracking-tight">
              {stats?.total ?? 128}
            </span>
            <p className="text-xs text-gov-400 mt-1">Recorded audit cases</p>
          </div>
        </div>

        {/* Compliant */}
        <div className="rounded-xl border border-emerald-200 bg-emerald-50/40 p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">
              Compliant
            </span>
            <div className="p-2 rounded-lg bg-emerald-100 text-emerald-700">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-emerald-900 tracking-tight">
              {stats?.compliant ?? 82}
            </span>
            <p className="text-xs text-emerald-700/80 mt-1">Full statutory adherence</p>
          </div>
        </div>

        {/* Non-Compliant */}
        <div className="rounded-xl border border-red-200 bg-red-50/40 p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-red-800 uppercase tracking-wider">
              Non-Compliant
            </span>
            <div className="p-2 rounded-lg bg-red-100 text-red-700">
              <XCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-red-900 tracking-tight">
              {stats?.non_compliant ?? 31}
            </span>
            <p className="text-xs text-red-700/80 mt-1">Confirmed rule violations</p>
          </div>
        </div>

        {/* Needs Verification */}
        <div className="rounded-xl border border-amber-200 bg-amber-50/40 p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-amber-800 uppercase tracking-wider">
              Needs Verification
            </span>
            <div className="p-2 rounded-lg bg-amber-100 text-amber-700">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-amber-900 tracking-tight">
              {stats?.needs_verification ?? 15}
            </span>
            <p className="text-xs text-amber-700/80 mt-1">Awaiting physical confirmation</p>
          </div>
        </div>
      </div>

      {/* Charts & Compliance Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Compliance Donut Chart */}
        <div className="rounded-xl border border-gov-200 bg-white p-5 shadow-xs">
          <div className="border-b border-gov-100 pb-3 mb-3">
            <h2 className="text-sm font-bold text-gov-900">Inspection Compliance Overview</h2>
            <p className="text-xs text-gov-500">Distribution across analyzed commodities</p>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="45%"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value: any) => [`${value} cases`, 'Total']}
                  contentStyle={{ backgroundColor: '#ffffff', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '12px' }}
                />
                <Legend 
                  verticalAlign="bottom" 
                  align="center"
                  wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Quick Statutory Compliance Guidelines */}
        <div className="lg:col-span-2 rounded-xl border border-gov-200 bg-white p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="border-b border-gov-100 pb-3 mb-3 flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-gov-900">Statutory Framework Reference</h2>
                <p className="text-xs text-gov-500">Legal Metrology (Packaged Commodities) Rules, 2011</p>
              </div>
              <span className="text-xs font-semibold bg-gov-100 text-gov-800 px-2.5 py-1 rounded">Rule 6 Protocols</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs mt-4">
              <div className="p-3 rounded-lg bg-gov-50 border border-gov-200/80">
                <span className="font-bold text-gov-900 block mb-1">Rule 6(1)(a) & (c)</span>
                <p className="text-gov-600">
                  Mandatory complete address of manufacturer/packer and standard net quantity in metric units.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-gov-50 border border-gov-200/80">
                <span className="font-bold text-gov-900 block mb-1">Rule 6(1)(e) & (d)</span>
                <p className="text-gov-600">
                  Maximum Retail Price (MRP inclusive of all taxes) and month/year of packing or manufacture.
                </p>
              </div>

              <div className="p-3 rounded-lg bg-gov-50 border border-gov-200/80">
                <span className="font-bold text-gov-900 block mb-1">Rule 6(1)(n)</span>
                <p className="text-gov-600">
                  Mandatory consumer care details (toll-free telephone, email, and designated grievance address).
                </p>
              </div>

              <div className="p-3 rounded-lg bg-gov-50 border border-gov-200/80">
                <span className="font-bold text-gov-900 block mb-1">Rule 9(1)</span>
                <p className="text-gov-600">
                  Legibility, minimum font size standards, and high optical contrast for all declared text.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-gov-100 flex items-center justify-between text-xs text-gov-500">
            <span>Enforcement Standard: Automated Optical Inspection Protocol</span>
            <span className="font-medium text-gov-700">SIH 2026 Prototype</span>
          </div>
        </div>
      </div>

      {/* Recent Inspections Table */}
      <div className="rounded-xl border border-gov-200 bg-white shadow-xs overflow-hidden">
        <div className="p-5 border-b border-gov-100 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-gov-900">Recent Inspections</h2>
            <p className="text-xs text-gov-500">Chronological history of scanned commodities</p>
          </div>

          <button
            onClick={() => navigate('/history')}
            className="text-xs font-semibold text-gov-700 hover:text-gov-900 flex items-center gap-1"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-gov-600">
            <thead className="bg-gov-50 text-xs font-semibold uppercase text-gov-500 border-b border-gov-200/80">
              <tr>
                <th scope="col" className="px-5 py-3">Inspection ID</th>
                <th scope="col" className="px-5 py-3">Product</th>
                <th scope="col" className="px-5 py-3">Date</th>
                <th scope="col" className="px-5 py-3">Status</th>
                <th scope="col" className="px-5 py-3">Officer</th>
                <th scope="col" className="px-5 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gov-100">
              {stats?.recent && stats.recent.length > 0 ? (
                stats.recent.map((item) => (
                  <tr 
                    key={item.id}
                    onClick={() => navigate(`/result/${item.id}`)}
                    className="hover:bg-gov-50/70 transition-colors cursor-pointer"
                  >
                    <td className="px-5 py-3.5 font-mono font-bold text-gov-900">
                      {item.id}
                    </td>
                    <td className="px-5 py-3.5 font-medium text-gov-900">
                      {item.product}
                    </td>
                    <td className="px-5 py-3.5 text-xs text-gov-500">
                      {item.date}
                    </td>
                    <td className="px-5 py-3.5">
                      {getStatusBadge(item.final_status || item.status)}
                    </td>
                    <td className="px-5 py-3.5 text-xs text-gov-600">
                      {item.officer}
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-gov-700 hover:text-gov-900">
                        <span>Details</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="text-center py-6 text-sm text-gov-400">
                    No inspection records found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
