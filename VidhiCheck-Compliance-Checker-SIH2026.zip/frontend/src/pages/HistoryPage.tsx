import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Search, 
  Filter, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  ExternalLink,
  Plus,
  Calendar,
  Building
} from 'lucide-react';
import { api } from '../services/api';
import { Inspection } from '../data/demoData';

export const HistoryPage: React.FC = () => {
  const [inspections, setInspections] = useState<Inspection[]>([]);
  const [filtered, setFiltered] = useState<Inspection[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [loading, setLoading] = useState<boolean>(true);

  const navigate = useNavigate();

  useEffect(() => {
    loadInspections();
  }, []);

  const loadInspections = async () => {
    try {
      const data = await api.getInspections();
      setInspections(data);
      setFiltered(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let result = inspections;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (i) => i.id.toLowerCase().includes(q) || i.product.toLowerCase().includes(q)
      );
    }

    if (statusFilter !== 'All') {
      result = result.filter(
        (i) => (i.final_status || i.status).toLowerCase() === statusFilter.toLowerCase()
      );
    }

    setFiltered(result);
  }, [searchQuery, statusFilter, inspections]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Compliant':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-0.5 text-xs font-semibold text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3" />
            Compliant
          </span>
        );
      case 'Non-Compliant':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-red-50 px-2.5 py-0.5 text-xs font-semibold text-red-700 border border-red-200">
            <XCircle className="w-3 h-3" />
            Non-Compliant
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2.5 py-0.5 text-xs font-semibold text-amber-800 border border-amber-200">
            <AlertTriangle className="w-3 h-3" />
            Needs Verification
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-gov-200 pb-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gov-900">
            Inspection History
          </h1>
          <p className="text-sm text-gov-500 mt-0.5">
            Audit logs and records of examined packaged commodities
          </p>
        </div>

        <button
          onClick={() => navigate('/scan')}
          className="inline-flex items-center gap-1.5 rounded-lg bg-gov-900 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-gov-800 transition-colors cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Inspection</span>
        </button>
      </div>

      {/* Search and Filters Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
        {/* Search */}
        <div className="relative w-full sm:max-w-md">
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-gov-400">
            <Search className="h-4 w-4" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search product or inspection ID..."
            className="w-full rounded-xl border border-gov-300 bg-white py-2 pl-9 pr-3 text-xs text-gov-900 placeholder:text-gov-400 focus:border-gov-900 focus:outline-none focus:ring-1 focus:ring-gov-900 transition-colors shadow-2xs"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
          {['All', 'Compliant', 'Non-Compliant', 'Needs Verification'].map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setStatusFilter(f)}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                statusFilter === f
                  ? 'bg-gov-900 text-white shadow-xs'
                  : 'bg-white text-gov-600 border border-gov-200 hover:bg-gov-50'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Inspections Table */}
      <div className="rounded-2xl border border-gov-200 bg-white shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-gov-600">
            <thead className="bg-gov-50 text-xs font-semibold uppercase text-gov-500 border-b border-gov-200">
              <tr>
                <th className="px-5 py-3">Inspection ID</th>
                <th className="px-5 py-3">Product</th>
                <th className="px-5 py-3">Date</th>
                <th className="px-5 py-3">Score</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gov-100">
              {loading ? (
                <tr>
                  <td colSpan={6} className="text-center py-10 text-xs text-gov-400">
                    Loading inspections database...
                  </td>
                </tr>
              ) : filtered.length > 0 ? (
                filtered.map((item) => (
                  <tr
                    key={item.id}
                    onClick={() => navigate(`/result/${item.id}`)}
                    className="hover:bg-gov-50/70 transition-colors cursor-pointer"
                  >
                    <td className="px-5 py-3.5 font-mono font-bold text-gov-900">
                      {item.id}
                    </td>
                    <td className="px-5 py-3.5 font-medium text-gov-900">
                      {item.product}
                    </td>
                    <td className="px-5 py-3.5 text-xs text-gov-500">
                      {item.date}
                    </td>
                    <td className="px-5 py-3.5 font-semibold text-gov-900">
                      {item.score} <span className="text-xs font-normal text-gov-400">/ 100</span>
                    </td>
                    <td className="px-5 py-3.5">
                      {getStatusBadge(item.final_status || item.status)}
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate(`/result/${item.id}`);
                        }}
                        className="inline-flex items-center gap-1 rounded-lg border border-gov-200 bg-white px-2.5 py-1 text-xs font-semibold text-gov-700 hover:bg-gov-50 transition-colors cursor-pointer"
                      >
                        <span>View</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="text-center py-12 text-sm text-gov-400">
                    No matching inspections found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
