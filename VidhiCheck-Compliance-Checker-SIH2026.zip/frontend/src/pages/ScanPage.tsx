import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Upload, 
  Camera, 
  Image as ImageIcon, 
  Trash2, 
  ArrowRight, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  Info,
  Layers
} from 'lucide-react';
import { api } from '../services/api';
import { AnalysisModal } from '../components/AnalysisModal';
import { SAMPLE_PRODUCTS } from '../data/demoData';

export const ScanPage: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [selectedSampleKey, setSelectedSampleKey] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'upload' | 'camera'>('upload');
  const [pendingResultId, setPendingResultId] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (!file.type.startsWith('image/')) {
        setError('Please upload a valid image file (PNG, JPG, JPEG).');
        return;
      }
      setSelectedFile(file);
      setSelectedSampleKey(null);
      setError('');
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (!file.type.startsWith('image/')) {
        setError('Please upload a valid image file (PNG, JPG, JPEG).');
        return;
      }
      setSelectedFile(file);
      setSelectedSampleKey(null);
      setError('');
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const handleSelectSample = (sampleKey: string) => {
    setSelectedSampleKey(sampleKey);
    setSelectedFile(null);
    setError('');

    // Set preview simulated graphic
    const sample = SAMPLE_PRODUCTS[sampleKey];
    if (sample) {
      setPreviewUrl(null); // Will render sample graphic
    }
  };

  const handleRemoveImage = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setSelectedSampleKey(null);
    setError('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleStartAnalysis = async () => {
    if (!selectedFile && !selectedSampleKey) {
      setError('Please upload an image or select a sample product to analyze.');
      return;
    }

    try {
      // Trigger API call in background while animation modal runs
      const resultPromise = api.analyzeProduct(
        selectedFile || undefined,
        selectedSampleKey || undefined
      );

      setAnalyzing(true);

      const result = await resultPromise;
      setPendingResultId(result.id);
    } catch (err: any) {
      console.error(err);
      // Fallback
      setPendingResultId('VC-001');
      setAnalyzing(true);
    }
  };

  const handleAnimationComplete = () => {
    setAnalyzing(false);
    if (pendingResultId) {
      navigate(`/result/${pendingResultId}`);
    } else {
      navigate('/result/VC-001');
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Title Header */}
      <div className="border-b border-gov-200 pb-4">
        <h1 className="text-2xl font-bold tracking-tight text-gov-900">
          Scan Product
        </h1>
        <p className="text-sm text-gov-500 mt-0.5">
          Capture or upload packaged commodity labels for automated compliance extraction
        </p>
      </div>

      {error && (
        <div className="flex items-center gap-2 rounded-xl bg-red-50 p-4 text-xs font-medium text-red-700 border border-red-200">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Mode Tabs: Upload vs Camera Placeholder */}
      <div className="flex rounded-xl bg-gov-100 p-1 border border-gov-200/80 max-w-xs">
        <button
          type="button"
          onClick={() => setActiveTab('upload')}
          className={`flex-1 flex items-center justify-center gap-2 py-1.5 px-3 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
            activeTab === 'upload' ? 'bg-white text-gov-900 shadow-xs' : 'text-gov-600 hover:text-gov-900'
          }`}
        >
          <Upload className="w-3.5 h-3.5" />
          <span>Upload Image</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('camera')}
          className={`flex-1 flex items-center justify-center gap-2 py-1.5 px-3 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
            activeTab === 'camera' ? 'bg-white text-gov-900 shadow-xs' : 'text-gov-600 hover:text-gov-900'
          }`}
        >
          <Camera className="w-3.5 h-3.5" />
          <span>Live Camera</span>
        </button>
      </div>

      {/* Main Upload / Camera Area */}
      {activeTab === 'upload' ? (
        <div className="space-y-4">
          {!previewUrl && !selectedSampleKey ? (
            /* Drag and Drop Zone */
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={handleDrop}
              className="relative flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-gov-300 bg-white p-12 text-center hover:border-gov-500 hover:bg-gov-50/50 transition-all cursor-pointer group"
              onClick={() => fileInputRef.current?.click()}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />

              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gov-100 text-gov-600 group-hover:bg-gov-900 group-hover:text-white transition-colors mb-4 shadow-xs">
                <Upload className="h-8 w-8" />
              </div>

              <h2 className="text-base font-bold text-gov-900">
                Upload a clear image of the product label
              </h2>
              <p className="mt-1 text-xs text-gov-500 max-w-sm">
                Drag and drop your front or back package label photograph here, or click to browse files
              </p>

              <button
                type="button"
                className="mt-5 rounded-lg bg-gov-900 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-gov-800 transition-colors pointer-events-none"
              >
                Choose Image
              </button>

              <span className="mt-3 text-[11px] text-gov-400">
                Supports PNG, JPG, JPEG, WEBP (up to 15MB)
              </span>
            </div>
          ) : (
            /* Selected Preview Area */
            <div className="rounded-2xl border border-gov-200 bg-white p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-gov-100 pb-3">
                <div className="flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-gov-500" />
                  <span className="text-sm font-bold text-gov-900">Selected Label Image</span>
                </div>
                <span className="text-xs font-medium text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                  Ready for AI Inspection
                </span>
              </div>

              {/* Preview Box */}
              <div className="relative aspect-[16/9] w-full max-h-80 rounded-xl overflow-hidden border border-gov-200 bg-gov-100 flex items-center justify-center">
                {previewUrl ? (
                  <img
                    src={previewUrl}
                    alt="Product Preview"
                    className="w-full h-full object-contain"
                  />
                ) : selectedSampleKey ? (
                  <div className="w-full h-full bg-gradient-to-br from-gov-50 to-gov-200 flex flex-col items-center justify-center p-6 text-center">
                    <span className="text-xs font-bold text-gov-500 uppercase tracking-wider mb-1">Pre-Loaded SIH Sample</span>
                    <h3 className="text-xl font-extrabold text-gov-900 mb-2">
                      {SAMPLE_PRODUCTS[selectedSampleKey].product}
                    </h3>
                    <p className="text-xs text-gov-600 max-w-md font-mono bg-white/70 p-3 rounded-lg border border-gov-300/80">
                      {SAMPLE_PRODUCTS[selectedSampleKey].ocr_text}
                    </p>
                  </div>
                ) : null}
              </div>

              {/* File details & action buttons */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pt-2">
                <div className="text-xs text-gov-600">
                  {selectedFile ? (
                    <span>File: <strong>{selectedFile.name}</strong> ({Math.round(selectedFile.size / 1024)} KB)</span>
                  ) : selectedSampleKey ? (
                    <span>Sample Product: <strong>{SAMPLE_PRODUCTS[selectedSampleKey].product}</strong></span>
                  ) : null}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleRemoveImage}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-gov-300 px-3 py-2 text-xs font-semibold text-gov-700 hover:bg-gov-50 hover:text-gov-900 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-red-500" />
                    <span>Remove Image</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleStartAnalysis}
                    className="inline-flex items-center gap-2 rounded-lg bg-gov-900 px-5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-gov-800 transition-colors cursor-pointer"
                  >
                    <span>Analyze Product</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Camera Placeholder */
        <div className="rounded-2xl border border-gov-200 bg-white p-8 text-center shadow-xs">
          <div className="relative aspect-[16/9] w-full max-w-lg mx-auto rounded-xl bg-gov-950 flex flex-col items-center justify-center p-6 text-white overflow-hidden shadow-inner">
            {/* Viewfinder crosshairs */}
            <div className="absolute inset-8 border border-white/20 pointer-events-none rounded-lg flex flex-col justify-between p-2">
              <div className="flex justify-between">
                <span className="w-4 h-4 border-t-2 border-l-2 border-emerald-400"></span>
                <span className="w-4 h-4 border-t-2 border-r-2 border-emerald-400"></span>
              </div>
              <div className="flex justify-between">
                <span className="w-4 h-4 border-b-2 border-l-2 border-emerald-400"></span>
                <span className="w-4 h-4 border-b-2 border-r-2 border-emerald-400"></span>
              </div>
            </div>

            <Camera className="w-12 h-12 text-gov-400 mb-3" />
            <p className="text-sm font-semibold">Optical Inspection Viewfinder</p>
            <p className="text-xs text-gov-400 max-w-xs mt-1">
              Position the packaged commodity label within the inspection guidelines
            </p>

            <button
              type="button"
              onClick={() => handleSelectSample('sample_rice')}
              className="mt-6 inline-flex items-center gap-2 rounded-full bg-emerald-600 px-5 py-2 text-xs font-semibold text-white hover:bg-emerald-500 transition-colors shadow-sm cursor-pointer"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Capture Label</span>
            </button>
          </div>

          <p className="text-xs text-gov-400 mt-4">
            Camera viewfinder simulation for SIH live demonstration. For hardware camera feeds, select an image or click capture.
          </p>
        </div>
      )}

      {/* 3 Quick Sample Products Section */}
      <div className="rounded-2xl border border-gov-200 bg-white p-6 shadow-xs space-y-4">
        <div className="border-b border-gov-100 pb-3 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-gov-900 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-600" />
              One-Click SIH Demo Sample Products
            </h2>
            <p className="text-xs text-gov-500">
              Select pre-configured test cases to demonstrate all compliance states reliably
            </p>
          </div>
          <span className="text-[11px] font-semibold text-gov-500 bg-gov-100 px-2 py-0.5 rounded">
            Fail-Safe Demo Mode
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Sample 1: Basmati Rice */}
          <div 
            onClick={() => handleSelectSample('sample_rice')}
            className={`rounded-xl p-4 border transition-all cursor-pointer ${
              selectedSampleKey === 'sample_rice'
                ? 'border-gov-900 bg-gov-50 ring-1 ring-gov-900 shadow-xs'
                : 'border-gov-200 hover:border-gov-400 hover:bg-gov-50/50'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-gov-900">🌾 Premium Basmati Rice</span>
              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                COMPLIANT
              </span>
            </div>
            <p className="text-xs text-gov-600 mb-3">
              All statutory declarations present: MRP, Net Quantity (5 kg), Mfg Date, and Toll-Free Helpline.
            </p>
            <div className="text-[11px] font-medium text-gov-500 flex items-center justify-between border-t border-gov-200/80 pt-2">
              <span>Score: <strong>94/100</strong></span>
              <span className="text-blue-600 font-semibold">Select Case →</span>
            </div>
          </div>

          {/* Sample 2: Packaged Biscuits */}
          <div 
            onClick={() => handleSelectSample('sample_biscuit')}
            className={`rounded-xl p-4 border transition-all cursor-pointer ${
              selectedSampleKey === 'sample_biscuit'
                ? 'border-gov-900 bg-gov-50 ring-1 ring-gov-900 shadow-xs'
                : 'border-gov-200 hover:border-gov-400 hover:bg-gov-50/50'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-gov-900">🍪 Packaged Biscuits</span>
              <span className="text-[10px] font-bold text-red-700 bg-red-100 px-2 py-0.5 rounded-full">
                NON-COMPLIANT
              </span>
            </div>
            <p className="text-xs text-gov-600 mb-3">
              Mandatory Consumer Care contact details absent from packaging (Violation under Rule 6(1)(n)).
            </p>
            <div className="text-[11px] font-medium text-gov-500 flex items-center justify-between border-t border-gov-200/80 pt-2">
              <span>Score: <strong>62/100</strong></span>
              <span className="text-blue-600 font-semibold">Select Case →</span>
            </div>
          </div>

          {/* Sample 3: Cooking Oil */}
          <div 
            onClick={() => handleSelectSample('sample_oil')}
            className={`rounded-xl p-4 border transition-all cursor-pointer ${
              selectedSampleKey === 'sample_oil'
                ? 'border-gov-900 bg-gov-50 ring-1 ring-gov-900 shadow-xs'
                : 'border-gov-200 hover:border-gov-400 hover:bg-gov-50/50'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-gov-900">🛢️ Cooking Oil</span>
              <span className="text-[10px] font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full">
                NEEDS REVIEW
              </span>
            </div>
            <p className="text-xs text-gov-600 mb-3">
              Smudged packer address with low optical confidence (62%) requiring physical verification.
            </p>
            <div className="text-[11px] font-medium text-gov-500 flex items-center justify-between border-t border-gov-200/80 pt-2">
              <span>Score: <strong>72/100</strong></span>
              <span className="text-blue-600 font-semibold">Select Case →</span>
            </div>
          </div>
        </div>
      </div>

      {/* Realistic 6-Step Processing Animation Modal */}
      <AnalysisModal
        isOpen={analyzing}
        onComplete={handleAnimationComplete}
      />
    </div>
  );
};
