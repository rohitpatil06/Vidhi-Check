import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, KeyRound, UserCheck, AlertCircle, ArrowRight, Sparkles } from 'lucide-react';

interface LoginPageProps {
  onLogin: (officerId: string) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [officerId, setOfficerId] = useState<string>('officer001');
  const [password, setPassword] = useState<string>('vidhicheck123');
  const [error, setError] = useState<string>('');
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!officerId.trim() || !password.trim()) {
      setError('Please enter Officer ID and Password');
      return;
    }

    if (officerId === 'officer001' && password === 'vidhicheck123') {
      onLogin(officerId);
      navigate('/dashboard');
    } else {
      setError('Invalid credentials. Use demo: officer001 / vidhicheck123');
    }
  };

  const handleFillDemo = () => {
    setOfficerId('officer001');
    setPassword('vidhicheck123');
    setError('');
  };

  return (
    <div className="min-h-screen bg-gov-50 flex flex-col justify-center items-center px-4 py-12">
      {/* Container */}
      <div className="w-full max-w-md">
        {/* Branding header */}
        <div className="text-center mb-8">
          <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gov-900 text-white shadow-md mb-4">
            <Shield className="h-7 w-7" />
          </div>
          <h1 className="text-2xl font-black tracking-tight text-gov-900 sm:text-3xl">
            VIDHICHECK
          </h1>
          <p className="mt-1.5 text-sm font-medium text-gov-600">
            AI-Based Packaged Commodity Compliance Checker
          </p>
          <p className="text-xs text-gov-400 mt-0.5">
            Legal Metrology Officer Enforcement Portal
          </p>
        </div>

        {/* Card */}
        <div className="rounded-2xl border border-gov-200 bg-white p-7 shadow-sm">
          <div className="border-b border-gov-100 pb-4 mb-5">
            <h2 className="text-base font-bold text-gov-900">Officer Authentication</h2>
            <p className="text-xs text-gov-500">Sign in with authorized Legal Metrology credentials</p>
          </div>

          {error && (
            <div className="mb-4 flex items-center gap-2 rounded-lg bg-red-50 p-3 text-xs text-red-700 border border-red-200">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-gov-700 mb-1.5">
                Officer ID
              </label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-gov-400">
                  <UserCheck className="h-4 w-4" />
                </div>
                <input
                  type="text"
                  value={officerId}
                  onChange={(e) => setOfficerId(e.target.value)}
                  placeholder="e.g. officer001"
                  className="w-full rounded-lg border border-gov-300 py-2 pl-9 pr-3 text-sm text-gov-900 placeholder:text-gov-400 focus:border-gov-900 focus:outline-none focus:ring-1 focus:ring-gov-900 transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gov-700 mb-1.5">
                Password
              </label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-gov-400">
                  <KeyRound className="h-4 w-4" />
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full rounded-lg border border-gov-300 py-2 pl-9 pr-3 text-sm text-gov-900 placeholder:text-gov-400 focus:border-gov-900 focus:outline-none focus:ring-1 focus:ring-gov-900 transition-colors"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full mt-2 flex items-center justify-center gap-2 rounded-lg bg-gov-900 py-2.5 px-4 text-sm font-semibold text-white shadow-sm hover:bg-gov-800 transition-colors cursor-pointer"
            >
              <span>Login</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </form>

          {/* Quick Demo Credentials Box */}
          <div className="mt-6 rounded-xl bg-gov-50 p-3.5 border border-gov-200/80">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold text-gov-800 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                SIH Demo Credentials
              </span>
              <button
                type="button"
                onClick={handleFillDemo}
                className="text-[11px] font-semibold text-blue-600 hover:text-blue-800 underline cursor-pointer"
              >
                Auto-fill
              </button>
            </div>
            <p className="text-[11px] text-gov-600">
              Officer ID: <code className="font-mono font-bold bg-white px-1.5 py-0.5 rounded border border-gov-200">officer001</code>
            </p>
            <p className="text-[11px] text-gov-600 mt-1">
              Password: <code className="font-mono font-bold bg-white px-1.5 py-0.5 rounded border border-gov-200">vidhicheck123</code>
            </p>
          </div>
        </div>

        <p className="text-center text-xs text-gov-400 mt-6">
          VidhiCheck Prototype &bull; Smart India Hackathon (SIH 2026)
        </p>
      </div>
    </div>
  );
};
