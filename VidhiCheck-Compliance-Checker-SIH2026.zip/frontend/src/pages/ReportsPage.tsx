import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { 
  FileText, 
  Download, 
  Printer, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle,
  Building2,
  Shield,
  UserCheck
} from 'lucide-react';
import { api } from '../services/api';
import { Inspection } from '../data/demoData';

export const ReportsPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const [inspections, setInspections] = useState<Inspection[]>([]);
  const [selectedInspection, setSelectedInspection] = useState<Inspection | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [downloading, setDownloading] = useState<boolean>(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const all = await api.getInspections();
      setInspections(all);

      const targetId = searchParams.get('id');
      if (targetId) {
        const found = all.find((i) => i.id === targetId);
        if (found) {
          setSelectedInspection(found);
          return;
        }
      }

      if (all.length > 0) {
        setSelectedInspection(all[0]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async () => {
    if (!selectedInspection) return;
    setDownloading(true);
    try {
      await api.downloadReportPdf(selectedInspection);
    } finally {
      setDownloading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (loading) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="text-center space-y-2">
          <div className="w-8 h-8 border-4 border-gov-900 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-xs text-gov-500">Preparing compliance report...</p>
        </div>
      </div>
    );
  }

  if (!selectedInspection) {
    return (
      <div className="rounded-xl border border-gov-200 bg-white p-8 text-center max-w-md mx-auto">
        <p className="text-sm text-gov-500">No inspection record available for report generation.</p>
      </div>
    );
  }

  const effectiveStatus = selectedInspection.final_status || selectedInspection.status;

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-12">
      {/* Top action header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-gov-200 pb-4 print:hidden">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gov-900">
            Compliance Inspection Report
          </h1>
          <p className="text-sm text-gov-500 mt-0.5">
            Official statutory audit dossier for Legal Metrology enforcement
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Select inspection */}
          <select
            value={selectedInspection.id}
            onChange={(e) => {
              const item = inspections.find((i) => i.id === e.target.value);
              if (item) setSelectedInspection(item);
            }}
            className="rounded-lg border border-gov-300 bg-white px-3 py-2 text-xs font-semibold text-gov-900 focus:outline-none"
          >
            {inspections.map((i) => (
              <option key={i.id} value={i.id}>
                {i.id} — {i.product}
              </option>
            ))}
          </select>

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 rounded-lg border border-gov-300 bg-white px-3 py-2 text-xs font-semibold text-gov-700 hover:bg-gov-50 transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>

          <button
            onClick={handleDownload}
            disabled={downloading}
            className="inline-flex items-center gap-1.5 rounded-lg bg-gov-900 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-gov-800 transition-colors cursor-pointer disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{downloading ? 'Generating...' : 'Download PDF'}</span>
          </button>
        </div>
      </div>

      {/* Official Government Form Presentation Sheet */}
      <div className="rounded-2xl border border-gov-300 bg-white p-8 sm:p-12 shadow-sm space-y-6 text-gov-900 font-sans print:p-0 print:border-none print:shadow-none">
        {/* Document Header */}
        <div className="border-b-2 border-gov-900 pb-5 text-center space-y-1">
          <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gov-900 text-white mb-2">
            <Shield className="h-6 w-6" />
          </div>
          <h2 className="text-xl font-black tracking-wider text-gov-900 uppercase">
            VIDHICHECK
          </h2>
          <p className="text-xs font-bold text-gov-700 uppercase tracking-wide">
            DIRECTORATE OF LEGAL METROLOGY &bull; GOVERNMENT OF INDIA
          </p>
          <p className="text-[11px] text-gov-500 italic">
            Packaged Commodities Inspection Protocol under The Legal Metrology (Packaged Commodities) Rules, 2011
          </p>
        </div>

        {/* Overview Meta Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 rounded-xl bg-gov-50 p-4 border border-gov-200 text-xs">
          <div>
            <span className="text-gov-500 font-medium block">Inspection ID:</span>
            <strong className="font-mono text-sm text-gov-900">{selectedInspection.id}</strong>
          </div>
          <div>
            <span className="text-gov-500 font-medium block">Inspection Date:</span>
            <strong className="text-gov-900">{selectedInspection.date}</strong>
          </div>
          <div>
            <span className="text-gov-500 font-medium block">Inspecting Officer:</span>
            <strong className="text-gov-900">{selectedInspection.officer}</strong>
          </div>
          <div>
            <span className="text-gov-500 font-medium block">Packaged Commodity:</span>
            <strong className="text-gov-900">{selectedInspection.product}</strong>
          </div>
          <div>
            <span className="text-gov-500 font-medium block">Compliance Score:</span>
            <strong className="text-gov-900 font-bold">{selectedInspection.score} / 100</strong>
          </div>
          <div>
            <span className="text-gov-500 font-medium block">Final Official Status:</span>
            <span className={`inline-block font-bold text-xs ${
              effectiveStatus === 'Compliant' ? 'text-emerald-700' :
              (effectiveStatus === 'Non-Compliant' ? 'text-red-700' : 'text-amber-800')
            }`}>
              {effectiveStatus.toUpperCase()}
            </span>
          </div>
        </div>

        {/* Section 1: Extracted Declarations */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-gov-800 border-b border-gov-200 pb-1">
            1. Extracted Label Declarations (AI / OCR Extraction)
          </h3>
          <table className="w-full text-left text-xs border border-gov-200">
            <thead className="bg-gov-100 text-gov-700 font-semibold border-b border-gov-200">
              <tr>
                <th className="p-2">Declaration Field</th>
                <th className="p-2">Extracted Value</th>
                <th className="p-2 text-right">Confidence</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gov-200">
              {selectedInspection.declarations.map((d, i) => (
                <tr key={i}>
                  <td className="p-2 font-medium text-gov-900">{d.label}</td>
                  <td className="p-2">{d.value}</td>
                  <td className="p-2 text-right font-mono">{Math.round(d.confidence * 100)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Section 2: Statutory Compliance Checks */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-gov-800 border-b border-gov-200 pb-1">
            2. Statutory Rule Compliance Checklist
          </h3>
          <table className="w-full text-left text-xs border border-gov-200">
            <thead className="bg-gov-100 text-gov-700 font-semibold border-b border-gov-200">
              <tr>
                <th className="p-2">Requirement</th>
                <th className="p-2">Inspection Result</th>
                <th className="p-2 text-right">Finding</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gov-200">
              {selectedInspection.checks.map((c, i) => (
                <tr key={i}>
                  <td className="p-2 font-medium text-gov-900">{c.requirement}</td>
                  <td className="p-2 text-gov-600">{c.result}</td>
                  <td className="p-2 text-right font-bold">
                    <span className={c.status === 'COMPLIANT' ? 'text-emerald-700' : (c.status === 'NON-COMPLIANT' ? 'text-red-700' : 'text-amber-800')}>
                      {c.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Section 3: Violations */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-gov-800 border-b border-gov-200 pb-1">
            3. Detected Rule Violations &amp; Infractions
          </h3>
          {selectedInspection.violations && selectedInspection.violations.length > 0 ? (
            <div className="space-y-2">
              {selectedInspection.violations.map((v, i) => (
                <div key={i} className="rounded-lg border border-red-200 bg-red-50/40 p-3 text-xs">
                  <div className="flex justify-between font-bold text-red-900 mb-1">
                    <span>{v.title}</span>
                    <span>{v.rule}</span>
                  </div>
                  <p className="text-gov-700">{v.reason}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-gov-500 italic p-2 bg-gov-50 rounded">
              No statutory infractions detected. Packaging conforms to Rule 6 requirements.
            </p>
          )}
        </div>

        {/* Section 4: Officer Verification & Remarks */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-gov-800 border-b border-gov-200 pb-1">
            4. Legal Metrology Officer Verification
          </h3>
          <div className="rounded-xl border border-gov-200 bg-gov-50 p-4 space-y-2 text-xs">
            <div className="flex justify-between">
              <span><strong>Enforcement Decision:</strong> {effectiveStatus.toUpperCase()}</span>
              <span><strong>Officer ID:</strong> {selectedInspection.officer}</span>
            </div>
            <p className="text-gov-700">
              <strong>Official Remarks:</strong> {selectedInspection.remarks || 'Verified against submitted packaged commodity label photograph.'}
            </p>
            <div className="pt-3 border-t border-gov-200/80 flex justify-between items-center text-[11px] text-gov-500">
              <span>Digital Verification Record</span>
              <span className="font-mono">VERIFIED BY AUTHORIZED OFFICER</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-gov-200 text-center text-[11px] text-gov-400 space-y-1">
          <p>
            Generated by VidhiCheck — AI-Assisted Packaged Commodity Compliance Checker
          </p>
          <p className="italic text-[10px]">
            Statutory Notice: AI analysis provides advisory verification. Final legal enforcement decisions are authorized by Legal Metrology officers.
          </p>
        </div>
      </div>
    </div>
  );
};
