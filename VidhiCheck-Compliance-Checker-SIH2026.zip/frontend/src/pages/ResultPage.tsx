import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  ShieldAlert, 
  FileText, 
  Download, 
  ArrowLeft, 
  UserCheck, 
  Sparkles,
  Info,
  Check,
  Building,
  RotateCcw,
  CheckCheck
} from 'lucide-react';
import { api } from '../services/api';
import { Inspection } from '../data/demoData';
import { AnnotatedImage } from '../components/AnnotatedImage';

export const ResultPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [inspection, setInspection] = useState<Inspection | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [officerDecision, setOfficerDecision] = useState<string>('');
  const [officerRemarks, setOfficerRemarks] = useState<string>('');
  const [verificationSubmitted, setVerificationSubmitted] = useState<boolean>(false);
  const [downloading, setDownloading] = useState<boolean>(false);

  const navigate = useNavigate();

  useEffect(() => {
    if (id) {
      loadInspection(id);
    }
  }, [id]);

  const loadInspection = async (inspId: string) => {
    try {
      const data = await api.getInspectionById(inspId);
      if (data) {
        setInspection(data);
        setOfficerRemarks(data.remarks || '');
        if (data.final_status) {
          if (data.final_status === 'Compliant') setOfficerDecision('Reject Violation');
          else if (data.final_status === 'Non-Compliant') setOfficerDecision('Confirm Violation');
          else setOfficerDecision('Needs Manual Review');
          setVerificationSubmitted(true);
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleOfficerVerification = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inspection || !officerDecision) return;

    try {
      const updated = await api.verifyInspection(
        inspection.id,
        officerDecision,
        officerRemarks
      );
      setInspection(updated);
      setVerificationSubmitted(true);
    } catch (err) {
      console.error(err);
    }
  };

  const handleDownloadPdf = async () => {
    if (!inspection) return;
    setDownloading(true);
    try {
      await api.downloadReportPdf(inspection);
    } finally {
      setDownloading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="text-center space-y-2">
          <div className="w-8 h-8 border-4 border-gov-900 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-xs text-gov-500 font-medium">Retrieving inspection audit...</p>
        </div>
      </div>
    );
  }

  if (!inspection) {
    return (
      <div className="rounded-2xl border border-gov-200 bg-white p-12 text-center max-w-lg mx-auto">
        <AlertTriangle className="w-10 h-10 text-amber-500 mx-auto mb-3" />
        <h2 className="text-lg font-bold text-gov-900">Inspection Not Found</h2>
        <p className="text-xs text-gov-500 mt-1 mb-6">
          The requested inspection audit record could not be located.
        </p>
        <button
          onClick={() => navigate('/history')}
          className="rounded-lg bg-gov-900 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-gov-800 cursor-pointer"
        >
          Return to Inspections
        </button>
      </div>
    );
  }

  const effectiveStatus = inspection.final_status || inspection.status;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Compliant':
        return (
          <div className="flex items-center gap-2 bg-emerald-50 text-emerald-800 border border-emerald-300 px-4 py-2 rounded-xl">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <div>
              <span className="text-xs font-semibold block uppercase tracking-wider text-emerald-600">Statutory Status</span>
              <strong className="text-sm font-extrabold">COMPLIANT</strong>
            </div>
          </div>
        );
      case 'Non-Compliant':
        return (
          <div className="flex items-center gap-2 bg-red-50 text-red-800 border border-red-300 px-4 py-2 rounded-xl">
            <XCircle className="w-5 h-5 text-red-600" />
            <div>
              <span className="text-xs font-semibold block uppercase tracking-wider text-red-600">Statutory Status</span>
              <strong className="text-sm font-extrabold">NON-COMPLIANT</strong>
            </div>
          </div>
        );
      default:
        return (
          <div className="flex items-center gap-2 bg-amber-50 text-amber-900 border border-amber-300 px-4 py-2 rounded-xl">
            <AlertTriangle className="w-5 h-5 text-amber-600" />
            <div>
              <span className="text-xs font-semibold block uppercase tracking-wider text-amber-700">Statutory Status</span>
              <strong className="text-sm font-extrabold">NEEDS VERIFICATION</strong>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Top action bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gov-200 pb-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/history')}
            className="p-2 rounded-lg border border-gov-200 bg-white hover:bg-gov-50 text-gov-700 transition-colors cursor-pointer"
            title="Back to inspections"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-gov-900">
                {inspection.product}
              </h1>
              <span className="font-mono text-xs font-bold bg-gov-100 text-gov-700 px-2 py-0.5 rounded">
                {inspection.id}
              </span>
            </div>
            <p className="text-xs text-gov-500 mt-0.5">
              Inspected on {inspection.date} &bull; Officer: {inspection.officer}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate(`/reports?id=${inspection.id}`)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-gov-300 bg-white px-3 py-2 text-xs font-semibold text-gov-700 hover:bg-gov-50 transition-colors cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>View Full Report</span>
          </button>

          <button
            onClick={handleDownloadPdf}
            disabled={downloading}
            className="inline-flex items-center gap-1.5 rounded-lg bg-gov-900 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-gov-800 transition-colors cursor-pointer disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{downloading ? 'Preparing PDF...' : 'Download PDF Report'}</span>
          </button>
        </div>
      </div>

      {/* Top Banner: Status & Compliance Score */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-2 rounded-2xl border border-gov-200 bg-white p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-bold text-gov-500 uppercase tracking-wider block mb-1">
              Automated Compliance Evaluation
            </span>
            <h2 className="text-lg font-bold text-gov-900">
              Legal Metrology Standard Review
            </h2>
            <p className="text-xs text-gov-500 mt-1 max-w-md">
              Evaluated against mandatory declarations under Rule 6 of the Legal Metrology (Packaged Commodities) Rules, 2011.
            </p>
          </div>

          <div className="flex-shrink-0">
            {getStatusBadge(effectiveStatus)}
          </div>
        </div>

        {/* Score Card */}
        <div className="rounded-2xl border border-gov-200 bg-white p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-gov-500 uppercase tracking-wider">
              Compliance Score
            </span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-gov-100 text-gov-700">
              Weighted
            </span>
          </div>

          <div className="my-2">
            <span className="text-3xl font-extrabold text-gov-900">
              {inspection.score}
            </span>
            <span className="text-sm font-semibold text-gov-400"> / 100</span>
          </div>

          {/* Breakdown */}
          <div className="space-y-1.5 text-[11px] text-gov-600 border-t border-gov-100 pt-2">
            <div className="flex justify-between">
              <span>Mandatory Declarations:</span>
              <strong className="text-gov-900">{inspection.breakdown.mandatory_declarations}%</strong>
            </div>
            <div className="flex justify-between">
              <span>Format Checks:</span>
              <strong className="text-gov-900">{inspection.breakdown.format_checks}%</strong>
            </div>
            <div className="flex justify-between">
              <span>Readability & Contrast:</span>
              <strong className="text-gov-900">{inspection.breakdown.readability}%</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Annotated Image & Extracted Information */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        {/* Left: Annotated Image */}
        <AnnotatedImage
          imageData={inspection.image_data}
          productName={inspection.product}
          boxes={inspection.bounding_boxes}
          declarations={inspection.declarations}
        />

        {/* Right: Extracted Declarations Table */}
        <div className="rounded-xl border border-gov-200 bg-white p-5 shadow-xs space-y-4">
          <div className="border-b border-gov-100 pb-3 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-gov-900">Extracted Product Information</h3>
              <p className="text-xs text-gov-500">Optical Character Recognition & Semantic Entities</p>
            </div>
            <span className="text-[11px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
              OCR Engine
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-gov-50 text-[11px] font-semibold uppercase text-gov-500 border-b border-gov-200">
                <tr>
                  <th className="py-2.5 px-3">Field</th>
                  <th className="py-2.5 px-3">Extracted Value</th>
                  <th className="py-2.5 px-3 text-right">Confidence</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gov-100 text-gov-700">
                {inspection.declarations.map((decl, i) => (
                  <tr key={i} className="hover:bg-gov-50/50">
                    <td className="py-2.5 px-3 font-semibold text-gov-900">
                      {decl.label}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={decl.status === 'fail' ? 'text-red-600 font-bold' : (decl.status === 'warning' ? 'text-amber-700 font-semibold' : '')}>
                        {decl.value}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <span className={`inline-block font-mono font-bold px-1.5 py-0.5 rounded text-[10px] ${
                        decl.confidence >= 0.9 ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                        (decl.confidence >= 0.7 ? 'bg-amber-50 text-amber-700 border border-amber-200' : 'bg-red-50 text-red-700 border border-red-200')
                      }`}>
                        {Math.round(decl.confidence * 100)}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {inspection.ocr_text && (
            <div className="mt-3 p-2.5 bg-gov-50 rounded-lg border border-gov-200/80 text-[11px] font-mono text-gov-600">
              <span className="font-sans font-bold text-gov-700 block mb-1">Raw OCR Stream:</span>
              <p className="line-clamp-2">{inspection.ocr_text}</p>
            </div>
          )}
        </div>
      </div>

      {/* Compliance Checklist Table */}
      <div className="rounded-xl border border-gov-200 bg-white p-5 shadow-xs space-y-4">
        <div className="border-b border-gov-100 pb-3 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-gov-900">Compliance Check</h3>
            <p className="text-xs text-gov-500">
              Validation against Legal Metrology (Packaged Commodities) statutory specifications
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigate('/rules')}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-gov-700 bg-gov-100 hover:bg-gov-200 px-2.5 py-1 rounded transition-colors cursor-pointer"
            title="Inspect full Legal Metrology Rules, 2011 specifications"
          >
            <span>Rule 6 &amp; 9 Criteria &bull; Standards Toolkit &rarr;</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-gov-50 text-[11px] font-semibold uppercase text-gov-500 border-b border-gov-200">
              <tr>
                <th className="py-3 px-4">Requirement</th>
                <th className="py-3 px-4">Result</th>
                <th className="py-3 px-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gov-100">
              {inspection.checks.map((chk, i) => (
                <tr key={i} className="hover:bg-gov-50/50">
                  <td className="py-3 px-4 font-semibold text-gov-900">
                    {chk.requirement}
                  </td>
                  <td className="py-3 px-4 text-gov-600">
                    {chk.result}
                  </td>
                  <td className="py-3 px-4 text-right">
                    {chk.status === 'COMPLIANT' ? (
                      <span className="inline-flex items-center gap-1 font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 text-[11px]">
                        <Check className="w-3 h-3" />
                        COMPLIANT
                      </span>
                    ) : chk.status === 'NON-COMPLIANT' ? (
                      <span className="inline-flex items-center gap-1 font-bold text-red-700 bg-red-50 px-2.5 py-1 rounded-full border border-red-200 text-[11px]">
                        <XCircle className="w-3 h-3" />
                        NON-COMPLIANT
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 font-bold text-amber-800 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200 text-[11px]">
                        <AlertTriangle className="w-3 h-3" />
                        NEEDS VERIFICATION
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detected Violations Section */}
      {inspection.violations && inspection.violations.length > 0 && (
        <div className="rounded-xl border border-red-200 bg-red-50/30 p-5 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-red-100 pb-3">
            <ShieldAlert className="w-5 h-5 text-red-600" />
            <div>
              <h3 className="text-base font-bold text-red-900">Detected Violations</h3>
              <p className="text-xs text-red-700">Possible statutory infractions flagged by automated rule check</p>
            </div>
          </div>

          <div className="space-y-3">
            {inspection.violations.map((v, i) => (
              <div key={i} className="rounded-lg bg-white border border-red-200 p-4 shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white bg-red-600 px-2 py-0.5 rounded">
                      Violation 0{i + 1}
                    </span>
                    <strong className="text-sm font-bold text-gov-900">{v.title}</strong>
                  </div>
                  <span className="text-xs font-bold text-red-700 bg-red-50 px-2.5 py-0.5 rounded-full border border-red-200">
                    {v.status}
                  </span>
                </div>

                <p className="text-xs text-gov-700 mb-3 leading-relaxed">
                  <strong>Reason:</strong> {v.reason}
                </p>

                <div className="flex items-center justify-between text-[11px] text-gov-500 border-t border-gov-100 pt-2 font-medium">
                  <span><strong>Statutory Rule:</strong> {v.rule}</span>
                  <span className="text-red-600 font-semibold">Severity: {v.severity || 'Critical'}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Section 12: Mandatory Legal Disclaimer */}
      <div className="rounded-xl border border-blue-200 bg-blue-50/60 p-4 flex items-start gap-3 text-xs text-blue-900">
        <Info className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-semibold">
            Important AI Advisory Notice:
          </p>
          <p className="text-blue-800 leading-relaxed">
            “VidhiCheck provides AI-assisted compliance analysis. Final enforcement decisions should be verified by an authorized officer.”
          </p>
          <p className="text-[11px] text-blue-700 font-mono mt-1">
            Standard Governance Workflow: <strong>AI Analysis → Officer Verification → Final Decision</strong>
          </p>
        </div>
      </div>

      {/* Section 13: Officer Verification Section */}
      <div className="rounded-2xl border border-gov-200 bg-white p-6 shadow-xs space-y-5">
        <div className="border-b border-gov-100 pb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-gov-900" />
            <div>
              <h3 className="text-base font-bold text-gov-900">Officer Verification</h3>
              <p className="text-xs text-gov-500">Confirm or modify automated findings before legal report signoff</p>
            </div>
          </div>

          {verificationSubmitted && (
            <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
              <CheckCheck className="w-3.5 h-3.5" />
              Verified &amp; Recorded
            </span>
          )}
        </div>

        <form onSubmit={handleOfficerVerification} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-gov-800 mb-2">
              Statutory Enforcement Action
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => setOfficerDecision('Confirm Violation')}
                className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                  officerDecision === 'Confirm Violation'
                    ? 'bg-red-600 text-white border-red-600 shadow-sm'
                    : 'bg-white text-red-700 border-red-200 hover:bg-red-50'
                }`}
              >
                <XCircle className="w-4 h-4" />
                <span>Confirm Violation</span>
              </button>

              <button
                type="button"
                onClick={() => setOfficerDecision('Reject Violation')}
                className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                  officerDecision === 'Reject Violation'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                    : 'bg-white text-emerald-700 border-emerald-200 hover:bg-emerald-50'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Reject Violation</span>
              </button>

              <button
                type="button"
                onClick={() => setOfficerDecision('Needs Manual Review')}
                className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                  officerDecision === 'Needs Manual Review'
                    ? 'bg-amber-500 text-white border-amber-500 shadow-sm'
                    : 'bg-white text-amber-800 border-amber-200 hover:bg-amber-50'
                }`}
              >
                <AlertTriangle className="w-4 h-4" />
                <span>Needs Manual Review</span>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gov-800 mb-1.5">
              Add Officer Remarks
            </label>
            <textarea
              rows={3}
              value={officerRemarks}
              onChange={(e) => setOfficerRemarks(e.target.value)}
              placeholder="e.g. Consumer care declaration was not visible in the submitted package image. Notice recommended under Rule 6(1)(n)."
              className="w-full rounded-xl border border-gov-300 p-3 text-xs text-gov-900 focus:border-gov-900 focus:outline-none focus:ring-1 focus:ring-gov-900"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <div className="text-xs text-gov-600">
              {inspection.final_status ? (
                <span>Recorded Final Status: <strong>{inspection.final_status}</strong></span>
              ) : (
                <span>Awaiting officer sign-off</span>
              )}
            </div>

            <button
              type="submit"
              disabled={!officerDecision}
              className="inline-flex items-center gap-2 rounded-lg bg-gov-900 px-5 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-gov-800 transition-colors cursor-pointer disabled:opacity-40"
            >
              <UserCheck className="w-4 h-4" />
              <span>Submit Verification</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
