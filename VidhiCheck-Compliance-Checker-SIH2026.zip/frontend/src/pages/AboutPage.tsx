import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Shield, 
  ScanLine, 
  Cpu, 
  FileCheck, 
  UserCheck, 
  FileText, 
  Code2,
  Database,
  Layers,
  Sparkles,
  BookOpen,
  Scale,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export const AboutPage: React.FC = () => {
  const steps = [
    { title: '1. Scan', desc: 'Officer uploads label image or selects inspection sample', icon: ScanLine },
    { title: '2. OCR', desc: 'Computer vision & OCR extracts raw packaging text', icon: Cpu },
    { title: '3. Extract', desc: 'Entities parsed: MRP, Net Qty, Mfg Date, Packer, Helpline', icon: Layers },
    { title: '4. Check', desc: 'Rules engine evaluates compliance against LM (PC) Rules, 2011', icon: FileCheck },
    { title: '5. Verify', desc: 'Officer reviews findings, confirms/rejects violations & adds remarks', icon: UserCheck },
    { title: '6. Report', desc: 'Generates official Form A/B compliance dossier in PDF', icon: FileText },
  ];

  const techStack = [
    { name: 'React 18 & TypeScript', role: 'Frontend UI', desc: 'Modern government inspection interface with Tailwind CSS, Lucide icons, and Recharts.' },
    { name: 'Python & FastAPI', role: 'Backend API', desc: 'High-performance asynchronous REST endpoints for analysis, verification, and audit logs.' },
    { name: 'OpenCV & OCR', role: 'Computer Vision', desc: 'Image contrast enhancement, adaptive thresholding, and OCR extraction with heuristic fallback.' },
    { name: 'SQLite Database', role: 'Data Persistence', desc: 'Lightweight schema storing inspections, declarations, violations, and officer verification records.' },
    { name: 'ReportLab Engine', role: 'PDF Dossier Generator', desc: 'Produces tamper-evident compliance inspection reports adhering to Seventh Schedule standards.' },
    { name: 'Rules Engine', role: 'Compliance Core', desc: 'Configurable rules matching G.S.R. 202(E) provisions of The Legal Metrology Act, 2009.' },
  ];

  const statutoryRules = [
    {
      rule: 'Rule 6(1)(a) & Rule 10',
      title: 'Name & Address of Manufacturer / Packer',
      desc: 'Complete postal address with factory location, city, state, and Postal Index Number [PIN] Code. Importer address required for foreign goods.'
    },
    {
      rule: 'Rule 6(1)(b)',
      title: 'Common or Generic Commodity Name',
      desc: 'Plain and conspicuous declaration of the commodity name contained in the package on the principal display panel.'
    },
    {
      rule: 'Rule 6(1)(c) & Rule 13',
      title: 'Net Quantity in Standard SI Metric Units',
      desc: 'Quantity declared strictly in standard metric units (g, kg, ml, L, N, U). Non-standard units (dozen, gross) or qualifiers ("approx.", "average") are prohibited.'
    },
    {
      rule: 'Rule 6(1)(d)',
      title: 'Month & Year of Manufacture / Packing',
      desc: 'Pre-packing or manufacture date expressed clearly in numerals or words (e.g. 08/2026) to inform the consumer.'
    },
    {
      rule: 'Rule 6(1)(e) & Rule 2(m)',
      title: 'Maximum Retail Price (MRP inclusive of all taxes)',
      desc: 'Printed in the statutory format "MRP Rs./₹ ... incl. of all taxes" with permissible rounding-off guidelines.'
    },
    {
      rule: 'Rule 6(2)',
      title: 'Consumer Care & Grievance Contact Details',
      desc: 'Mandatory name, address, telephone number, or email address of the consumer grievance redressal cell.'
    },
    {
      rule: 'Rule 7 & Rule 9(1)',
      title: 'Conspicuous Legibility & Minimum Font Size',
      desc: 'Declarations must contrast conspicuously against the background. Numerals must adhere to minimum height tables (Table I / Table II).'
    },
    {
      rule: 'Second Schedule',
      title: 'Prescribed Standard Pack Sizes',
      desc: 'Commodities like biscuits (100g, 200g), rice/atta (1kg, 2kg, 5kg), and edible oils must be packed in specified standard quantities.'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      {/* Header */}
      <div className="border-b border-gov-200 pb-5">
        <div className="flex items-center gap-3 mb-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gov-900 text-white shadow-xs">
            <Shield className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-gov-900">
              About VidhiCheck
            </h1>
            <p className="text-xs text-gov-500 font-medium">
              Smart India Hackathon (SIH 2026) Prototype &bull; Ministry of Consumer Affairs, Food &amp; Public Distribution
            </p>
          </div>
        </div>

        <p className="text-sm text-gov-700 mt-3 leading-relaxed max-w-2xl">
          <strong>VidhiCheck</strong> is an AI-assisted packaged commodity compliance checker built for <strong>Legal Metrology officers</strong>. It automates label verification against statutory requirements, highlights potential infractions, and generates tamper-evident audit dossiers.
        </p>
      </div>

      {/* Enforcement Workflow */}
      <div className="rounded-2xl border border-gov-200 bg-white p-6 shadow-xs space-y-5">
        <div>
          <h2 className="text-base font-bold text-gov-900">Inspection &amp; Verification Pipeline</h2>
          <p className="text-xs text-gov-500">End-to-end statutory examination process</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {steps.map((s, idx) => {
            const Icon = s.icon;
            return (
              <div key={idx} className="rounded-xl border border-gov-200 bg-gov-50/60 p-4 flex flex-col justify-between">
                <div>
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gov-900 text-white mb-2.5">
                    <Icon className="w-4 h-4" />
                  </div>
                  <h3 className="text-xs font-bold text-gov-900">{s.title}</h3>
                  <p className="text-[11px] text-gov-600 mt-1 leading-snug">{s.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-200 text-xs text-blue-900 flex items-center gap-2.5">
          <Scale className="w-4 h-4 text-blue-600 flex-shrink-0" />
          <span>
            <strong>Statutory Human-in-the-Loop Architecture:</strong> VidhiCheck enforces <em>AI Analysis &rarr; Officer Verification &rarr; Final Enforcement Decision</em>. As required by law, only an authorized officer can confirm a violation or issue statutory notices.
          </span>
        </div>
      </div>

      {/* Official Legal Metrology Framework Reference */}
      <div className="rounded-2xl border border-gov-200 bg-white p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gov-100 pb-3">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-gov-900" />
            <h2 className="text-base font-bold text-gov-900">Statutory Legal Framework (G.S.R. 202(E))</h2>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold bg-gov-100 text-gov-700 px-2.5 py-1 rounded">
              The Legal Metrology (Packaged Commodities) Rules, 2011
            </span>
            <Link
              to="/rules"
              className="text-xs font-bold text-blue-700 hover:text-blue-900 bg-blue-50 hover:bg-blue-100 px-2.5 py-1 rounded border border-blue-200 transition-colors"
            >
              Open Rules &amp; Calculators &rarr;
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-1">
          {statutoryRules.map((r, i) => (
            <div key={i} className="p-3.5 rounded-xl border border-gov-200 bg-gov-50/50 hover:bg-gov-50 transition-colors">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-gov-900">{r.title}</span>
                <span className="font-mono text-[10px] font-bold bg-gov-200 text-gov-800 px-1.5 py-0.5 rounded">
                  {r.rule}
                </span>
              </div>
              <p className="text-[11px] text-gov-600 leading-relaxed mt-1">
                {r.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Technology Stack Grid */}
      <div className="rounded-2xl border border-gov-200 bg-white p-6 shadow-xs space-y-4">
        <div>
          <h2 className="text-base font-bold text-gov-900">System Technology Stack</h2>
          <p className="text-xs text-gov-500">Robust, lightweight, and dependency-resilient architecture</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {techStack.map((tech, idx) => (
            <div key={idx} className="rounded-xl border border-gov-200 p-4 hover:border-gov-400 transition-colors">
              <span className="text-[10px] font-bold uppercase tracking-wider text-gov-500 block mb-1">
                {tech.role}
              </span>
              <h3 className="text-sm font-bold text-gov-900 mb-1">{tech.name}</h3>
              <p className="text-xs text-gov-600 leading-relaxed">{tech.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
