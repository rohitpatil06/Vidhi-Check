import { Inspection, DashboardStats, SAMPLE_PRODUCTS, INITIAL_INSPECTIONS } from '../data/demoData';

const BASE_URL = '/api';
const STORAGE_KEY = 'vidhicheck_inspections_cache';

// Local storage helpers
function getCachedInspections(): Inspection[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_INSPECTIONS));
      return INITIAL_INSPECTIONS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_INSPECTIONS;
  }
}

function saveCachedInspections(inspections: Inspection[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(inspections));
  } catch (e) {
    console.warn('Failed to save to local storage', e);
  }
}

export const api = {
  async checkBackendHealth(): Promise<boolean> {
    try {
      const res = await fetch(`${BASE_URL}/health`, { signal: AbortSignal.timeout(1500) });
      return res.ok;
    } catch {
      return false;
    }
  },

  async getDashboard(): Promise<DashboardStats> {
    try {
      const res = await fetch(`${BASE_URL}/dashboard`, { signal: AbortSignal.timeout(3000) });
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      console.info('Backend unavailable, using demo dashboard state.');
    }

    // Fallback calculation from cache
    const inspections = getCachedInspections();
    const compliant = inspections.filter(i => (i.final_status || i.status) === 'Compliant').length;
    const nonCompliant = inspections.filter(i => (i.final_status || i.status) === 'Non-Compliant').length;
    const needsVerification = inspections.filter(i => (i.final_status || i.status) === 'Needs Verification').length;

    return {
      total: 125 + inspections.length,
      compliant: 80 + compliant,
      non_compliant: 30 + nonCompliant,
      needs_verification: 15 + needsVerification,
      recent: inspections.slice(0, 5)
    };
  },

  async getInspections(): Promise<Inspection[]> {
    try {
      const res = await fetch(`${BASE_URL}/inspections`, { signal: AbortSignal.timeout(3000) });
      if (res.ok) {
        const data = await res.json();
        saveCachedInspections(data);
        return data;
      }
    } catch (e) {
      console.info('Backend unavailable, using demo inspection history.');
    }
    return getCachedInspections();
  },

  async getInspectionById(id: string): Promise<Inspection | null> {
    try {
      const res = await fetch(`${BASE_URL}/inspections/${id}`, { signal: AbortSignal.timeout(3000) });
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      console.info('Backend unavailable, reading from cached records.');
    }

    const cached = getCachedInspections();
    const found = cached.find(i => i.id === id);
    if (found) return found;

    // Check predefined
    const sample = Object.values(SAMPLE_PRODUCTS).find(p => p.id === id);
    return sample || null;
  },

  async analyzeProduct(file?: File, sampleId?: string): Promise<Inspection> {
    try {
      const formData = new FormData();
      if (file) {
        formData.append('file', file);
      }
      if (sampleId) {
        formData.append('sample_id', sampleId);
      }
      formData.append('officer', localStorage.getItem('vidhicheck_officer') || 'officer001');

      const res = await fetch(`${BASE_URL}/analyze`, {
        method: 'POST',
        body: formData,
        signal: AbortSignal.timeout(10000)
      });

      if (res.ok) {
        const data = await res.json();
        const cached = getCachedInspections();
        saveCachedInspections([data, ...cached.filter(i => i.id !== data.id)]);
        return data;
      }
    } catch (e) {
      console.warn('Backend analyze call failed, falling back to local simulation mode:', e);
    }

    // Client-side fallback
    const id = `VC-${Math.floor(10000 + Math.random() * 90000)}`;
    const today = new Date().toISOString().split('T')[0];

    let baseSample: Inspection;
    if (sampleId && SAMPLE_PRODUCTS[sampleId]) {
      baseSample = SAMPLE_PRODUCTS[sampleId];
    } else {
      baseSample = SAMPLE_PRODUCTS.sample_rice;
    }

    // Read image if file provided
    let imageDataUrl: string | null = null;
    if (file) {
      imageDataUrl = await new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target?.result as string);
        reader.onerror = () => resolve(null);
        reader.readAsDataURL(file);
      });
    }

    const simulated: Inspection = {
      ...baseSample,
      id,
      product: file ? `Packaged Product (${file.name.replace(/\.[^/.]+$/, "")})` : baseSample.product,
      date: today,
      image_data: imageDataUrl || baseSample.image_data,
      remarks: '',
      final_status: null
    };

    const cached = getCachedInspections();
    saveCachedInspections([simulated, ...cached]);
    return simulated;
  },

  async verifyInspection(inspectionId: string, decision: string, remarks: string): Promise<Inspection> {
    try {
      const res = await fetch(`${BASE_URL}/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          inspection_id: inspectionId,
          decision,
          remarks,
          officer: localStorage.getItem('vidhicheck_officer') || 'officer001'
        }),
        signal: AbortSignal.timeout(3000)
      });

      if (res.ok) {
        // refresh
        const refreshed = await this.getInspectionById(inspectionId);
        if (refreshed) return refreshed;
      }
    } catch (e) {
      console.warn('Backend verify call failed, updating local state:', e);
    }

    // Local fallback update
    let final_status = 'Needs Verification';
    if (decision === 'Confirm Violation') final_status = 'Non-Compliant';
    if (decision === 'Reject Violation') final_status = 'Compliant';

    const cached = getCachedInspections();
    const updated = cached.map(item => {
      if (item.id === inspectionId) {
        return {
          ...item,
          remarks,
          final_status,
          status: final_status as 'Compliant' | 'Non-Compliant' | 'Needs Verification'
        };
      }
      return item;
    });

    saveCachedInspections(updated);
    const target = updated.find(i => i.id === inspectionId);
    return target || cached[0];
  },

  async downloadReportPdf(inspection: Inspection) {
    // Try backend stream download first
    try {
      const res = await fetch(`${BASE_URL}/report/${inspection.id}`, { signal: AbortSignal.timeout(5000) });
      if (res.ok) {
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `VidhiCheck_Report_${inspection.id}.pdf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        return;
      }
    } catch (e) {
      console.info('Backend PDF download unavailable, triggering browser print report.', e);
    }

    // Direct browser print window as graceful fallback
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Please allow pop-ups to view/print the compliance report.');
      return;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>VidhiCheck Report — ${inspection.id}</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; padding: 36px; color: #0f172a; line-height: 1.5; }
          .header { text-align: center; border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 24px; }
          .title { font-size: 22px; font-weight: bold; letter-spacing: 1px; }
          .subtitle { font-size: 13px; color: #475569; margin-top: 4px; }
          .meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; background: #f8fafc; padding: 14px; border: 1px solid #e2e8f0; border-radius: 6px; margin-bottom: 24px; }
          .section-title { font-size: 14px; font-weight: bold; margin: 18px 0 8px 0; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 12px; }
          th { background: #1e293b; color: white; text-align: left; padding: 8px; }
          td { padding: 8px; border: 1px solid #cbd5e1; }
          tr:nth-child(even) { background: #f8fafc; }
          .badge { font-weight: bold; padding: 2px 6px; border-radius: 4px; }
          .badge-compliant { color: #166534; }
          .badge-violation { color: #991b1b; }
          .badge-review { color: #854d0e; }
          .footer { margin-top: 36px; text-align: center; font-size: 11px; color: #64748b; border-top: 1px solid #e2e8f0; padding-top: 12px; }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="title">VIDHICHECK</div>
          <div class="subtitle">DIRECTORATE OF LEGAL METROLOGY &bull; PACKAGED COMMODITIES COMPLIANCE REPORT</div>
          <div class="subtitle">Statutory Verification under The Legal Metrology (Packaged Commodities) Rules, 2011</div>
        </div>
        <div class="meta-grid">
          <div><strong>Inspection ID:</strong> ${inspection.id}</div>
          <div><strong>Date:</strong> ${inspection.date}</div>
          <div><strong>Product:</strong> ${inspection.product}</div>
          <div><strong>Officer:</strong> ${inspection.officer}</div>
          <div><strong>Compliance Score:</strong> ${inspection.score} / 100</div>
          <div><strong>Final Status:</strong> <span class="badge ${inspection.status === 'Compliant' ? 'badge-compliant' : (inspection.status === 'Non-Compliant' ? 'badge-violation' : 'badge-review')}">${(inspection.final_status || inspection.status).toUpperCase()}</span></div>
        </div>

        <div class="section-title">1. Extracted Label Declarations</div>
        <table>
          <thead>
            <tr><th>Field</th><th>Extracted Value</th><th>Confidence</th><th>Status</th></tr>
          </thead>
          <tbody>
            ${inspection.declarations.map(d => `
              <tr>
                <td>${d.label}</td>
                <td>${d.value}</td>
                <td>${Math.round(d.confidence * 100)}%</td>
                <td>${d.status.toUpperCase()}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <div class="section-title">2. Legal Metrology Compliance Checks</div>
        <table>
          <thead>
            <tr><th>Requirement</th><th>Result</th><th>Status</th></tr>
          </thead>
          <tbody>
            ${inspection.checks.map(c => `
              <tr>
                <td>${c.requirement}</td>
                <td>${c.result}</td>
                <td><strong>${c.status}</strong></td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <div class="section-title">3. Officer Verification & Remarks</div>
        <div style="background: #f1f5f9; padding: 12px; border: 1px solid #cbd5e1; border-radius: 4px;">
          <p><strong>Decision:</strong> ${(inspection.final_status || inspection.status).toUpperCase()}</p>
          <p><strong>Officer Remarks:</strong> ${inspection.remarks || 'No additional remarks recorded.'}</p>
        </div>

        <div class="footer">
          Generated by VidhiCheck — AI-Assisted Packaged Commodity Compliance Checker<br/>
          <em>Legal Notice: Final statutory enforcement decisions must be verified by an authorized Legal Metrology officer.</em>
        </div>
        <script>
          window.onload = function() { window.print(); }
        </script>
      </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  }
};
