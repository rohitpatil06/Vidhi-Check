import sqlite3
import json
import os
import logging
from datetime import datetime
from typing import List, Optional, Dict, Any

logger = logging.getLogger("VidhiCheck.Database")
DB_PATH = os.path.join(os.path.dirname(__file__), "vidhicheck.db")

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS inspections (
        id TEXT PRIMARY KEY,
        product_name TEXT NOT NULL,
        date TEXT NOT NULL,
        officer TEXT NOT NULL,
        status TEXT NOT NULL,
        score INTEGER NOT NULL,
        passed_checks INTEGER DEFAULT 0,
        total_checks INTEGER DEFAULT 0,
        ocr_text TEXT,
        image_data TEXT,
        bounding_boxes_json TEXT,
        rule_checks_json TEXT
    );
    """)

    # Schema migration checks for existing database
    cursor.execute("PRAGMA table_info(inspections)")
    cols = [row[1] for row in cursor.fetchall()]
    if "passed_checks" not in cols:
        cursor.execute("ALTER TABLE inspections ADD COLUMN passed_checks INTEGER DEFAULT 0")
    if "total_checks" not in cols:
        cursor.execute("ALTER TABLE inspections ADD COLUMN total_checks INTEGER DEFAULT 0")
    if "bounding_boxes_json" not in cols:
        cursor.execute("ALTER TABLE inspections ADD COLUMN bounding_boxes_json TEXT")
    if "rule_checks_json" not in cols:
        cursor.execute("ALTER TABLE inspections ADD COLUMN rule_checks_json TEXT")
    if "image_data" not in cols:
        cursor.execute("ALTER TABLE inspections ADD COLUMN image_data TEXT")

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS declarations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        inspection_id TEXT NOT NULL,
        field_name TEXT NOT NULL,
        label TEXT NOT NULL,
        value TEXT NOT NULL,
        confidence REAL NOT NULL,
        source TEXT DEFAULT 'Product Label',
        status TEXT NOT NULL,
        FOREIGN KEY (inspection_id) REFERENCES inspections (id)
    );
    """)

    cursor.execute("PRAGMA table_info(declarations)")
    decl_cols = [row[1] for row in cursor.fetchall()]
    if "source" not in decl_cols:
        cursor.execute("ALTER TABLE declarations ADD COLUMN source TEXT DEFAULT 'Product Label'")

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS violations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        inspection_id TEXT NOT NULL,
        rule_name TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        severity TEXT NOT NULL,
        status TEXT NOT NULL,
        evidence TEXT DEFAULT '',
        FOREIGN KEY (inspection_id) REFERENCES inspections (id)
    );
    """)

    cursor.execute("PRAGMA table_info(violations)")
    viol_cols = [row[1] for row in cursor.fetchall()]
    if "evidence" not in viol_cols:
        cursor.execute("ALTER TABLE violations ADD COLUMN evidence TEXT DEFAULT ''")

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS verification (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        inspection_id TEXT UNIQUE NOT NULL,
        officer_remark TEXT NOT NULL,
        final_status TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (inspection_id) REFERENCES inspections (id)
    );
    """)

    conn.commit()

    cursor.execute("SELECT COUNT(*) FROM inspections")
    count = cursor.fetchone()[0]
    if count == 0:
        seed_baseline_cases(cursor)
        conn.commit()

    conn.close()
    logger.info("[Database] SQLite initialized successfully.")

def seed_baseline_cases(cursor):
    """Seed deterministic baseline cases for SIH demonstration."""
    case1_checks = [
        {"rule_number": "Rule 6(1)(b)", "requirement": "Generic or Common Commodity Name", "detected_value": "Heritage Basmati Rice", "evidence": "Evidence: Detected on label.", "status": "PASS", "reason": "Commodity name plainly declared on principal display panel."},
        {"rule_number": "Rule 6(1)(a) read with Rule 10", "requirement": "Manufacturer / Packer Details", "detected_value": "Heritage Foods Ltd, G.T. Road, Karnal - 132001", "evidence": "Evidence: Factory address & PIN code visible.", "status": "PASS", "reason": "Conforms to complete postal address with PIN code."},
        {"rule_number": "Rule 6(1)(c)", "requirement": "Net Quantity in Standard Units", "detected_value": "5 kg", "evidence": "Evidence: 'Net Qty: 5 kg' visible.", "status": "PASS", "reason": "Standard SI metric units (kg)."},
        {"rule_number": "Rule 6(1)(e)", "requirement": "Maximum Retail Price (MRP)", "detected_value": "₹450.00 (incl. of all taxes)", "evidence": "Evidence: Inclusive of all taxes visible.", "status": "PASS", "reason": "Statutory MRP format verified."},
        {"rule_number": "Rule 6(1)(d)", "requirement": "Month & Year of Packing/Mfg", "detected_value": "08/2026", "evidence": "Evidence: 'Packed: 08/2026' visible.", "status": "PASS", "reason": "Pre-packing date expressed clearly in numerals."},
        {"rule_number": "Rule 6(2)", "requirement": "Consumer Care / Grievance Details", "detected_value": "1800-425-9000, care@heritage.in", "evidence": "Evidence: Toll-free helpline visible.", "status": "PASS", "reason": "Customer care telephone and email verified."},
        {"rule_number": "Rule 6(1)(a)", "requirement": "Country of Origin", "detected_value": "India", "evidence": "Evidence: 'Made in India' visible.", "status": "PASS", "reason": "Country of origin plainly displayed."},
        {"rule_number": "Rule 7 & Rule 9(1)", "requirement": "Label Legibility & Visual Contrast", "detected_value": "High optical contrast", "evidence": "Evidence: High sharpness and contrast.", "status": "PASS", "reason": "Numerals contrast conspicuously with background."}
    ]
    cursor.execute("""
        INSERT OR REPLACE INTO inspections (id, product_name, date, officer, status, score, passed_checks, total_checks, ocr_text, rule_checks_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        "VC-001", "Heritage Basmati Rice", "2026-09-10", "officer001", "Compliant", 100, 8, 8,
        "HERITAGE BASMATI RICE | NET WT: 5 kg | MRP ₹450.00 INCL ALL TAXES | PACKED: 08/2026 | HERITAGE FOODS LTD, G.T. ROAD, KARNAL - 132001 | CARE: 1800-425-9000 | MADE IN INDIA",
        json.dumps(case1_checks)
    ))
    cursor.execute("""
        INSERT OR REPLACE INTO verification (inspection_id, officer_remark, final_status, updated_at) VALUES (?, ?, ?, ?)
    """, ("VC-001", "Physical label verified. All 8 statutory declarations conform to Rule 6.", "Compliant", "2026-09-10 10:00:00"))

    c1_decls = [
        ("product_name", "Commodity Name", "Heritage Basmati Rice", 0.99, "Product Label", "pass"),
        ("manufacturer", "Manufacturer / Packer", "Heritage Foods Ltd, Karnal - 132001", 0.96, "Product Label", "pass"),
        ("net_quantity", "Net Quantity", "5 kg", 0.98, "Product Label", "pass"),
        ("mrp", "Maximum Retail Price", "₹450.00 (incl. of all taxes)", 0.97, "Product Label", "pass"),
        ("manufacturing_date", "Date of Packing / Mfg", "08/2026", 0.95, "Product Label", "pass"),
        ("consumer_care", "Consumer Care Helpline", "1800-425-9000, care@heritage.in", 0.98, "Product Label", "pass"),
        ("country_of_origin", "Country of Origin", "India", 0.99, "Product Label", "pass")
    ]
    for d in c1_decls:
        cursor.execute("INSERT OR REPLACE INTO declarations (inspection_id, field_name, label, value, confidence, source, status) VALUES (?, ?, ?, ?, ?, ?, ?)",
                       ("VC-001", d[0], d[1], d[2], d[3], d[4], d[5]))

    case2_checks = [
        {"rule_number": "Rule 6(1)(b)", "requirement": "Generic or Common Commodity Name", "detected_value": "XYZ Biscuits", "evidence": "Evidence: Detected on label.", "status": "PASS", "reason": "Commodity name plainly declared."},
        {"rule_number": "Rule 6(1)(a)", "requirement": "Manufacturer Details", "detected_value": "ABC Foods Pvt Ltd, Mumbai - 400072", "evidence": "Evidence: Address with PIN visible.", "status": "PASS", "reason": "Address verified."},
        {"rule_number": "Rule 6(1)(c)", "requirement": "Net Quantity", "detected_value": "100 g", "evidence": "Evidence: '100 g' declared.", "status": "PASS", "reason": "Standard metric unit."},
        {"rule_number": "Rule 6(1)(e)", "requirement": "Maximum Retail Price", "detected_value": "₹50.00 (incl. of all taxes)", "evidence": "Evidence: 'MRP ₹50' visible.", "status": "PASS", "reason": "Taxes included."},
        {"rule_number": "Rule 6(1)(d)", "requirement": "Packing Date", "detected_value": "08/2026", "evidence": "Evidence: '08/2026' visible.", "status": "PASS", "reason": "Date verified."},
        {"rule_number": "Rule 6(2)", "requirement": "Consumer Care Details", "detected_value": "Not detected", "evidence": "Evidence: Not detected on scanned label.", "status": "POSSIBLE VIOLATION", "reason": "Mandatory consumer grievance telephone/email absent from package under Rule 6(2)."},
        {"rule_number": "Rule 6(1)(a)", "requirement": "Country of Origin", "detected_value": "India", "evidence": "Evidence: 'Made in India' visible.", "status": "PASS", "reason": "Country of origin verified."},
        {"rule_number": "Rule 9(1)", "requirement": "Label Legibility", "detected_value": "High contrast", "evidence": "Evidence: Clear typography.", "status": "PASS", "reason": "Conspicuous print."}
    ]
    cursor.execute("""
        INSERT OR REPLACE INTO inspections (id, product_name, date, officer, status, score, passed_checks, total_checks, ocr_text, rule_checks_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        "VC-002", "XYZ Biscuits", "2026-09-10", "officer001", "Non-Compliant", 88, 7, 8,
        "XYZ BISCUITS | NET QTY: 100 g | MRP ₹50.00 INCL ALL TAXES | PACKED: 08/2026 | ABC FOODS PVT LTD | [NO CONSUMER CARE DETAILS]",
        json.dumps(case2_checks)
    ))
    cursor.execute("""
        INSERT OR REPLACE INTO violations (inspection_id, rule_name, title, description, severity, status, evidence)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, ("VC-002", "Rule 6(2)", "Consumer Care Details Missing", "Mandatory consumer grievance contact details (telephone/email) was not detected on the scanned label.", "Critical", "Open", "Evidence: Not detected on scanned label."))
    cursor.execute("""
        INSERT OR REPLACE INTO verification (inspection_id, officer_remark, final_status, updated_at) VALUES (?, ?, ?, ?)
    """, ("VC-002", "Confirmed missing consumer care contact. Notice issued under Rule 6(2).", "Non-Compliant", "2026-09-10 11:30:00"))

    c2_decls = [
        ("product_name", "Commodity Name", "XYZ Biscuits", 0.98, "Product Label", "pass"),
        ("manufacturer", "Manufacturer / Packer", "ABC Foods Pvt Ltd, Mumbai - 400072", 0.94, "Product Label", "pass"),
        ("net_quantity", "Net Quantity", "100 g", 0.97, "Product Label", "pass"),
        ("mrp", "Maximum Retail Price", "₹50.00 (incl. of all taxes)", 0.96, "Product Label", "pass"),
        ("manufacturing_date", "Date of Packing / Mfg", "08/2026", 0.93, "Product Label", "pass"),
        ("consumer_care", "Consumer Care Helpline", "Missing / Not Found", 0.00, "Product Label", "fail"),
        ("country_of_origin", "Country of Origin", "India", 0.98, "Product Label", "pass")
    ]
    for d in c2_decls:
        cursor.execute("INSERT OR REPLACE INTO declarations (inspection_id, field_name, label, value, confidence, source, status) VALUES (?, ?, ?, ?, ?, ?, ?)",
                       ("VC-002", d[0], d[1], d[2], d[3], d[4], d[5]))

def format_inspection_row(row) -> Dict[str, Any]:
    row_keys = row.keys()
    boxes = json.loads(row["bounding_boxes_json"]) if ("bounding_boxes_json" in row_keys and row["bounding_boxes_json"]) else []
    rule_checks = json.loads(row["rule_checks_json"]) if ("rule_checks_json" in row_keys and row["rule_checks_json"]) else []

    checks = []
    for c in rule_checks:
        st = c.get("status", "PASS")
        front_st = "COMPLIANT" if st == "PASS" else ("NON-COMPLIANT" if st == "POSSIBLE VIOLATION" else "NEEDS VERIFICATION")
        checks.append({
            "requirement": c.get("requirement", ""),
            "result": c.get("detected_value", ""),
            "status": front_st
        })

    stat = row["status"]
    mand_score = 95 if stat == "Compliant" else (65 if stat == "Non-Compliant" else 80)
    fmt_score = 90 if stat == "Compliant" else (70 if stat == "Non-Compliant" else 75)
    read_score = 90 if stat == "Compliant" else (60 if stat == "Non-Compliant" else 55)

    passed = row["passed_checks"] if "passed_checks" in row_keys and row["passed_checks"] is not None else len([c for c in rule_checks if c.get("status") == "PASS"])
    total = row["total_checks"] if "total_checks" in row_keys and row["total_checks"] is not None else (len(rule_checks) or 8)

    return {
        "id": row["id"],
        "product": row["product_name"],
        "date": row["date"],
        "officer": row["officer"],
        "status": row["status"],
        "score": row["score"],
        "breakdown": {
            "mandatory_declarations": mand_score,
            "format_checks": fmt_score,
            "readability": read_score
        },
        "passed_checks": passed,
        "total_checks": total,
        "declarations": [],
        "checks": checks,
        "rule_checks": rule_checks,
        "violations": [],
        "bounding_boxes": boxes,
        "ocr_text": row["ocr_text"] if "ocr_text" in row_keys and row["ocr_text"] else "",
        "image_data": row["image_data"] if "image_data" in row_keys else None,
        "remarks": row["officer_remark"] if "officer_remark" in row_keys and row["officer_remark"] else "",
        "final_status": row["final_status"] if "final_status" in row_keys else None
    }

def get_inspection_by_id(inspection_id: str) -> Optional[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT i.id, i.product_name, i.date, i.officer, 
               COALESCE(v.final_status, i.status) as status, 
               i.score, i.passed_checks, i.total_checks, i.ocr_text, 
               i.bounding_boxes_json, i.rule_checks_json, i.image_data,
               v.officer_remark, v.final_status
        FROM inspections i
        LEFT JOIN verification v ON i.id = v.inspection_id
        WHERE i.id = ?
    """, (inspection_id,))
    row = cursor.fetchone()
    if not row:
        conn.close()
        return None

    data = format_inspection_row(row)

    # Declarations
    cursor.execute("""
        SELECT field_name as field, label, value, confidence, source, status
        FROM declarations WHERE inspection_id = ?
    """, (inspection_id,))
    data["declarations"] = [dict(d) for d in cursor.fetchall()]

    # Violations
    cursor.execute("""
        SELECT CAST(id AS TEXT) as id, rule_name as rule, title, description as reason, severity, status, evidence
        FROM violations WHERE inspection_id = ?
    """, (inspection_id,))
    data["violations"] = [dict(v) for v in cursor.fetchall()]

    conn.close()
    return data

def get_all_inspections() -> List[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT i.id, i.product_name, i.date, i.officer, 
               COALESCE(v.final_status, i.status) as status, 
               i.score, i.passed_checks, i.total_checks, i.ocr_text, 
               i.bounding_boxes_json, i.rule_checks_json, i.image_data,
               v.officer_remark, v.final_status
        FROM inspections i
        LEFT JOIN verification v ON i.id = v.inspection_id
        ORDER BY i.date DESC, i.id DESC
    """)
    rows = cursor.fetchall()
    
    results = []
    for r in rows:
        item = format_inspection_row(r)
        cursor.execute("SELECT field_name as field, label, value, confidence, source, status FROM declarations WHERE inspection_id = ?", (item["id"],))
        item["declarations"] = [dict(d) for d in cursor.fetchall()]
        cursor.execute("SELECT CAST(id AS TEXT) as id, rule_name as rule, title, description as reason, severity, status, evidence FROM violations WHERE inspection_id = ?", (item["id"],))
        item["violations"] = [dict(v) for v in cursor.fetchall()]
        results.append(item)

    conn.close()
    return results

def get_dashboard_data() -> Dict[str, Any]:
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM inspections")
    total = cursor.fetchone()[0]

    cursor.execute("""
        SELECT 
            SUM(CASE WHEN COALESCE(v.final_status, i.status) = 'Compliant' THEN 1 ELSE 0 END) as compliant,
            SUM(CASE WHEN COALESCE(v.final_status, i.status) = 'Non-Compliant' THEN 1 ELSE 0 END) as non_compliant,
            SUM(CASE WHEN COALESCE(v.final_status, i.status) = 'Needs Verification' THEN 1 ELSE 0 END) as needs_verification
        FROM inspections i
        LEFT JOIN verification v ON i.id = v.inspection_id
    """)
    row = cursor.fetchone()
    compliant = row["compliant"] or 0
    non_compliant = row["non_compliant"] or 0
    needs_verification = row["needs_verification"] or 0

    conn.close()

    recent = get_all_inspections()[:10]

    return {
        "total": 125 + total,
        "compliant": 80 + compliant,
        "non_compliant": 30 + non_compliant,
        "needs_verification": 15 + needs_verification,
        "recent": recent
    }

def save_inspection(data: Dict[str, Any]) -> str:
    conn = get_connection()
    cursor = conn.cursor()

    rule_checks = data.get("rule_checks", [])
    if not rule_checks and data.get("checks"):
        rule_checks = [
            {
                "rule_number": "Rule 6",
                "requirement": c.get("requirement", ""),
                "detected_value": c.get("result", ""),
                "evidence": f"Result: {c.get('result', '')}",
                "status": "PASS" if c.get("status") == "COMPLIANT" else ("POSSIBLE VIOLATION" if c.get("status") == "NON-COMPLIANT" else "NEEDS VERIFICATION"),
                "reason": "Statutory verification check."
            }
            for c in data["checks"]
        ]

    cursor.execute("""
        INSERT OR REPLACE INTO inspections 
        (id, product_name, date, officer, status, score, passed_checks, total_checks, ocr_text, image_data, bounding_boxes_json, rule_checks_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        data["id"],
        data["product"],
        data["date"],
        data["officer"],
        data["status"],
        data["score"],
        data.get("passed_checks", len([c for c in rule_checks if c.get("status") == "PASS"])),
        data.get("total_checks", len(rule_checks) or 8),
        data.get("ocr_text", ""),
        data.get("image_data"),
        json.dumps(data.get("bounding_boxes", [])),
        json.dumps(rule_checks)
    ))

    cursor.execute("DELETE FROM declarations WHERE inspection_id = ?", (data["id"],))
    cursor.execute("DELETE FROM violations WHERE inspection_id = ?", (data["id"],))

    for d in data.get("declarations", []):
        cursor.execute("""
            INSERT INTO declarations (inspection_id, field_name, label, value, confidence, source, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (data["id"], d["field"], d["label"], d["value"], float(d.get("confidence", 0.0)), d.get("source", "Product Label"), d.get("status", "DETECTED")))

    for v in data.get("violations", []):
        cursor.execute("""
            INSERT INTO violations (inspection_id, rule_name, title, description, severity, status, evidence)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (data["id"], v.get("rule", "Rule 6"), v["title"], v.get("reason", ""), v.get("severity", "Major"), v.get("status", "Open"), v.get("evidence", "")))

    conn.commit()
    conn.close()
    logger.info(f"[Database] Saved inspection {data['id']} for '{data['product']}' successfully.")
    return data["id"]

def save_verification(inspection_id: str, decision: str, remarks: str) -> Dict[str, Any]:
    conn = get_connection()
    cursor = conn.cursor()

    if decision == "Confirm Violation":
        final_status = "Non-Compliant"
    elif decision == "Reject Violation":
        final_status = "Compliant"
    else:
        final_status = "Needs Verification"

    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cursor.execute("""
        INSERT INTO verification (inspection_id, officer_remark, final_status, updated_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(inspection_id) DO UPDATE SET
            officer_remark = excluded.officer_remark,
            final_status = excluded.final_status,
            updated_at = excluded.updated_at
    """, (inspection_id, remarks, final_status, now_str))

    cursor.execute("UPDATE inspections SET status = ? WHERE id = ?", (final_status, inspection_id))

    conn.commit()
    conn.close()
    logger.info(f"[Database] Verification recorded for {inspection_id}: Final Status={final_status}")

    return {
        "inspection_id": inspection_id,
        "final_status": final_status,
        "officer_remark": remarks,
        "updated_at": now_str
    }

# Auto-initialize database schema on module import
try:
    init_db()
except Exception as e:
    logger.error(f"Failed to auto-init DB on import: {e}")
