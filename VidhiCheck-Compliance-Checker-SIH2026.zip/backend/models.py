from typing import List, Optional, Dict, Any, Union
from pydantic import BaseModel, Field

class DeclarationItem(BaseModel):
    field: str
    label: str
    value: str
    confidence: float
    source: str = "Product Label"
    status: str = "DETECTED"

class RuleCheckResult(BaseModel):
    rule_number: str
    requirement: str
    detected_value: str
    evidence: str
    status: str
    reason: str

class ComplianceCheck(BaseModel):
    requirement: str
    result: str
    status: str

class ViolationItem(BaseModel):
    id: Optional[Union[str, int]] = None
    rule: str
    title: str
    reason: str
    severity: str = "Major"
    status: str = "Open"
    evidence: str = ""

class BoundingBox(BaseModel):
    field: str
    label: str
    color: str
    x: float
    y: float
    width: float
    height: float

class ScoreBreakdown(BaseModel):
    mandatory_declarations: int = 90
    format_checks: int = 85
    readability: int = 85

class InspectionResponse(BaseModel):
    id: str
    product: str
    date: str
    officer: str
    status: str
    score: int
    passed_checks: int = 0
    total_checks: int = 8
    breakdown: Optional[ScoreBreakdown] = None
    declarations: List[DeclarationItem] = []
    checks: List[ComplianceCheck] = []
    rule_checks: List[RuleCheckResult] = []
    violations: List[ViolationItem] = []
    bounding_boxes: List[BoundingBox] = []
    ocr_text: str = ""
    image_data: Optional[str] = None
    remarks: str = ""
    final_status: Optional[str] = None

class VerificationRequest(BaseModel):
    inspection_id: str
    decision: str
    remarks: str
    officer: Optional[str] = "officer001"

class DashboardResponse(BaseModel):
    total: int
    compliant: int
    non_compliant: int
    needs_verification: int
    recent: List[InspectionResponse]
