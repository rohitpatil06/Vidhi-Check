import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

import database
from routes.inspections import router as inspections_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize database on startup
    database.init_db()
    yield

app = FastAPI(
    title="VidhiCheck API",
    description="AI-Based Packaged Commodity Compliance Checker Backend for Legal Metrology Officers",
    version="1.0.0",
    lifespan=lifespan
)

# Allow CORS for local frontend Vite server
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routes
app.include_router(inspections_router)

@app.get("/")
def root():
    return {
        "app": "VidhiCheck API",
        "status": "online",
        "version": "1.0.0",
        "tagline": "Scan. Verify. Comply.",
        "docs_url": "/docs"
    }

@app.get("/api/health")
def health_check():
    return {"status": "ok", "service": "VidhiCheck Backend", "database": "connected"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
