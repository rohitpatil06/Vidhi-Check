import io
from typing import Dict, Any
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

def generate_pdf_report(inspection_data: Dict[str, Any]) -> io.BytesIO:
    """
    Generate official Legal Metrology Compliance Inspection Report in PDF format.
    Models Form A/B data sheet principles under the Seventh Schedule of The Legal Metrology (Packaged Commodities) Rules, 2011.
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=36,
        leftMargin=36,
        topMargin=32,
        bottomMargin=32
    )

    styles = getSampleStyleSheet()
    
    # Custom styles
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=18,
        leading=22,
        textColor=colors.HexColor('#0F172A'),
        alignment=1 # Center
    )
    subtitle_style = ParagraphStyle(
        'DocSubtitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#334155'),
        alignment=1
    )
    gazette_style = ParagraphStyle(
        'GazetteNotice',
        parent=styles['Normal'],
        fontName='Helvetica-Oblique',
        fontSize=8,
        leading=11,
        textColor=colors.HexColor('#64748B'),
        alignment=1
    )
    h2_style = ParagraphStyle(
        'Heading2_Custom',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=11,
        leading=15,
        textColor=colors.HexColor('#1E293B'),
        spaceBefore=6,
        spaceAfter=3
    )
    body_style = ParagraphStyle(
        'Body_Custom',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=8.5,
        leading=11,
        textColor=colors.HexColor('#334155')
    )

    elements = []

    # Government Header
    elements.append(Paragraph("VIDHICHECK &bull; LEGAL METROLOGY INSPECTION DOSSIER", title_style))
    elements.append(Paragraph("DIRECTORATE OF LEGAL METROLOGY &bull; GOVERNMENT OF INDIA", subtitle_style))
    elements.append(Paragraph("Statutory Inspection Protocol under The Legal Metrology Act, 2009 &amp; The Legal Metrology (Packaged Commodities) Rules, 2011 (G.S.R. 202(E))", gazette_style))
    elements.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#0F172A'), spaceBefore=4, spaceAfter=8))

    # Meta Overview Table
    insp_id = inspection_data.get("id", "VC-000")
    product = inspection_data.get("product", "Unknown Product")
    date_val = inspection_data.get("date", "N/A")
    officer = inspection_data.get("officer", "officer001")
    status = inspection_data.get("final_status") or inspection_data.get("status", "Compliant")
    score = inspection_data.get("score", 85)

    status_color = colors.HexColor('#166534') if status == 'Compliant' else (colors.HexColor('#991B1B') if status == 'Non-Compliant' else colors.HexColor('#854D0E'))

    meta_data = [
        [
            Paragraph(f"<b>Inspection ID:</b> {insp_id}", body_style),
            Paragraph(f"<b>Audit Date:</b> {date_val}", body_style)
        ],
        [
            Paragraph(f"<b>Packaged Commodity:</b> {product}", body_style),
            Paragraph(f"<b>Authorized Officer ID:</b> {officer}", body_style)
        ],
        [
            Paragraph(f"<b>AI Compliance Score:</b> <b>{score} / 100</b>", body_style),
            Paragraph(f"<b>Official Statutory Status:</b> <font color='{status_color}'><b>{status.upper()}</b></font>", body_style)
        ]
    ]
    meta_table = Table(meta_data, colWidths=[270, 270])
    meta_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#F8FAFC')),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#CBD5E1')),
        ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor('#E2E8F0')),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
    ]))
    elements.append(meta_table)
    elements.append(Spacer(1, 8))

    # Section 1: Declarations Table
    elements.append(Paragraph("1. Extracted Label Declarations (Optical Character Recognition)", h2_style))
    decl_data = [["Declaration Field", "Extracted Label Value", "Confidence", "Statutory Rule"]]
    
    declarations = inspection_data.get("declarations", [])
    rule_map = {
        "product_name": "Rule 6(1)(b)",
        "manufacturer": "Rule 6(1)(a) & 10",
        "net_quantity": "Rule 6(1)(c) & 13",
        "mrp": "Rule 6(1)(e)",
        "manufacturing_date": "Rule 6(1)(d)",
        "consumer_care": "Rule 6(2)",
        "country_of_origin": "Rule 6(1)(a)"
    }

    for d in declarations:
        field_key = d.get("field", "")
        conf_str = f"{int(float(d.get('confidence', 0.9)) * 100)}%"
        rule_cite = rule_map.get(field_key, "Rule 6(1)")
        decl_data.append([
            d.get("label", field_key),
            d.get("value", ""),
            conf_str,
            rule_cite
        ])

    decl_table = Table(decl_data, colWidths=[150, 230, 70, 90])
    decl_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1E293B')),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,0), 8),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#CBD5E1')),
        ('TOPPADDING', (0,0), (-1,-1), 3),
        ('BOTTOMPADDING', (0,0), (-1,-1), 3),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor('#F8FAFC')]),
    ]))
    elements.append(decl_table)
    elements.append(Spacer(1, 8))

    # Section 2: Statutory Compliance Checklist
    elements.append(Paragraph("2. Statutory Rule Compliance Checklist (LM Rules, 2011)", h2_style))
    checks = inspection_data.get("checks", [])
    chk_data = [["Statutory Requirement", "Analysis Result", "Status"]]
    for c in checks:
        chk_data.append([
            c.get("requirement", ""),
            c.get("result", ""),
            c.get("status", "")
        ])

    chk_table = Table(chk_data, colWidths=[180, 260, 100])
    chk_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#0F766E')),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,0), 8),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#CBD5E1')),
        ('TOPPADDING', (0,0), (-1,-1), 3),
        ('BOTTOMPADDING', (0,0), (-1,-1), 3),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor('#F0FDFA')]),
    ]))
    elements.append(chk_table)
    elements.append(Spacer(1, 8))

    # Section 3: Violations Section
    violations = inspection_data.get("violations", [])
    elements.append(Paragraph("3. Detected Rule Violations &amp; Infractions", h2_style))
    if violations:
        viol_data = [["Rule Citation", "Infraction Title", "Severity", "Finding & Statutory Reason"]]
        for v in violations:
            viol_data.append([
                v.get("rule", "LM Rules, 2011"),
                v.get("title", "Declaration Infraction"),
                v.get("severity", "Major"),
                v.get("reason", "")
            ])
        viol_table = Table(viol_data, colWidths=[130, 130, 60, 220])
        viol_table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#991B1B')),
            ('TEXTCOLOR', (0,0), (-1,0), colors.white),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('FONTSIZE', (0,0), (-1,0), 8),
            ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#FCA5A5')),
            ('TOPPADDING', (0,0), (-1,-1), 3),
            ('BOTTOMPADDING', (0,0), (-1,-1), 3),
            ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor('#FEF2F2')]),
        ]))
        elements.append(viol_table)
    else:
        elements.append(Paragraph("<i>No statutory violations detected. Package conforms to mandatory requirements under Rule 6 of the Legal Metrology (Packaged Commodities) Rules, 2011.</i>", body_style))
    
    elements.append(Spacer(1, 8))

    # Section 4: Officer Verification Section (Seventh Schedule Form A Style)
    elements.append(Paragraph("4. Legal Metrology Officer Verification (Seventh Schedule, Form A)", h2_style))
    remarks = inspection_data.get("remarks") or "Verified against submitted packaged commodity label photograph."
    final_st = inspection_data.get("final_status") or inspection_data.get("status", "Compliant")
    
    officer_box = [
        [Paragraph(f"<b>Authorized Enforcement Action:</b> {final_st.upper()}", body_style)],
        [Paragraph(f"<b>Official Remarks:</b> {remarks}", body_style)],
        [Paragraph(f"<b>Digital Signature Record:</b> Authorized Legal Metrology Inspector &bull; Officer ID: {officer} &bull; Directorate of Legal Metrology", body_style)]
    ]
    off_table = Table(officer_box, colWidths=[540])
    off_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#F1F5F9')),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#94A3B8')),
        ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor('#CBD5E1')),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
    ]))
    elements.append(off_table)
    elements.append(Spacer(1, 10))

    # Statutory Disclaimer Footer
    footer_text = "<b>Statutory Notice:</b> VidhiCheck is an AI-assisted advisory system for packaging inspection. Final prosecution or compounding action is governed by Section 15 &amp; Section 52 of The Legal Metrology Act, 2009 and requires authorization by an empowered Legal Metrology Officer.<br/><b>Generated by VidhiCheck — AI-Assisted Packaged Commodity Compliance Checker</b>"
    elements.append(Paragraph(footer_text, ParagraphStyle('Footer', parent=styles['Normal'], fontSize=7.5, leading=10, textColor=colors.HexColor('#64748B'), alignment=1)))

    doc.build(elements)
    buffer.seek(0)
    return buffer
