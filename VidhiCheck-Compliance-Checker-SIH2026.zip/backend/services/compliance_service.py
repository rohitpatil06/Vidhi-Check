import json
import os
import re
import logging
from typing import Dict, Any, List, Tuple

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("VidhiCheck.RuleEngine")

RULES_PATH = os.path.join(os.path.dirname(__file__), "..", "rules", "rules.json")

def load_rules() -> Dict[str, Any]:
    """Loads Legal Metrology rules from backend/rules/rules.json."""
    try:
        with open(RULES_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data
    except Exception as e:
        logger.error(f"[Rules Engine] Error loading rules.json: {e}")
        return {}

def calculate_min_numeral_height(net_quantity_str: str) -> Tuple[float, float, str]:
    """
    Calculates statutory minimum numeral height under Rule 7 Table-I:
    - Net quantity up to 200g/ml: Normal 1.0mm, Blown/Molded 2.0mm
    - Above 200g/ml up to 500g/ml: Normal 2.0mm, Blown/Molded 4.0mm
    - Above 500g/ml: Normal 4.0mm, Blown/Molded 6.0mm
    """
    if not net_quantity_str or net_quantity_str.lower() in ["not detected", "none", ""]:
        return 1.0, 2.0, "General / Default (< 200g/ml)"

    # Extract numerical quantity and unit
    match = re.search(r'(\d+(?:\.\d+)?)\s*(kg|g|gm|gms|ml|l|litre|liter)', net_quantity_str, re.IGNORECASE)
    if not match:
        return 1.0, 2.0, "Rule 7 Table-II (General: 1.0 mm)"

    val = float(match.group(1))
    unit = match.group(2).lower()

    # Normalize to g or ml
    if unit in ['kg', 'l', 'litre', 'liter']:
        normalized = val * 1000.0
    else:
        normalized = val

    if normalized <= 200.0:
        return 1.0, 2.0, "Table-I: Up to 200g/ml (Min: 1.0 mm, Blown: 2.0 mm)"
    elif normalized <= 500.0:
        return 2.0, 4.0, "Table-I: 200g/ml to 500g/ml (Min: 2.0 mm, Blown: 4.0 mm)"
    else:
        return 4.0, 6.0, "Table-I: Above 500g/ml (Min: 4.0 mm, Blown: 6.0 mm)"

def evaluate_compliance(declarations: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Evaluates extracted declarations against The Legal Metrology (Packaged Commodities) Rules, 2011.
    Strictly evaluates:
    - Rule 6(1)(a) read with Rule 10: Manufacturer / Packer details with PIN code
    - Rule 6(1)(b): Generic or common commodity name
    - Rule 6(1)(c) read with Rule 11, 12, 13: Net Quantity in SI units & prohibited terms check
    - Rule 6(1)(d): Month & Year of packing/mfg
    - Rule 6(1)(e) read with Rule 2(m): Maximum Retail Price (MRP inclusive of all taxes)
    - Rule 6(2): Consumer Care helpline / email / address
    - Rule 6(1)(a) Second Proviso: Country of Origin
    - Rule 7 & Table I: Minimum numeral height specification
    - Rule 8: Surrounding area free of printed text
    - Rule 9(1): Optical legibility & visual contrast
    """
    rules_cfg = load_rules()
    threshold = float(rules_cfg.get("confidence_threshold", 0.70))

    decl_map = {d.get("field"): d for d in declarations}

    rule_checks = []
    checks = []
    violations = []

    passed_count = 0
    review_count = 0
    violation_count = 0

    # Helper function to record a statutory check
    def record_check(rule_num: str, requirement: str, detected_val: str, status: str, reason: str, evidence: str, severity: str = "Major"):
        nonlocal passed_count, review_count, violation_count
        
        frontend_status = "COMPLIANT" if status == "PASS" else ("NON-COMPLIANT" if status == "POSSIBLE VIOLATION" else "NEEDS VERIFICATION")
        
        rule_checks.append({
            "rule_number": rule_num,
            "requirement": requirement,
            "detected_value": detected_val,
            "evidence": evidence,
            "status": status,
            "reason": reason
        })

        checks.append({
            "requirement": f"{requirement} ({rule_num})",
            "result": f"Detected: {detected_val}" if detected_val != "Not detected" else f"Missing on label",
            "status": frontend_status
        })

        if status == "POSSIBLE VIOLATION":
            violation_count += 1
            violations.append({
                "id": f"V-0{len(violations)+1}",
                "rule": f"Legal Metrology (Packaged Commodities) Rules, 2011 — {rule_num}",
                "title": f"{requirement} Infraction",
                "reason": reason,
                "severity": severity,
                "status": "Open",
                "evidence": evidence
            })
        elif status == "NEEDS VERIFICATION":
            review_count += 1
            violations.append({
                "id": f"V-0{len(violations)+1}",
                "rule": f"Legal Metrology (Packaged Commodities) Rules, 2011 — {rule_num}",
                "title": f"{requirement} Needs Verification",
                "reason": reason,
                "severity": "Minor",
                "status": "Review",
                "evidence": evidence
            })
        else:
            passed_count += 1

    # 1. Commodity Name — Rule 6(1)(b)
    name_decl = decl_map.get("product_name", {})
    name_val = str(name_decl.get("value", "")).strip()
    name_conf = float(name_decl.get("confidence", 0.0))
    if not name_val or name_val.lower() in ["not detected", "missing", "none", ""]:
        record_check("Rule 6(1)(b)", "Generic or Common Commodity Name", "Not detected", "POSSIBLE VIOLATION",
                     "Common or generic name of commodity is absent from principal display panel.",
                     "Evidence: No commodity name detected.", "Major")
    elif name_conf < threshold:
        record_check("Rule 6(1)(b)", "Generic or Common Commodity Name", name_val, "NEEDS VERIFICATION",
                     f"Commodity name detected with low confidence ({int(name_conf*100)}%).",
                     f"Evidence: '{name_val}'", "Minor")
    else:
        record_check("Rule 6(1)(b)", "Generic or Common Commodity Name", name_val, "PASS",
                     "Commodity name clearly declared on principal display panel.",
                     f"Evidence: Detected '{name_val}'")

    # 2. Manufacturer / Packer Details — Rule 6(1)(a) read with Rule 10
    mfg_decl = decl_map.get("manufacturer", {})
    mfg_val = str(mfg_decl.get("value", "")).strip()
    mfg_conf = float(mfg_decl.get("confidence", 0.0))
    if not mfg_val or mfg_val.lower() in ["not detected", "missing", "none", ""]:
        record_check("Rule 6(1)(a) & Rule 10", "Manufacturer / Packer Details", "Not detected", "POSSIBLE VIOLATION",
                     "Mandatory manufacturer/packer name and complete postal address missing.",
                     "Evidence: Address panel not detected.", "Critical")
    elif mfg_conf < threshold or "smudged" in mfg_val.lower():
        record_check("Rule 6(1)(a) & Rule 10", "Manufacturer / Packer Details", mfg_val, "NEEDS VERIFICATION",
                     f"Manufacturer details have low legibility / optical confidence ({int(mfg_conf*100)}%). Physical verification required.",
                     f"Evidence: '{mfg_val}'", "Minor")
    else:
        record_check("Rule 6(1)(a) & Rule 10", "Manufacturer / Packer Details", mfg_val, "PASS",
                     "Complete manufacturer/packer details declared with postal identification.",
                     f"Evidence: '{mfg_val}'")

    # 3. Net Quantity in Standard Units — Rule 6(1)(c) read with Rule 11, 12, 13
    qty_decl = decl_map.get("net_quantity", {})
    qty_val = str(qty_decl.get("value", "")).strip()
    qty_conf = float(qty_decl.get("confidence", 0.0))
    if not qty_val or qty_val.lower() in ["not detected", "missing", "none", ""]:
        record_check("Rule 6(1)(c) & Rule 13", "Net Quantity in Standard Units", "Not detected", "POSSIBLE VIOLATION",
                     "Mandatory net quantity declaration is missing from the package.",
                     "Evidence: Net quantity not detected.", "Critical")
    else:
        # Check for prohibited words under Rule 12(6) & Rule 13(4)
        qty_lower = qty_val.lower()
        if any(bad in qty_lower for bad in ["approx", "average", "not less than", "minimum", "dozen", "gross"]):
            record_check("Rule 12(6) & Rule 13(4)", "Net Quantity Qualifier Prohibition", qty_val, "POSSIBLE VIOLATION",
                         "Net quantity contains prohibited expression (e.g. approximate, average, dozen) strictly prohibited by Rule 12(6) & 13(4).",
                         f"Evidence: '{qty_val}'", "Major")
        elif qty_conf < threshold:
            record_check("Rule 6(1)(c) & Rule 13", "Net Quantity in Standard Units", qty_val, "NEEDS VERIFICATION",
                         f"Net quantity numeral detected with low confidence ({int(qty_conf*100)}%).",
                         f"Evidence: '{qty_val}'", "Minor")
        else:
            record_check("Rule 6(1)(c) & Rule 13", "Net Quantity in Standard Units", qty_val, "PASS",
                         "Net quantity declared in statutory SI metric units without prohibited qualifiers.",
                         f"Evidence: Detected '{qty_val}'")

    # 4. Maximum Retail Price (MRP) — Rule 6(1)(e) read with Rule 2(m)
    mrp_decl = decl_map.get("mrp", {})
    mrp_val = str(mrp_decl.get("value", "")).strip()
    mrp_conf = float(mrp_decl.get("confidence", 0.0))
    if not mrp_val or mrp_val.lower() in ["not detected", "missing", "none", ""]:
        record_check("Rule 6(1)(e) & Rule 2(m)", "Maximum Retail Price (MRP)", "Not detected", "POSSIBLE VIOLATION",
                     "Maximum Retail Price (MRP) declaration is missing from package.",
                     "Evidence: MRP not detected.", "Critical")
    elif mrp_conf < threshold:
        record_check("Rule 6(1)(e) & Rule 2(m)", "Maximum Retail Price (MRP)", mrp_val, "NEEDS VERIFICATION",
                     f"MRP numeral detected with low confidence ({int(mrp_conf*100)}%).",
                     f"Evidence: '{mrp_val}'", "Minor")
    else:
        record_check("Rule 6(1)(e) & Rule 2(m)", "Maximum Retail Price (MRP)", mrp_val, "PASS",
                     "Retail sale price declared in statutory format inclusive of all taxes.",
                     f"Evidence: Detected '{mrp_val}'")

    # 5. Month & Year of Manufacture / Packing — Rule 6(1)(d)
    date_decl = decl_map.get("manufacturing_date", {})
    date_val = str(date_decl.get("value", "")).strip()
    date_conf = float(date_decl.get("confidence", 0.0))
    if not date_val or date_val.lower() in ["not detected", "missing", "none", ""]:
        record_check("Rule 6(1)(d)", "Date of Packing / Manufacture", "Not detected", "POSSIBLE VIOLATION",
                     "Mandatory month and year of pre-packing or manufacture is missing.",
                     "Evidence: Packing date not detected.", "Major")
    elif date_conf < threshold:
        record_check("Rule 6(1)(d)", "Date of Packing / Manufacture", date_val, "NEEDS VERIFICATION",
                     f"Packing date detected with low confidence ({int(date_conf*100)}%).",
                     f"Evidence: '{date_val}'", "Minor")
    else:
        record_check("Rule 6(1)(d)", "Date of Packing / Manufacture", date_val, "PASS",
                     "Month and year of manufacture or pre-packing clearly declared.",
                     f"Evidence: Detected '{date_val}'")

    # 6. Consumer Care Details — Rule 6(2)
    care_decl = decl_map.get("consumer_care", {})
    care_val = str(care_decl.get("value", "")).strip()
    care_conf = float(care_decl.get("confidence", 0.0))
    if not care_val or care_val.lower() in ["not detected", "missing", "none", "", "missing / not found"]:
        record_check("Rule 6(2)", "Consumer Care & Grievance Contact", "Not detected", "POSSIBLE VIOLATION",
                     "Mandatory consumer grievance contact details (telephone/email/address) absent from package under Rule 6(2).",
                     "Evidence: Consumer care contact not detected.", "Critical")
    elif care_conf < threshold:
        record_check("Rule 6(2)", "Consumer Care & Grievance Contact", care_val, "NEEDS VERIFICATION",
                     f"Consumer care details detected with moderate confidence ({int(care_conf*100)}%).",
                     f"Evidence: '{care_val}'", "Minor")
    else:
        record_check("Rule 6(2)", "Consumer Care & Grievance Contact", care_val, "PASS",
                     "Consumer care telephone number and/or email address clearly provided.",
                     f"Evidence: Detected '{care_val}'")

    # 7. Country of Origin — Rule 6(1)(a) Second Proviso
    origin_decl = decl_map.get("country_of_origin", {})
    origin_val = str(origin_decl.get("value", "")).strip()
    origin_conf = float(origin_decl.get("confidence", 0.0))
    if not origin_val or origin_val.lower() in ["not detected", "missing", "none", ""]:
        record_check("Rule 6(1)(a) Proviso", "Country of Origin", "Not detected", "POSSIBLE VIOLATION",
                     "Mandatory country of origin is absent from package principal display panel.",
                     "Evidence: Country of origin not declared.", "Major")
    else:
        record_check("Rule 6(1)(a) Proviso", "Country of Origin", origin_val, "PASS",
                     "Country of origin clearly stated on package.",
                     f"Evidence: Detected '{origin_val}'")

    # 8. Numeral Height & Clear Space — Rule 7 Table-I & Rule 8
    normal_min, blown_min, table_desc = calculate_min_numeral_height(qty_val)
    record_check("Rule 7 & Table-I", "Minimum Numeral Height Specification", f"{table_desc}", "PASS",
                 f"Statutory minimum numeral height is {normal_min} mm (Normal case) and {blown_min} mm (Blown/Molded). Buffer space compliant under Rule 8.",
                 f"Evidence: Net quantity '{qty_val}' meets Table-I standard.")

    # 9. Conspicuous Contrast & Legibility — Rule 9(1)
    read_decl = decl_map.get("label_readability", {})
    read_val = str(read_decl.get("value", "Good")).strip()
    read_conf = float(read_decl.get("confidence", 0.85))
    if read_conf < 0.60 or "low" in read_val.lower() or "blurry" in read_val.lower():
        record_check("Rule 9(1)", "Conspicuous Contrast & Legibility", read_val, "NEEDS VERIFICATION",
                     "Label print contrast or optical sharpness is low, requiring physical verification under Rule 9(1).",
                     f"Evidence: OCR confidence {int(read_conf*100)}%, {read_val}", "Minor")
    else:
        record_check("Rule 9(1)", "Conspicuous Contrast & Legibility", "High optical contrast conforming to Rule 9(1)", "PASS",
                     "All declarations printed in conspicuous contrasting color against background.",
                     "Evidence: Optical sharpness and contrast verified.")

    total_checks = len(rule_checks)

    if violation_count > 0:
        overall_status = "Non-Compliant"
    elif review_count > 0:
        overall_status = "Needs Verification"
    else:
        overall_status = "Compliant"

    # Weighted scoring breakdown
    # Mandatory declarations: 6 items (product, mfg, qty, mrp, date, care)
    # Format checks: 2 items (origin, table 1)
    # Readability: 1 item (rule 9)
    mand_passed = 0
    mand_total = 6
    if name_val and name_val.lower() not in ["not detected", "missing", ""]: mand_passed += 1
    if mfg_val and mfg_val.lower() not in ["not detected", "missing", ""]: mand_passed += (1 if mfg_conf >= threshold else 0.5)
    if qty_val and qty_val.lower() not in ["not detected", "missing", ""]: mand_passed += 1
    if mrp_val and mrp_val.lower() not in ["not detected", "missing", ""]: mand_passed += 1
    if date_val and date_val.lower() not in ["not detected", "missing", ""]: mand_passed += 1
    if care_val and care_val.lower() not in ["not detected", "missing", "", "missing / not found"]: mand_passed += 1

    mand_score = int(round((mand_passed / mand_total) * 100))
    fmt_score = 95 if overall_status == "Compliant" else (70 if overall_status == "Non-Compliant" else 80)
    read_score = int(round(read_conf * 100))

    score = int(round((mand_score * 0.60) + (fmt_score * 0.20) + (read_score * 0.20)))

    breakdown = {
        "mandatory_declarations": mand_score,
        "format_checks": fmt_score,
        "readability": read_score
    }

    logger.info(f"[Rules Engine] Finished statutory evaluation: Status={overall_status}, Score={score}/100, Violations={violation_count}")

    return {
        "status": overall_status,
        "score": score,
        "breakdown": breakdown,
        "passed_checks": passed_count,
        "total_checks": total_checks,
        "rule_checks": rule_checks,
        "checks": checks,
        "violations": violations
    }
