from fastapi.testclient import TestClient
import main

def test_all():
    client = TestClient(main.app)

    # 1. Health check
    res = client.get('/api/health')
    assert res.status_code == 200, f'Health failed: {res.text}'
    print('PASS 1: Health check passed:', res.json())

    # 2. Dashboard
    res = client.get('/api/dashboard')
    assert res.status_code == 200, f'Dashboard failed: {res.text}'
    d = res.json()
    assert 'total' in d and 'recent' in d, 'Dashboard keys missing'
    print(f'PASS 2: Dashboard passed: Total={d["total"]}, Compliant={d["compliant"]}, Non-Compliant={d["non_compliant"]}')

    # 3. Inspections list
    res = client.get('/api/inspections')
    assert res.status_code == 200, f'Inspections failed: {res.text}'
    items = res.json()
    assert len(items) >= 3, 'Expected at least 3 seeded items'
    print(f'PASS 3: Inspections list passed: Found {len(items)} items')

    # 4. Inspection Detail
    res = client.get('/api/inspections/VC-001')
    assert res.status_code == 200, f'Inspection detail failed: {res.text}'
    detail = res.json()
    assert detail['product'] == 'Premium Basmati Rice'
    print(f'PASS 4: Inspection detail passed: {detail["id"]} {detail["product"]} Score: {detail["score"]}')

    # 5. Analyze sample product
    res = client.post('/api/analyze', data={'sample_id': 'sample_biscuit', 'officer': 'officer001'})
    assert res.status_code == 200, f'Analyze failed: {res.text}'
    analyzed = res.json()
    assert analyzed['status'] == 'Non-Compliant'
    assert len(analyzed['violations']) > 0
    print(f'PASS 5: Analyze sample passed: {analyzed["id"]} {analyzed["product"]} Status: {analyzed["status"]}')

    # 6. Officer Verification
    res = client.post('/api/verify', json={'inspection_id': analyzed['id'], 'decision': 'Confirm Violation', 'remarks': 'Helpline absent. Violation confirmed.'})
    assert res.status_code == 200, f'Verify failed: {res.text}'
    ver = res.json()
    assert ver['final_status'] == 'Non-Compliant'
    print(f'PASS 6: Officer verification passed: {ver}')

    # 7. Download PDF Report
    res = client.get(f'/api/report/{analyzed["id"]}')
    assert res.status_code == 200, f'Report failed: {res.text}'
    assert res.headers['content-type'] == 'application/pdf'
    assert res.content.startswith(b'%PDF'), 'Not a valid PDF header'
    print(f'PASS 7: Report generation passed: Received valid PDF ({len(res.content)} bytes)')

    print('\n=============================================')
    print('ALL 7 BACKEND API TEST SUITES PASSED!')
    print('=============================================')

if __name__ == '__main__':
    test_all()
